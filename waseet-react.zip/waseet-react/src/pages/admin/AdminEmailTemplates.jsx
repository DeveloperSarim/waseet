import React, { useState } from 'react'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

// Icon d-paths (exact from source)
const userPlus = 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM20 8v6M23 11h-6'
const userCheck = 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM16 11l2 2 4-4'
const lockI = 'M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4'
const mailI = 'M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM22 6l-10 7L2 6'
const checkI = 'M20 6L9 17l-5-5'
const xI = 'M18 6L6 18M6 6l12 12'
const pauseI = 'M6 4h4v16H6zM14 4h4v16h-4z'
const filePlus = 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M12 12v6M9 15h6'
const refreshI = 'M23 4v6h-6M1 20v-6h6M3.5 9a9 9 0 0 1 14.8-3.4L23 10M1 14l4.7 4.4A9 9 0 0 0 20.5 15'
const coinI = 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 7v10'
const bankI = 'M3 21h18M3 10h18M5 6l7-3 7 3M4 10v11M20 10v11M8 14v3M12 14v3M16 14v3'
const alertI = 'M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01'
const speakI = 'M3 11l18-5v12L3 14v-3z'
const toolsI = 'M14.7 6.3a4 4 0 0 1-5.4 5.4L3 18v3h3l6.3-6.3a4 4 0 0 1 5.4-5.4z'

const groupsDef = [
  { label: 'Account', iconBg: '#EEF3FF', iconColor: '#1B4FD8', items: [
    { id: 'dev_welcome', name: 'Developer welcome', edited: 'Edited Jun 20', icon: userPlus },
    { id: 'realtor_welcome', name: 'Realtor welcome', edited: 'Edited Jun 20', icon: userCheck },
    { id: 'temp_pw', name: 'Temporary password', edited: 'Edited Jun 15', icon: lockI },
    { id: 'verify', name: 'Email verification', edited: 'Edited Jun 10', icon: mailI },
  ] },
  { label: 'Review', iconBg: '#FEF9EC', iconColor: colors.amber, items: [
    { id: 'approved', name: 'Application approved', edited: 'Edited Jun 18', icon: checkI },
    { id: 'rejected', name: 'Application rejected', edited: 'Edited Jun 18', icon: xI },
    { id: 'suspended', name: 'Account suspended', edited: 'Edited Jun 12', icon: pauseI },
  ] },
  { label: 'Leads', iconBg: colors.purpleTint, iconColor: '#5B5BD6', items: [
    { id: 'lead_recv', name: 'Lead received', edited: 'Edited Jun 8', icon: filePlus },
    { id: 'lead_upd', name: 'Lead status updated', edited: 'Edited Jun 8', icon: refreshI },
  ] },
  { label: 'Commissions', iconBg: colors.greenTint, iconColor: colors.green, items: [
    { id: 'comm_inv', name: 'Commission invoice', edited: 'Edited Jun 22', icon: coinI },
    { id: 'pay_verified', name: 'Payment verified', edited: 'Edited Jun 22', icon: checkI },
    { id: 'disbursed', name: 'Disbursement sent', edited: 'Edited Jun 22', icon: bankI },
    { id: 'overdue', name: 'Payment overdue', edited: 'Edited Jun 5', icon: alertI },
  ] },
  { label: 'Platform', iconBg: colors.surfaceMuted, iconColor: colors.textMuted, items: [
    { id: 'announce', name: 'Announcement', edited: 'Edited Jun 26', icon: speakI },
    { id: 'maint', name: 'Maintenance notice', edited: 'Edited May 30', icon: toolsI },
  ] },
]

const allItems = groupsDef.flatMap((g) => g.items)
const triggerMap = {
  temp_pw: 'Triggered: when admin approves account and sends login credentials',
  dev_welcome: 'Triggered: when a developer account is approved',
  realtor_welcome: 'Triggered: when a realtor account is approved',
}
const variables = ['{{name}}', '{{email}}', '{{temp_password}}', '{{company_name}}', '{{login_url}}', '{{support_email}}', '{{badge}}']
const bodyText = 'Hi {{name}},\n\nWelcome to Waseet! Your account has been approved. Here are your login credentials:\n\nEmail: {{email}}\nTemporary Password: {{temp_password}}\n\nPlease log in and change your password immediately at: {{login_url}}\n\nThis temporary password expires in 24 hours.\n\nIf you have any questions, contact us at {{support_email}}.\n\nThe Waseet Team'

const tabActive = { padding: '0 12px', height: 32, display: 'flex', alignItems: 'center', fontSize: 12, cursor: 'pointer', background: colors.ink, color: '#fff' }
const tabIdle = { padding: '0 12px', height: 32, display: 'flex', alignItems: 'center', fontSize: 12, cursor: 'pointer', background: 'transparent', color: colors.textSoft }

export default function AdminEmailTemplates() {
  const [active, setActive] = useState('temp_pw')
  const [mode, setMode] = useState('edit') // edit | preview
  const [device, setDevice] = useState('desktop') // desktop | mobile
  const [saveState, setSaveState] = useState('idle') // idle | saved
  const [toast, setToast] = useState(false)
  const [testOpen, setTestOpen] = useState(false)
  const [testSent, setTestSent] = useState(false)
  const [resetOpen, setResetOpen] = useState(false)

  const cur = allItems.find((t) => t.id === active) || allItems[2]
  const tplName = cur.name
  const tplTrigger = triggerMap[active] || ('Triggered: ' + cur.name.toLowerCase())
  const isEdit = mode === 'edit'
  const isPreview = mode === 'preview'

  const save = () => {
    setSaveState('saved'); setToast(true)
    setTimeout(() => { setSaveState('idle'); setToast(false) }, 3000)
  }
  const openTest = () => { setTestOpen(true); setTestSent(false) }
  const sendTest = () => setTestSent(true)
  const openReset = () => setResetOpen(true)
  const closeModals = () => { setTestOpen(false); setResetOpen(false); setTestSent(false) }
  const stop = (e) => e.stopPropagation()

  const saveLabel = saveState === 'saved' ? 'Saved ✓' : 'Save Changes'
  const saveBtnStyle = {
    height: 34, padding: '0 16px', borderRadius: 7, fontSize: 13, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer',
    ...(saveState === 'saved'
      ? { background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, color: colors.greenDark }
      : { background: colors.green, border: 'none', color: '#fff' }),
  }
  const previewWidth = device === 'mobile' ? '375px' : '100%'

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>Email Templates</span>
            <span style={{ fontSize: 13, color: colors.textFaint }}>14 templates</span>
          </div>
        }
        actions={
          <button onClick={openTest} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={1.8}><path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM22 6l-10 7L2 6" /></svg>Send test email
          </button>
        }
      />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>

          {/* LEFT: TEMPLATE LIST */}
          <div style={{ width: 280, flexShrink: 0, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ padding: '12px 14px', borderBottom: `1px solid ${colors.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 13, fontWeight: 600 }}>Templates</span>
              <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8} style={{ cursor: 'pointer' }}><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.3-4.3" /></svg>
            </div>
            {groupsDef.map((g) => (
              <div key={g.label}>
                <div style={{ padding: '8px 14px', background: colors.bg, borderBottom: `1px solid ${colors.surfaceMuted}`, fontSize: 9, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{g.label}</div>
                {g.items.map((t) => {
                  const on = active === t.id
                  return (
                    <div key={t.id} onClick={() => setActive(t.id)} style={{ padding: '10px 14px', borderBottom: `1px solid ${colors.surfaceMuted}`, cursor: 'pointer', display: 'flex', gap: 10, alignItems: 'center', ...(on ? { background: colors.greenTint, borderLeft: `3px solid ${colors.green}` } : {}) }}>
                      <div style={{ width: 28, height: 28, borderRadius: 7, background: on ? colors.greenTint : g.iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={on ? colors.green : g.iconColor} strokeWidth={1.8}><path d={t.icon} /></svg>
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 1, color: on ? colors.greenDark : colors.ink }}>{t.name}</div>
                        <div style={{ fontSize: 10, color: colors.textFaint }}>{t.edited}</div>
                      </div>
                    </div>
                  )
                })}
              </div>
            ))}
          </div>

          {/* RIGHT: EDITOR */}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 3 }}>{tplName}</div>
                  <div style={{ fontSize: 12, color: colors.textFaint }}>{tplTrigger}</div>
                </div>
                <div style={{ display: 'flex', border: `1px solid ${colors.border}`, borderRadius: 7, overflow: 'hidden' }}>
                  <span onClick={() => setMode('edit')} style={isEdit ? tabActive : tabIdle}>Edit</span>
                  <span onClick={() => setMode('preview')} style={isPreview ? tabActive : tabIdle}>Preview</span>
                </div>
              </div>

              {/* EDIT MODE */}
              {isEdit && (
                <>
                  <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '12px 14px', marginBottom: 16, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                    <div><div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 2 }}>Trigger</div><div style={{ fontSize: 12, color: colors.textMuted }}>Account approval</div></div>
                    <div><div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 2 }}>Recipients</div><div style={{ fontSize: 12, color: colors.textMuted }}>New developer/realtor</div></div>
                    <div><div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 2 }}>Last edited</div><div style={{ fontSize: 12, color: colors.textMuted }}>June 15, 2026</div></div>
                    <div><div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 2 }}>Sent count</div><div style={{ fontSize: 12, color: colors.textMuted }}>32 times</div></div>
                  </div>
                  <div style={{ marginBottom: 14 }}>
                    <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Subject</div>
                    <input defaultValue="Welcome to Waseet — Your login details" style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 13, fontFamily: 'inherit' }} />
                  </div>
                  <div style={{ marginBottom: 12 }}>
                    <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 6 }}>Available variables:</div>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      {variables.map((v) => (
                        <span key={v} style={{ background: '#EEF3FF', border: `1px solid ${colors.blueTintBorder}`, borderRadius: 4, padding: '2px 7px', fontSize: 11, color: '#1B4FD8', fontFamily: 'monospace', cursor: 'pointer' }}>{v}</span>
                      ))}
                    </div>
                    <div style={{ fontSize: 10, color: colors.textFaint, marginTop: 4 }}>Click to copy</div>
                  </div>
                  <div style={{ background: colors.bg, border: `1px solid ${colors.border}`, borderBottom: 'none', borderRadius: '8px 8px 0 0', padding: '7px 10px', display: 'flex', gap: 2, alignItems: 'center' }}>
                    <span style={{ width: 28, height: 28, borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center', color: colors.textFaint, cursor: 'pointer', fontSize: 13, fontWeight: 700 }}>B</span>
                    <span style={{ width: 28, height: 28, borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center', color: colors.textFaint, cursor: 'pointer', fontSize: 13, fontStyle: 'italic' }}>I</span>
                    <span style={{ width: 28, height: 28, borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center', color: colors.textFaint, cursor: 'pointer', fontSize: 13, textDecoration: 'underline' }}>U</span>
                    <span style={{ width: 1, height: 16, background: colors.border, margin: '0 4px' }} />
                    <span style={{ width: 28, height: 28, borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center', color: colors.textFaint, cursor: 'pointer' }}><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" /></svg></span>
                    <span style={{ width: 1, height: 16, background: colors.border, margin: '0 4px' }} />
                    <span style={{ height: 28, padding: '0 10px', borderRadius: 5, display: 'flex', alignItems: 'center', gap: 4, background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, color: colors.greenDark, cursor: 'pointer', fontSize: 11, fontWeight: 500 }}>+ Insert variable</span>
                  </div>
                  <textarea defaultValue={bodyText} style={{ width: '100%', minHeight: 280, border: `1px solid ${colors.border}`, borderTop: 'none', borderRadius: '0 0 8px 8px', padding: '12px 14px', fontSize: 13, color: colors.textMuted, lineHeight: 1.8, fontFamily: 'monospace', resize: 'vertical' }} />
                  <div style={{ border: `1px solid ${colors.border}`, borderTop: 'none', borderRadius: '0 0 8px 8px', padding: '6px 10px', display: 'flex', justifyContent: 'space-between', marginTop: -8 }}>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>{'{{name}} will be replaced with actual value'}</span>
                    <span style={{ fontSize: 10, color: colors.textFaint }}>Characters: 487</span>
                  </div>
                  <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
                    <button onClick={save} style={saveBtnStyle}>{saveLabel}</button>
                    <button onClick={openReset} style={{ height: 34, padding: '0 14px', background: 'transparent', border: 'none', fontSize: 12, color: colors.textFaint, fontFamily: 'inherit', cursor: 'pointer' }}>Reset to default</button>
                    <button onClick={openTest} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Send test email</button>
                  </div>
                </>
              )}

              {/* PREVIEW MODE */}
              {isPreview && (
                <>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                    <span style={{ fontSize: 13, fontWeight: 600 }}>Email preview</span>
                    <span style={{ fontSize: 12, color: colors.textFaint }}>Variables filled with sample data</span>
                  </div>
                  <div style={{ display: 'flex', border: `1px solid ${colors.border}`, borderRadius: 7, overflow: 'hidden', marginBottom: 12, width: 'fit-content' }}>
                    <span onClick={() => setDevice('desktop')} style={device === 'desktop' ? tabActive : tabIdle}>Desktop</span>
                    <span onClick={() => setDevice('mobile')} style={device === 'mobile' ? tabActive : tabIdle}>Mobile</span>
                  </div>
                  <div style={{ border: `1px solid ${colors.border}`, borderRadius: 10, overflow: 'hidden', maxWidth: previewWidth, margin: '0 auto' }}>
                    <div style={{ background: colors.ink, padding: '16px 24px' }}>
                      <span style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>waseet</span>
                      <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', marginLeft: 6 }}>وسيط</span>
                    </div>
                    <div style={{ background: colors.surfaceMuted, padding: '8px 24px', borderBottom: `1px solid ${colors.border}` }}>
                      <div style={{ fontSize: 11, color: colors.textFaint }}>From: noreply@waseet.io</div>
                      <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>To: m.faisal@alfaisal.com</div>
                      <div style={{ fontSize: 11, color: colors.textMuted, marginTop: 2 }}>Subject: Welcome to Waseet — Your login details</div>
                    </div>
                    <div style={{ background: '#fff', padding: '24px 32px', fontSize: 14, color: colors.textMuted, lineHeight: 1.8 }}>
                      <div style={{ marginBottom: 14 }}>Hi <span style={{ color: colors.greenDark, fontWeight: 500 }}>Mohammed</span>,</div>
                      <div style={{ marginBottom: 14 }}>Welcome to Waseet! Your account has been approved. Here are your login credentials:</div>
                      <div style={{ marginBottom: 4 }}>Email: <span style={{ color: colors.greenDark, fontWeight: 500 }}>m.faisal@alfaisal.com</span></div>
                      <div style={{ marginBottom: 14 }}>Temporary Password: <span style={{ color: colors.greenDark, fontWeight: 500, background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 4, padding: '1px 6px', fontFamily: 'monospace' }}>TempPass@123</span></div>
                      <div style={{ marginBottom: 14 }}>Please log in and change your password immediately.</div>
                      <div style={{ marginBottom: 14 }}>This temporary password expires in 24 hours.</div>
                      <div style={{ marginBottom: 4 }}>If you have any questions, contact us at <span style={{ color: '#1B4FD8', textDecoration: 'underline' }}>support@waseet.io</span>.</div>
                      <div style={{ marginTop: 8 }}>The Waseet Team</div>
                      <span style={{ display: 'inline-block', background: colors.green, color: '#fff', borderRadius: 7, padding: '10px 20px', fontSize: 14, fontWeight: 600, marginTop: 16 }}>Log in to Waseet</span>
                    </div>
                    <div style={{ background: colors.surfaceMuted, borderTop: `1px solid ${colors.border}`, padding: '14px 24px' }}>
                      <div style={{ fontSize: 11, color: colors.textFaint }}>© 2026 Waseet · waseet.io</div>
                      <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 4 }}>Unsubscribe</div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* TEST MODAL */}
      {testOpen && (
        <div onClick={closeModals} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div onClick={stop} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px', maxWidth: 420, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)' }}>
            {!testSent ? (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>Send test email</span>
                  <span onClick={closeModals} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span>
                </div>
                <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '10px 12px', marginBottom: 14 }}>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 3 }}>Template:</div>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{tplName}</div>
                </div>
                <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Send to:</div>
                <div style={{ position: 'relative' }}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}><path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM22 6l-10 7L2 6" /></svg>
                  <input placeholder="admin@waseet.io" style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 13, fontFamily: 'inherit' }} />
                </div>
                <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 8 }}>Variables will be filled with sample data for the test.</div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 14 }}>
                  <button onClick={closeModals} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Cancel</button>
                  <button onClick={sendTest} style={{ height: 34, padding: '0 14px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Send test</button>
                </div>
              </>
            ) : (
              <div style={{ textAlign: 'center', padding: '8px 0' }}>
                <svg width={36} height={36} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2} style={{ marginBottom: 10 }}><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></svg>
                <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 6 }}>Test email sent!</div>
                <div style={{ fontSize: 12, color: colors.textSoft }}>Delivered to admin@waseet.io</div>
                <button onClick={closeModals} style={{ width: '100%', height: 34, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', marginTop: 14 }}>Done</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* RESET MODAL */}
      {resetOpen && (
        <div onClick={closeModals} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div onClick={stop} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px', maxWidth: 420, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>Reset template?</div>
                <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 4 }}>{tplName}</div>
              </div>
              <span onClick={closeModals} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span>
            </div>
            <div style={{ background: colors.amberTint, border: `1px solid ${colors.amberTintBorder}`, borderRadius: 8, padding: '10px 12px', marginBottom: 14, fontSize: 13, color: colors.amberText, lineHeight: 1.6 }}>All your custom edits to this template will be lost and replaced with the default content.</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
              <button onClick={closeModals} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Cancel</button>
              <button onClick={closeModals} style={{ height: 34, padding: '0 14px', background: colors.red, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Reset to default</button>
            </div>
          </div>
        </div>
      )}

      {/* SAVE TOAST */}
      {toast && (
        <div style={{ position: 'fixed', right: 22, bottom: 22, zIndex: 60, background: '#fff', border: `1px solid ${colors.greenTintBorder}`, borderRadius: 10, padding: '12px 14px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2} style={{ flexShrink: 0, marginTop: 1 }}><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></svg>
          <div>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Template saved</div>
            <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>{tplName} template updated</div>
          </div>
        </div>
      )}
    </>
  )
}
