import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { Topbar } from '../../components/layout/Topbar'
import { Avatar } from '../../components/ui'

const card = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 18px', marginBottom: 12 }
const sectionLabel = { fontSize: 9, fontWeight: 700, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em' }
const rLabel = { fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }

const data = {
  developer: {
    listPath: '/admin/developers', listName: 'Developers', name: 'Al Faisal Development', email: 'm.faisal@alfaisal.com',
    infoLabel: 'Company Information',
    fields: [['Company Name', 'Al Faisal Development'], ['REGA License', 'REGA-2024-12345'], ['CR Number', '1234567890'], ['Country', 'Saudi Arabia 🇸🇦'], ['City', 'Jeddah'], ['Website', 'alfaisal.com'], ['Years in Business', '10+ years'], ['Type', 'Real Estate Developer']],
    contact: [['Full Name', 'Mohammed Al-Faisal'], ['Designation', 'Sales Director'], ['Phone', '+966 50 987 6543'], ['Email', 'm.faisal@alfaisal.com'], ['WhatsApp', '+966 50 987 6543']],
    docs: [{ name: 'Trade License / CR', meta: 'PDF · 2.4 MB' }, { name: 'REGA Certificate', meta: 'PDF · 1.1 MB' }],
  },
  realtor: {
    listPath: '/admin/realtors', listName: 'Realtors', name: 'Fatima Al-Otaibi', email: 'fatima@gmail.com',
    infoLabel: 'Realtor Information',
    fields: [['Full Name', 'Fatima Al-Otaibi'], ['Iqama / ID', '2XXXXXXXX1'], ['FAL License', 'FAL-2024-66120'], ['License Expiry', 'Nov 2026'], ['Country', 'Saudi Arabia 🇸🇦'], ['City', 'Riyadh'], ['Experience', '3–5 years'], ['Languages', 'Arabic · English']],
    contact: [['Phone', '+966 55 220 1188'], ['WhatsApp', '+966 55 220 1188'], ['Email', 'fatima@gmail.com'], ['Agency', 'Independent']],
    docs: [{ name: 'FAL License', meta: 'PDF · 1.8 MB' }, { name: 'Iqama Copy', meta: 'JPG · 1.2 MB' }, { name: 'Profile Photo', meta: 'JPG · 0.6 MB' }],
  },
}

export default function AdminReview({ role = 'developer' }) {
  const navigate = useNavigate()
  const d = data[role]
  const [preview, setPreview] = useState(null)
  const [modal, setModal] = useState(null) // 'approve' | 'reject'

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span onClick={() => navigate(d.listPath)} style={{ fontSize: 13, color: colors.textFaint, cursor: 'pointer' }}>{d.listName}</span>
            <Icon name="chevronRight" size={14} color={colors.borderStrong} strokeWidth={2} />
            <span style={{ fontSize: 13, fontWeight: 500 }}>{d.name}</span>
          </div>
        }
        actions={<button onClick={() => navigate(d.listPath)} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>← Back to list</button>}
      />
      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div className="rp-cols" style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
          {/* LEFT */}
          <div style={{ flex: 2.5, minWidth: 0 }}>
            <div style={card}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <span style={sectionLabel}>{d.infoLabel}</span>
                <span style={{ background: colors.amberTint, border: `1px solid ${colors.amberTintBorder}`, color: colors.amberText, borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 700 }}>Pending Review</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px 16px' }}>
                {d.fields.map(([label, value]) => (
                  <div key={label}>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 2 }}>{label}</div>
                    <div style={{ fontSize: 13, color: colors.textMuted }}>{value}</div>
                  </div>
                ))}
              </div>
            </div>

            <div style={card}>
              <div style={{ ...sectionLabel, marginBottom: 14 }}>Contact Person</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px 16px' }}>
                {d.contact.map(([label, value]) => (
                  <div key={label}>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 2 }}>{label}</div>
                    <div style={{ fontSize: 13, color: colors.textMuted }}>{value}</div>
                  </div>
                ))}
              </div>
            </div>

            <div style={card}>
              <div style={{ ...sectionLabel, marginBottom: 8 }}>Documents</div>
              {d.docs.map((doc) => (
                <div key={doc.name} style={{ padding: '12px 0', borderBottom: `1px solid ${colors.surfaceMuted}`, display: 'flex', gap: 12, alignItems: 'center' }}>
                  <div style={{ flex: 1, display: 'flex', gap: 10, alignItems: 'center' }}>
                    <Icon name="fileText" size={18} color={colors.textFaint} strokeWidth={1.6} />
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{doc.name}</div>
                      <div style={{ fontSize: 11, color: colors.textFaint }}>{doc.meta}</div>
                    </div>
                  </div>
                  <span style={{ background: colors.amberTint, color: colors.amberText, border: `1px solid ${colors.amberTintBorder}`, borderRadius: 999, padding: '2px 8px', fontSize: 10, fontWeight: 600 }}>Pending</span>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <span onClick={() => setPreview(doc.name)} style={{ display: 'flex', gap: 4, alignItems: 'center', fontSize: 11, color: colors.greenDark, border: `1px solid ${colors.greenTintBorder}`, background: colors.greenTint, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>
                      <Icon name="eye" size={12} color={colors.greenDark} strokeWidth={1.8} />Preview
                    </span>
                    <span style={{ fontSize: 11, color: colors.textMuted, border: `1px solid ${colors.border}`, background: '#fff', borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>Download ↓</span>
                  </div>
                </div>
              ))}
              {preview && (
                <div style={{ marginTop: 10, background: colors.surfaceAlt, border: `1px solid ${colors.border}`, borderRadius: 10, overflow: 'hidden' }}>
                  <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '8px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={{ fontSize: 12, color: colors.textMuted }}>Page 1 of 3</span>
                      <span style={{ fontSize: 12, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>← Prev</span>
                      <span style={{ fontSize: 12, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>Next →</span>
                    </div>
                    <span onClick={() => setPreview(null)} style={{ fontSize: 16, color: colors.textFaint, cursor: 'pointer' }}>×</span>
                  </div>
                  <div style={{ height: 240, background: colors.surfaceMuted, backgroundImage: 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 9px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ fontSize: 13, color: colors.textFaint, background: 'rgba(249,250,251,0.9)', padding: '6px 12px', borderRadius: 6 }}>PDF Preview — {preview}</span>
                  </div>
                  <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, padding: '8px 12px', display: 'flex', justifyContent: 'flex-end' }}>
                    <button style={{ height: 30, padding: '0 12px', background: colors.green, border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
                      <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2.5}><path d="M20 6L9 17l-5-5" /></svg>Mark as Verified
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* RIGHT */}
          <div style={{ flex: 1, minWidth: 240 }}>
            <div style={card}>
              <div style={rLabel}>Account Status</div>
              <div style={{ background: colors.amberTint, border: `1px solid ${colors.amberTintBorder}`, borderRadius: 8, padding: '8px 12px', display: 'flex', gap: 8, alignItems: 'center' }}>
                <Icon name="clock" size={18} color={colors.amber} strokeWidth={1.8} />
                <span style={{ fontSize: 18, fontWeight: 700, color: colors.amberText }}>Pending Review</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 11, color: colors.textFaint }}>Applied</span><span style={{ fontSize: 12, color: colors.textMuted }}>June 24, 2026</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 11, color: colors.textFaint }}>First application</span><span style={{ fontSize: 12, color: colors.textMuted }}>Yes</span></div>
              </div>
            </div>

            {role === 'developer' && (
              <div style={card} className="wa-form">
                <div style={rLabel}>Platform Commission</div>
                <div style={{ fontSize: 12, color: colors.textSoft, marginBottom: 10 }}>Global default: 15%</div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span style={{ fontSize: 12, color: colors.textMuted }}>Override:</span>
                  <input defaultValue="15" style={{ width: 60, height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 8px', fontSize: 13, fontFamily: 'inherit', textAlign: 'right' }} />
                  <span style={{ fontSize: 13, color: colors.textMuted }}>%</span>
                  <button style={{ height: 30, padding: '0 10px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Save</button>
                </div>
                <div style={{ fontSize: 10, color: colors.textFaint, marginTop: 8 }}>Applies to new deals only</div>
              </div>
            )}

            <div style={card} className="wa-form">
              <div style={rLabel}>Internal Notes</div>
              <textarea placeholder="Add internal notes..." style={{ width: '100%', height: 90, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', resize: 'none' }} />
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                <button style={{ height: 30, padding: '0 12px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Save Note</button>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <button onClick={() => setModal('approve')} style={{ height: 36, background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2.5}><path d="M20 6L9 17l-5-5" /></svg>Approve &amp; Send Credentials
              </button>
              <button onClick={() => setModal('reject')} style={{ height: 36, background: '#fff', border: `1px solid ${colors.redTintBorder}`, borderRadius: 8, fontSize: 13, fontWeight: 600, color: colors.red, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                <Icon name="xCircle" size={14} color={colors.red} strokeWidth={2} />Reject with Reason
              </button>
              <button style={{ height: 36, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>Suspend Account</button>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {modal && (
        <div onClick={() => setModal(null)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px', maxWidth: 420, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)' }} className="wa-form">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>{modal === 'approve' ? `Approve ${role} account` : `Reject application`}</span>
              <span onClick={() => setModal(null)} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span>
            </div>
            {modal === 'approve' ? (
              <div style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 8, padding: '10px 12px', marginBottom: 14, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                <Icon name="info" size={16} color={colors.green} strokeWidth={1.8} style={{ flexShrink: 0, marginTop: 1 }} />
                <div>
                  <div style={{ fontSize: 12, color: colors.textMuted, marginBottom: 4 }}>Credentials will be emailed to:</div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{d.email}</div>
                  <div style={{ fontSize: 12, color: colors.textSoft, marginTop: 4 }}>A temporary password will be included. Expires in 24 hours.</div>
                </div>
              </div>
            ) : (
              <>
                <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Rejection reason (sent to applicant):</div>
                <textarea placeholder="Explain why the application was rejected..." style={{ width: '100%', height: 80, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, fontFamily: 'inherit', resize: 'none', marginBottom: 14 }} />
              </>
            )}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
              <button onClick={() => setModal(null)} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Cancel</button>
              <button onClick={() => { setModal(null); navigate(d.listPath) }} style={{ height: 34, padding: '0 14px', background: modal === 'approve' ? colors.green : colors.red, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>{modal === 'approve' ? 'Approve & Send' : 'Reject Application'}</button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
