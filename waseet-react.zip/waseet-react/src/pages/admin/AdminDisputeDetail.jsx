import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const card = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 18px' }
const capLabel = { fontSize: 9, fontWeight: 700, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 14 }
const rLabel = { fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }
const softLabel = { fontSize: 9, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }
const previewHatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 11px)'

const leadInfo = [
  ['Client', 'Khalid Al-Ansari'], ['Project', 'Palm Residence · 2BR'],
  ['Lead ID', '#WS-2026-042'], ['Deal Value', 'SAR 900,000'], ['Commission', 'SAR 27,000 (3%)'],
]
const pdfPath = 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6'
const imgPath = 'M3 3h18v18H3zM3 15l5-5 4 4 3-3 6 6'
const evidence = [
  { name: 'whatsapp_screenshot.jpg', meta: '1.2 MB · Image · Jun 27', iconColor: '#16A34A', iconPath: imgPath },
  { name: 'marketing_email.pdf', meta: '0.8 MB · PDF · Jun 27', iconColor: '#DC2626', iconPath: pdfPath },
  { name: 'client_record.pdf', meta: '2.1 MB · PDF · Jun 27', iconColor: '#DC2626', iconPath: pdfPath },
]
const circleFill = { system: { background: '#EEF3FF', border: '1px solid #BFDBFE' }, event: { background: colors.surfaceMuted, border: `1px solid ${colors.border}` } }
const history = [
  { type: 'system', label: 'Dispute raised', time: 'Jun 27 · 2:14 PM', desc: 'Al Faisal Development submitted dispute' },
  { type: 'event', label: 'Evidence uploaded', time: 'Jun 27 · 2:18 PM', desc: '3 files attached by developer' },
  { type: 'event', label: 'Admin review started', time: 'Jun 28 · 9:00 AM', desc: 'Assigned to Super Admin' },
  { type: 'event', label: 'Under review', time: 'Ongoing', desc: 'Admin reviewing evidence and lead history', last: true },
]
const ctx = [
  { label: 'Lead submitted', date: 'Jun 24', sub: 'Ahmed Al-Rashid submitted lead' },
  { label: 'Contacted', date: 'Jun 25' }, { label: 'Site Visit', date: 'Jun 26' }, { label: 'Dispute raised', date: 'Jun 27' },
]
const modalShell = { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }
const chip = { display: 'inline-block', height: 28, lineHeight: '26px', padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 11, color: colors.textMuted, cursor: 'pointer' }

export default function AdminDisputeDetail() {
  const navigate = useNavigate()
  const [choice, setChoice] = useState(null) // realtor | dev
  const [note, setNote] = useState('')
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [resolved, setResolved] = useState(false)
  const [toast, setToast] = useState(false)
  const [preview, setPreview] = useState(null)

  const canResolve = !!choice && note.trim().length > 0
  const decisionText = choice === 'dev' ? 'In favor of Developer — Al Faisal Development' : 'In favor of Realtor — Ahmed Al-Rashid'
  const detailText = choice === 'dev' ? 'Commission SAR 27,000 will be cancelled. Developer is not charged.' : 'Commission SAR 22,950 will be disbursed as normal.'

  const confirmResolve = () => {
    setConfirmOpen(false); setResolved(true); setToast(true)
    setTimeout(() => setToast(false), 5000)
  }

  const optStyle = (on) => ({ border: on ? `2px solid ${colors.green}` : `1px solid ${colors.border}`, borderRadius: 10, padding: '12px 14px', cursor: 'pointer', background: on ? colors.greenTint : '#fff' })
  const radio = (on) => ({ width: 16, height: 16, borderRadius: '50%', flexShrink: 0, ...(on ? { background: colors.green, boxShadow: `inset 0 0 0 3px #fff, 0 0 0 1px ${colors.green}` } : { background: '#fff', border: `1.5px solid ${colors.borderStrong}` }) })

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span onClick={() => navigate('/admin/disputes')} style={{ fontSize: 13, color: colors.textFaint, cursor: 'pointer' }}>Disputes</span>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.borderStrong} strokeWidth={2}><path d="M9 6l6 6-6 6" /></svg>
            <span style={{ fontSize: 13, color: colors.ink, fontWeight: 500 }}>Dispute #D-0012</span>
          </div>
        }
        actions={<button onClick={() => navigate('/admin/disputes')} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2}><path d="M15 18l-6-6 6-6" /></svg>Back to list</button>}
      />

      {/* Status banner */}
      <div style={{ background: resolved ? colors.greenTint : colors.redTint, borderBottom: `1px solid ${resolved ? colors.greenTintBorder : colors.redTintBorder}`, padding: '10px 22px', display: 'flex', gap: 10, alignItems: 'center' }}>
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={resolved ? colors.green : colors.red} strokeWidth={2} style={{ flexShrink: 0 }}>
          {resolved ? <><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></> : <><circle cx="12" cy="12" r="10" /><path d="M12 8v4M12 16h.01" /></>}
        </svg>
        <span style={{ fontSize: 13, fontWeight: 600, color: resolved ? colors.greenDark : '#991B1B' }}>{resolved ? 'Dispute #D-0012 · Resolved' : 'Dispute #D-0012 · Open'}</span>
        <span style={{ color: colors.borderStrong }}>·</span>
        <span style={{ fontSize: 13, color: resolved ? colors.greenDark : colors.red }}>{resolved ? 'In favor of Realtor' : 'Raised June 27, 2026 · 4 days open'}</span>
        <span style={{ fontSize: 12, color: colors.textFaint, marginLeft: 'auto' }}>{resolved ? 'Resolved June 30, 2026' : 'Needs resolution'}</span>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div className="rp-cols" style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
          {/* LEFT */}
          <div style={{ flex: 2.5, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 12 }}>
            {/* Overview */}
            <div style={card}>
              <div style={capLabel}>Dispute Overview</div>
              <div style={{ display: 'flex', border: `1px solid ${colors.border}`, borderRadius: 10, overflow: 'hidden', marginBottom: 14 }}>
                <div style={{ flex: 1, padding: '12px 14px', background: colors.redTint, borderRight: `1px solid ${colors.redTintBorder}` }}>
                  <div style={softLabel}>Raised By</div>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <div style={{ width: 36, height: 36, borderRadius: 8, background: colors.surfaceMuted, border: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: colors.textMuted }}>AF</div>
                    <div><div style={{ fontSize: 13, fontWeight: 600 }}>Al Faisal Development</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>Developer</div></div>
                  </div>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 8 }}>Raised: June 27 · 2:14 PM</div>
                </div>
                <div style={{ flex: 1, padding: '12px 14px' }}>
                  <div style={softLabel}>Against</div>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <div style={{ width: 36, height: 36, borderRadius: '50%', background: colors.surfaceMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: colors.textMuted }}>AR</div>
                    <div><div style={{ fontSize: 13, fontWeight: 600 }}>Ahmed Al-Rashid 🥇</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>Gold Realtor</div></div>
                  </div>
                </div>
              </div>
              <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '12px 14px', marginBottom: 14 }}>
                <div style={softLabel}>Related Lead</div>
                <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                  {leadInfo.map(([label, value]) => (
                    <div key={label}><div style={{ fontSize: 10, color: colors.textFaint }}>{label}</div><div style={{ fontSize: 13, color: colors.textMuted, marginTop: 2 }}>{value}</div></div>
                  ))}
                </div>
                <div onClick={() => navigate('/admin/leads')} style={{ fontSize: 12, color: colors.greenDark, marginTop: 10, cursor: 'pointer' }}>View Lead →</div>
              </div>
              <div>
                <div style={{ ...softLabel, marginBottom: 10 }}>Reason for Dispute</div>
                <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '12px 14px', fontSize: 13, color: colors.textMuted, lineHeight: 1.7 }}>The realtor submitted this lead after we had already been in direct contact with this client for 3 weeks. The client was introduced to our Palm Residence project through our own marketing channels, not through the realtor. We should not be liable for this commission.</div>
              </div>
            </div>

            {/* Evidence */}
            <div style={card}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <span style={{ ...capLabel, marginBottom: 0 }}>Evidence</span><span style={{ fontSize: 11, color: colors.textFaint }}>3 files</span>
              </div>
              {evidence.map((e) => (
                <div key={e.name} onClick={() => setPreview(e.name)} style={{ display: 'flex', gap: 10, alignItems: 'center', padding: '10px 4px', margin: '0 -4px', borderBottom: `1px solid ${colors.surfaceMuted}`, cursor: 'pointer', borderRadius: 6 }}>
                  <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke={e.iconColor} strokeWidth={1.7}><path d={e.iconPath} /></svg>
                  <div style={{ flex: 1 }}><div style={{ fontSize: 13, fontWeight: 500 }}>{e.name}</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>{e.meta}</div></div>
                  <span style={{ fontSize: 11, color: colors.greenDark, border: `1px solid ${colors.greenTintBorder}`, background: colors.greenTint, borderRadius: 5, padding: '3px 8px' }}>Preview</span>
                  <span style={{ fontSize: 11, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px' }}>Download ↓</span>
                </div>
              ))}
              {preview && (
                <div style={{ border: `1px solid ${colors.border}`, borderRadius: 10, marginTop: 10, overflow: 'hidden' }}>
                  <div style={{ background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '10px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 13, fontWeight: 500 }}>{preview}</span><span onClick={() => setPreview(null)} style={{ fontSize: 16, color: colors.textFaint, cursor: 'pointer' }}>×</span>
                  </div>
                  <div style={{ height: 240, background: colors.surfaceMuted, backgroundImage: previewHatch, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ fontSize: 12, color: colors.textFaint }}>{preview.endsWith('.pdf') ? 'PDF preview' : 'Image preview'}</span>
                  </div>
                  <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, padding: '10px 14px' }}><span style={chip}>Download Original</span></div>
                </div>
              )}
            </div>

            {/* History */}
            <div style={card}>
              <div style={capLabel}>Dispute History</div>
              {history.map((h, i) => (
                <div key={i} style={{ display: 'flex', gap: 12 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <span style={{ width: 20, height: 20, borderRadius: '50%', ...circleFill[h.type] }} />
                    {!h.last && <span style={{ width: 1.5, flex: 1, background: colors.surfaceMuted, margin: '2px 0' }} />}
                  </div>
                  <div style={{ flex: 1, paddingBottom: 16 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}><span style={{ fontSize: 13, fontWeight: 500 }}>{h.label}</span><span style={{ fontSize: 11, color: colors.textFaint }}>{h.time}</span></div>
                    <div style={{ fontSize: 12, color: colors.textSoft }}>{h.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT */}
          <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 12 }}>
            {/* Status */}
            <div style={card}>
              <div style={rLabel}>Dispute Status</div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 16, fontWeight: 700, borderRadius: 8, padding: '8px 12px', color: resolved ? colors.greenDark : '#991B1B', background: resolved ? colors.greenTint : colors.redTint, border: `1px solid ${resolved ? colors.greenTintBorder : colors.redTintBorder}` }}>
                <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={resolved ? colors.green : colors.red} strokeWidth={2}>{resolved ? <><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></> : <><circle cx="12" cy="12" r="10" /><path d="M12 8v4M12 16h.01" /></>}</svg>
                {resolved ? 'Resolved ✓' : 'Open'}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 10 }}>
                {[['Dispute ID:', '#D-0012'], ['Opened:', 'June 27, 2026'], ['Days open:', resolved ? '—' : '4 days'], ['Type:', 'Developer vs Realtor']].map(([l, v]) => (
                  <div key={l} style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 11, color: colors.textFaint }}>{l}</span><span style={{ fontSize: 12, color: colors.textMuted }}>{v}</span></div>
                ))}
              </div>
            </div>

            {/* Context */}
            <div style={card}>
              <div style={rLabel}>Lead Context</div>
              {ctx.map((c) => (
                <div key={c.label} style={{ display: 'flex', gap: 8, padding: '6px 0', alignItems: 'flex-start' }}>
                  <span style={{ width: 6, height: 6, borderRadius: '50%', background: colors.green, marginTop: 5, flexShrink: 0 }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 11, color: colors.textMuted, fontWeight: 500 }}>{c.label}</span><span style={{ fontSize: 11, color: colors.textFaint }}>{c.date}</span></div>
                    {c.sub && <div style={{ fontSize: 11, color: colors.textSoft, marginTop: 1 }}>{c.sub}</div>}
                  </div>
                </div>
              ))}
              <div onClick={() => navigate('/admin/leads')} style={{ fontSize: 12, color: colors.greenDark, marginTop: 10, cursor: 'pointer' }}>View Full Lead →</div>
            </div>

            {/* Notes */}
            <div style={card} className="wa-form">
              <div style={{ ...rLabel, marginBottom: 10 }}>Review Notes</div>
              <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '10px 12px', marginBottom: 10 }}>
                <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 4 }}>Admin note · Jun 28 9:15 AM</div>
                <div style={{ fontSize: 12, color: colors.textMuted, lineHeight: 1.5 }}>Evidence shows realtor was first point of contact on June 20.</div>
              </div>
              <textarea placeholder="Add a review note…" style={{ width: '100%', height: 70, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, fontFamily: 'inherit', resize: 'none' }} />
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}><span style={{ ...chip, height: 28, lineHeight: '26px', padding: '0 10px' }}>Save Note</span></div>
            </div>

            {/* Resolution / Resolved */}
            {!resolved ? (
              <div style={card} className="wa-form">
                <div style={rLabel}>Resolve Dispute</div>
                <div style={{ fontSize: 12, color: colors.textMuted, marginBottom: 10 }}>Select the resolution:</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div onClick={() => setChoice('realtor')} style={optStyle(choice === 'realtor')}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><span style={radio(choice === 'realtor')} /><span style={{ fontSize: 13, fontWeight: 600 }}>In favor of Realtor</span></div>
                    <div style={{ fontSize: 11, color: colors.textSoft, marginTop: 6, marginLeft: 24 }}>Commission stands. Ahmed Al-Rashid receives SAR 22,950.</div>
                  </div>
                  <div onClick={() => setChoice('dev')} style={optStyle(choice === 'dev')}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><span style={radio(choice === 'dev')} /><span style={{ fontSize: 13, fontWeight: 600 }}>In favor of Developer</span></div>
                    <div style={{ fontSize: 11, color: colors.textSoft, marginTop: 6, marginLeft: 24 }}>Commission cancelled. Al Faisal Development is not charged.</div>
                  </div>
                </div>
                <div style={{ marginTop: 12 }}>
                  <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Resolution note (sent to both parties):</div>
                  <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Explain the decision…" style={{ width: '100%', height: 80, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, fontFamily: 'inherit', resize: 'none' }} />
                </div>
                <button onClick={() => canResolve && setConfirmOpen(true)} disabled={!canResolve} style={{ width: '100%', height: 36, marginTop: 12, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', background: canResolve ? colors.green : colors.textFaint, cursor: canResolve ? 'pointer' : 'not-allowed' }}>Resolve Dispute</button>
              </div>
            ) : (
              <div style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 12, padding: '14px 16px' }}>
                <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2} style={{ marginBottom: 8 }}><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></svg>
                <div style={{ fontSize: 13, fontWeight: 600, color: colors.greenDark, marginBottom: 4 }}>Resolved · June 30, 2026</div>
                <div style={{ background: '#fff', border: `1px solid ${colors.greenTintBorder}`, borderRadius: 8, padding: '10px 12px', marginBottom: 10 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{choice === 'dev' ? 'In favor of Developer' : 'In favor of Realtor'}</div>
                  <div style={{ fontSize: 12, color: colors.textSoft, marginTop: 3 }}>{choice === 'dev' ? 'Al Faisal Development · commission cancelled' : 'Ahmed Al-Rashid · SAR 22,950 disbursed'}</div>
                </div>
                <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 4 }}>Resolution note:</div>
                <div style={{ fontSize: 12, color: colors.textMuted, lineHeight: 1.5 }}>{note || 'Evidence shows realtor was the first point of contact with this client. Commission stands.'}</div>
                <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 8 }}>Resolved by Super Admin</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Confirm modal */}
      {confirmOpen && (
        <div onClick={() => setConfirmOpen(false)} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px', maxWidth: 440, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}><span style={{ fontSize: 14, fontWeight: 600 }}>Resolve dispute?</span><span onClick={() => setConfirmOpen(false)} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 8, padding: '12px 14px', marginBottom: 14 }}>
              <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 4 }}>Decision:</div>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>{decisionText}</div>
              <div style={{ fontSize: 12, color: colors.textMuted }}>{detailText}</div>
            </div>
            <div style={{ display: 'flex', gap: 6, alignItems: 'flex-start', marginBottom: 14 }}>
              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8} style={{ flexShrink: 0, marginTop: 2 }}><path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM22 6l-10 7L2 6" /></svg>
              <span style={{ fontSize: 12, color: colors.textSoft, lineHeight: 1.5 }}>Both parties will be notified by email with the resolution note.</span>
            </div>
            <div style={{ fontSize: 12, color: colors.amber, marginBottom: 14 }}>This decision is final and cannot be reversed.</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}><button onClick={() => setConfirmOpen(false)} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Cancel</button><button onClick={confirmResolve} style={{ height: 34, padding: '0 14px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Confirm Resolution</button></div>
          </div>
        </div>
      )}

      {/* Success toast */}
      {toast && (
        <div style={{ position: 'fixed', right: 22, bottom: 22, zIndex: 60, background: '#fff', border: `1px solid ${colors.greenTintBorder}`, borderRadius: 10, padding: '12px 14px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', display: 'flex', gap: 10, alignItems: 'center' }}>
          <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2}><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></svg>
          <span style={{ fontSize: 13, fontWeight: 500 }}>Dispute #D-0012 resolved. Both parties notified.</span>
        </div>
      )}
    </>
  )
}
