import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { Topbar } from '../../components/layout/Topbar'

const card = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 18px', marginBottom: 12 }
const sectionLabel = { fontSize: 9, fontWeight: 700, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 14 }
const rLabel = { fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }
const fieldLabel = { fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 2 }
const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 9px)'
const pendBadge = { background: '#FEF9EC', border: '1px solid #F3E2B8', color: '#92400E' }

const profileInfo = [
  { d: 'M12 22s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11z', value: 'Jeddah, Saudi Arabia' },
  { d: 'M4 22V4h12l-2 4 2 4H4', value: 'Saudi Arabia 🇸🇦' },
  { d: 'M20 7h-4V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM10 5h4v2h-4z', value: 'Al-Rashid Real Estate' },
  { d: 'M3 5h18v14H3zM3 7l9 6 9-6', value: 'ahmed@gmail.com' },
  { d: 'M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.6A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.4-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z', value: '+966 50 123 4567' },
]

const stats = [
  { value: '48', label: 'Total Leads' },
  { value: '8', label: 'Deals Closed' },
  { value: '16.7%', label: 'Conversion' },
  { value: 'SAR 139k', label: 'Total Earned' },
]

const personal = [
  { label: 'Full Name', value: 'Ahmed Mohammed Al-Rashid' },
  { label: 'Country', value: 'Saudi Arabia 🇸🇦' },
  { label: 'City', value: 'Jeddah' },
  { label: 'Iqama / ID', value: '2XXXXXXXX4', locked: true },
  { label: 'Languages', value: 'Arabic, English, Urdu' },
  { label: 'Agency', value: 'Al-Rashid Real Estate' },
  { label: 'Experience', value: '5–10 years' },
  { label: 'Specialization', value: 'Apartments · Villas' },
  { label: 'WhatsApp', value: '+966 50 123 4567' },
]

const license = [
  { label: 'License Type', value: 'FAL License', color: colors.textMuted },
  { label: 'License Number', value: 'FAL-2024-78923', color: colors.textMuted },
  { label: 'Expiry Date', value: 'December 2026', color: colors.greenDark },
  { label: 'REGA Verified', value: 'Yes ✓', color: colors.green },
  { label: 'Applied', value: 'January 15, 2026', color: colors.textMuted },
  { label: 'Approved by', value: 'Admin · January 16, 2026', color: colors.textMuted },
]

const docs = [
  { name: 'Profile Photo', meta: 'JPG · 0.8 MB · Uploaded Jan 15', isPhoto: true, short: 'Profile Photo.jpg' },
  { name: 'FAL License Document', meta: '2.1 MB · PDF · Uploaded Jan 15', isPhoto: false, short: 'FAL License.pdf' },
  { name: 'Iqama / National ID', meta: '1.4 MB · PDF · Uploaded Jan 15', isPhoto: false, short: 'Iqama ID.pdf' },
]

const performance = [
  { project: 'Palm Residence', leads: '24', deals: '3', conv: '12.5%' },
  { project: 'Al Noor Tower', leads: '14', deals: '3', conv: '21.4%' },
  { project: 'Marina Heights', leads: '10', deals: '2', conv: '20%' },
]

const inputStyle = { width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 13, fontFamily: 'inherit', color: colors.textMuted, background: '#fff' }
const modalShell = { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }
const modalCardBase = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px', width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)' }
const btnGhost = { height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }

export default function AdminRealtorReview() {
  const navigate = useNavigate()
  const [previewIdx, setPreviewIdx] = useState(null)
  const [modal, setModal] = useState(null) // approve | reject | suspend | badge
  const [rejectReason, setRejectReason] = useState('')
  const [badge, setBadge] = useState('🥇 Gold')

  const badgeChanged = badge !== '🥇 Gold'
  const badgeClean = badge.replace(/[^A-Za-z ]/g, '').trim()
  const close = () => setModal(null)
  const pv = previewIdx != null ? docs[previewIdx] : null

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span onClick={() => navigate('/admin/realtors')} style={{ fontSize: 13, color: colors.textFaint, cursor: 'pointer' }}>Realtors</span>
            <Icon name="chevronRight" size={14} color={colors.borderStrong} strokeWidth={2} />
            <span style={{ fontSize: 13, fontWeight: 500 }}>Ahmed Al-Rashid</span>
          </div>
        }
        actions={<button onClick={() => navigate('/admin/realtors')} style={btnGhost}>← Back to list</button>}
      />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div className="rp-cols" style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
          {/* LEFT */}
          <div style={{ flex: 2.5, minWidth: 0 }}>
            {/* Profile */}
            <div style={{ ...card, padding: '16px 18px' }}>
              <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                <div style={{ width: 80, height: 80, borderRadius: '50%', background: colors.surfaceMuted, border: `1px solid ${colors.border}`, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 700, color: colors.textMuted }}>AR</div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 4 }}>
                    <span style={{ fontSize: 18, fontWeight: 700, letterSpacing: '-0.02em' }}>Ahmed Al-Rashid</span>
                    <span style={{ ...pendBadge, borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 700 }}>Pending Review</span>
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                    <span style={{ fontSize: 16 }}>🥇</span>
                    <span style={{ fontSize: 13, fontWeight: 500, color: colors.greenDark }}>Gold Realtor</span>
                    <span style={{ fontSize: 10, color: colors.borderStrong }}>·</span>
                    <span style={{ fontSize: 12, color: colors.textFaint }}>Member since Jan 2026</span>
                  </div>
                  <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                    {profileInfo.map((p) => (
                      <span key={p.value} style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
                        <svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.7}><path d={p.d} /></svg>
                        <span style={{ fontSize: 12, color: colors.textMuted }}>{p.value}</span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <div style={{ display: 'flex', marginTop: 14, paddingTop: 14, borderTop: `1px solid ${colors.surfaceMuted}` }}>
                {stats.map((st, i) => (
                  <div key={st.label} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', borderRight: i < stats.length - 1 ? `1px solid ${colors.surfaceMuted}` : 'none' }}>
                    <div style={{ fontSize: 18, fontWeight: 700 }}>{st.value}</div>
                    <div style={{ fontSize: 10, color: colors.textFaint, marginTop: 3 }}>{st.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Personal info */}
            <div style={card}>
              <div style={sectionLabel}>Personal Information</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px 16px' }}>
                {personal.map((f) => (
                  <div key={f.label}>
                    <div style={fieldLabel}>{f.label}</div>
                    <div style={{ fontSize: 13, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 4 }}>
                      {f.value}
                      {f.locked && (
                        <>
                          <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8}><rect x="4" y="11" width="16" height="9" rx="2" /><path d="M8 11V7a4 4 0 0 1 8 0v4" /></svg>
                          <span style={{ fontSize: 10, color: colors.textFaint }}>Encrypted</span>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* License */}
            <div style={card}>
              <div style={sectionLabel}>License &amp; Credentials</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px 16px' }}>
                {license.map((f) => (
                  <div key={f.label}>
                    <div style={fieldLabel}>{f.label}</div>
                    <div style={{ fontSize: 13, color: f.color }}>{f.value}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Documents */}
            <div style={card}>
              <div style={{ ...sectionLabel, marginBottom: 8 }}>Documents</div>
              {docs.map((doc, i) => (
                <div key={doc.name} style={{ padding: '12px 0', borderBottom: `1px solid ${colors.surfaceMuted}`, display: 'flex', gap: 12, alignItems: 'center' }}>
                  <div style={{ flex: 1, display: 'flex', gap: 10, alignItems: 'center' }}>
                    {doc.isPhoto ? (
                      <span style={{ width: 40, height: 40, borderRadius: 6, background: colors.surfaceMuted, border: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: colors.textMuted }}>AR</span>
                    ) : (
                      <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.6} style={{ flexShrink: 0 }}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></svg>
                    )}
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{doc.name}</div>
                      <div style={{ fontSize: 11, color: colors.textFaint }}>{doc.meta}</div>
                    </div>
                  </div>
                  <span style={{ background: colors.greenTint, color: colors.greenDark, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 999, padding: '2px 8px', fontSize: 10, fontWeight: 600 }}>Verified ✓</span>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <span onClick={() => setPreviewIdx(previewIdx === i ? null : i)} style={{ display: 'flex', gap: 4, alignItems: 'center', fontSize: 11, color: colors.greenDark, border: `1px solid ${colors.greenTintBorder}`, background: colors.greenTint, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>
                      <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.greenDark} strokeWidth={1.8}><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z" /><circle cx="12" cy="12" r="3" /></svg>Preview
                    </span>
                    <span style={{ fontSize: 11, color: colors.textMuted, border: `1px solid ${colors.border}`, background: '#fff', borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>Download ↓</span>
                  </div>
                </div>
              ))}
              {pv && (
                <div style={{ marginTop: 10, background: colors.surfaceAlt, border: `1px solid ${colors.border}`, borderRadius: 10, overflow: 'hidden' }}>
                  <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '8px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={{ fontSize: 12, color: colors.textMuted }}>Page 1 of 2</span>
                      <span style={{ fontSize: 12, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>← Prev</span>
                      <span style={{ fontSize: 12, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>Next →</span>
                    </div>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <span style={{ fontSize: 12, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>−</span>
                      <span style={{ fontSize: 12, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>+</span>
                      <span style={{ fontSize: 12, color: colors.textMuted, cursor: 'pointer' }}>Download ↓</span>
                    </div>
                  </div>
                  <div style={{ height: 300, background: colors.surfaceMuted, backgroundImage: hatch, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ fontSize: 13, color: colors.textFaint, background: 'rgba(249,250,251,0.9)', padding: '6px 12px', borderRadius: 6 }}>Preview — {pv.short}</span>
                  </div>
                  <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, padding: '8px 12px', display: 'flex', justifyContent: 'flex-end' }}>
                    <button style={{ height: 30, padding: '0 12px', background: colors.green, border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
                      <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2.5}><path d="M20 6L9 17l-5-5" /></svg>Mark as Verified
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Performance */}
            <div style={{ ...card, marginBottom: 0 }}>
              <div style={sectionLabel}>Performance</div>
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 6, paddingBottom: 8, borderBottom: `1px solid ${colors.surfaceMuted}`, fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                <span>Project</span><span>Leads</span><span>Deals</span><span>Conv. %</span>
              </div>
              {performance.map((p) => (
                <div key={p.project} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 6, padding: '10px 0', borderBottom: `1px solid ${colors.surfaceMuted}`, fontSize: 13, color: colors.textMuted }}>
                  <span>{p.project}</span><span>{p.leads}</span><span>{p.deals}</span><span>{p.conv}</span>
                </div>
              ))}
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 6, paddingTop: 10, fontSize: 13, fontWeight: 600 }}>
                <span>Total</span><span>48</span><span>8</span><span>16.7%</span>
              </div>
            </div>
          </div>

          {/* RIGHT */}
          <div style={{ flex: 1, minWidth: 240 }}>
            {/* Account status */}
            <div style={card}>
              <div style={rLabel}>Account Status</div>
              <div style={{ background: '#FEF9EC', border: '1px solid #F3E2B8', borderRadius: 8, padding: '8px 12px', display: 'flex', gap: 8, alignItems: 'center' }}>
                <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>
                <span style={{ fontSize: 18, fontWeight: 700, color: '#92400E' }}>Pending Review</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 10 }}>
                {[['Applied', 'Jan 15, 2026'], ['Approved', 'Jan 16, 2026'], ['Last active', '2 hours ago']].map(([l, v]) => (
                  <div key={l} style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 11, color: colors.textFaint }}>{l}</span><span style={{ fontSize: 12, color: colors.textMuted }}>{v}</span></div>
                ))}
              </div>
            </div>

            {/* Badge management */}
            <div style={card} className="wa-form">
              <div style={rLabel}>Badge Management</div>
              <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 12 }}>
                <span style={{ fontSize: 20 }}>🥇</span>
                <div><div style={{ fontSize: 13, fontWeight: 600 }}>Gold Realtor</div><div style={{ fontSize: 11, color: colors.textFaint }}>Auto-calculated (8 deals)</div></div>
              </div>
              <div style={{ fontSize: 12, color: colors.textMuted, marginBottom: 6 }}>Manual override:</div>
              <select value={badge} onChange={(e) => setBadge(e.target.value)} style={inputStyle}>
                <option>🥉 Bronze</option><option>🥈 Silver</option><option>🥇 Gold</option><option>💎 Platinum</option>
              </select>
              {badgeChanged && (
                <div>
                  <textarea placeholder="Reason for manual override..." style={{ width: '100%', height: 60, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 12, fontFamily: 'inherit', resize: 'none', marginTop: 8 }} />
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                    <button onClick={() => setModal('badge')} style={{ height: 30, padding: '0 12px', background: '#fff', border: `1px solid ${colors.green}`, borderRadius: 6, fontSize: 12, fontWeight: 600, color: colors.greenDark, fontFamily: 'inherit', cursor: 'pointer' }}>Save Override</button>
                  </div>
                </div>
              )}
              <div style={{ marginTop: 12, paddingTop: 12, borderTop: `1px solid ${colors.surfaceMuted}` }}>
                <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 6 }}>Previous overrides</div>
                <div style={{ fontSize: 12, color: colors.textSoft }}>No manual overrides</div>
              </div>
            </div>

            {/* Internal notes */}
            <div style={card} className="wa-form">
              <div style={rLabel}>Internal Notes</div>
              <textarea placeholder="Add internal notes..." style={{ width: '100%', height: 90, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', resize: 'none' }} />
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                <button style={{ height: 30, padding: '0 12px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Save Note</button>
              </div>
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <button onClick={() => setModal('approve')} style={{ height: 36, background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2.5}><path d="M20 6L9 17l-5-5" /></svg>Approve &amp; Send Credentials
              </button>
              <button onClick={() => setModal('reject')} style={{ height: 36, background: '#fff', border: `1px solid ${colors.redTintBorder}`, borderRadius: 8, fontSize: 13, fontWeight: 600, color: colors.red, fontFamily: 'inherit', cursor: 'pointer' }}>Reject with Reason</button>
              <button onClick={() => setModal('suspend')} style={{ height: 36, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Suspend Account</button>
              <button onClick={() => navigate('/admin/leads')} style={{ height: 36, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>View All Leads →</button>
              <button onClick={() => navigate('/admin/commissions')} style={{ height: 36, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>View Payout History →</button>
            </div>
          </div>
        </div>
      </div>

      {/* MODALS */}
      {modal === 'approve' && (
        <div onClick={close} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={{ ...modalCardBase, maxWidth: 420 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}><span style={{ fontSize: 14, fontWeight: 600 }}>Approve realtor account</span><span onClick={close} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 8, padding: '10px 12px', marginBottom: 14, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.8} style={{ flexShrink: 0, marginTop: 1 }}><circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" /></svg>
              <div><div style={{ fontSize: 12, color: colors.textMuted, marginBottom: 4 }}>Credentials will be emailed to:</div><div style={{ fontSize: 13, fontWeight: 600 }}>ahmed@gmail.com</div><div style={{ fontSize: 12, color: colors.textSoft, marginTop: 4 }}>A temporary password will be included. Expires in 24 hours.</div></div>
            </div>
            <div style={{ fontSize: 13, color: colors.textMuted, marginBottom: 16 }}>Ahmed Al-Rashid will receive login credentials at ahmed@gmail.com.</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}><button onClick={close} style={btnGhost}>Cancel</button><button onClick={() => { close(); navigate('/admin/realtors') }} style={{ height: 34, padding: '0 14px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Approve &amp; Send Email</button></div>
          </div>
        </div>
      )}

      {modal === 'reject' && (
        <div onClick={close} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={{ ...modalCardBase, maxWidth: 420 }} className="wa-form">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}><div><div style={{ fontSize: 14, fontWeight: 600 }}>Reject application</div><div style={{ fontSize: 12, color: colors.textFaint, marginTop: 4 }}>Ahmed Al-Rashid</div></div><span onClick={close} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Rejection reason *</div>
            <textarea value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} placeholder="e.g. License could not be verified with REGA." style={{ width: '100%', height: 90, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, fontFamily: 'inherit', resize: 'none' }} />
            <div style={{ fontSize: 11, color: colors.textFaint, fontStyle: 'italic', marginTop: 6 }}>This reason will be emailed to the applicant</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 14 }}>
              <button onClick={close} style={btnGhost}>Cancel</button>
              <button disabled={!rejectReason.trim()} onClick={() => { close(); navigate('/admin/realtors') }} style={{ height: 34, padding: '0 14px', border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', background: rejectReason.trim() ? colors.red : '#F3B4B4', cursor: rejectReason.trim() ? 'pointer' : 'not-allowed' }}>Reject &amp; Notify</button>
            </div>
          </div>
        </div>
      )}

      {modal === 'suspend' && (
        <div onClick={close} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={{ ...modalCardBase, maxWidth: 420 }} className="wa-form">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}><span style={{ fontSize: 14, fontWeight: 600 }}>Suspend account</span><span onClick={close} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ background: colors.redTint, border: `1px solid ${colors.redTintBorder}`, borderRadius: 8, padding: '10px 12px', marginBottom: 14, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.red} strokeWidth={1.8} style={{ flexShrink: 0, marginTop: 1 }}><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" /><path d="M12 9v4M12 17h.01" /></svg>
              <span style={{ fontSize: 13, color: '#991B1B', lineHeight: 1.6 }}>Realtor will be logged out immediately. Any pending commissions are unaffected.</span>
            </div>
            <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Reason (emailed to realtor):</div>
            <textarea placeholder="Reason for suspension..." style={{ width: '100%', height: 70, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, fontFamily: 'inherit', resize: 'none' }} />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 14 }}><button onClick={close} style={btnGhost}>Cancel</button><button onClick={close} style={{ height: 34, padding: '0 14px', background: colors.red, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Suspend Account</button></div>
          </div>
        </div>
      )}

      {modal === 'badge' && (
        <div onClick={close} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={{ ...modalCardBase, maxWidth: 400 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}><span style={{ fontSize: 14, fontWeight: 600 }}>Change badge to {badgeClean}?</span><span onClick={close} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '10px 12px', marginBottom: 12 }}><div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 2 }}>Reason</div><div style={{ fontSize: 13, color: colors.textMuted }}>Exceptional performance — 10 deals</div></div>
            <div style={{ fontSize: 13, color: colors.textMuted, marginBottom: 16 }}>This overrides auto-calculation.</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}><button onClick={close} style={btnGhost}>Cancel</button><button onClick={close} style={{ height: 34, padding: '0 14px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Confirm Override</button></div>
          </div>
        </div>
      )}
    </>
  )
}
