import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { AdminTopbar, AdminTabs, AdminSearchBar, Pagination, StatusPill } from './AdminTableKit'

const tabs = [['All', 92], ['Pending', 6], ['Processing', 4], ['Paid', 82]]
const rows = [
  { id: 'WS-084', project: 'Palm Residence · 2BR', realtor: 'Ahmed Al-Rashid', developer: 'Al Faisal Development', amount: 'SAR 27,000', fee: 'SAR 4,050', date: 'Jun 20', status: 'Pending' },
  { id: 'WS-081', project: 'Coral Bay · 1BR', realtor: 'Ahmed Al-Rashid', developer: 'Emaar KSA', amount: 'SAR 28,800', fee: 'SAR 4,320', date: 'Jun 12', status: 'Processing' },
  { id: 'WS-079', project: 'The Vantage · 1BR', realtor: 'Sara Abdullah', developer: 'Rakeen Estates', amount: 'SAR 10,800', fee: 'SAR 1,620', date: 'Jun 08', status: 'Paid' },
  { id: 'WS-072', project: 'Jade Gardens · Villa', realtor: 'Noura Al-Mutairi', developer: 'Rakeen Estates', amount: 'SAR 63,000', fee: 'SAR 9,450', date: 'May 22', status: 'Paid' },
  { id: 'WS-066', project: 'Al Noor Tower · 2BR', realtor: 'Bilal Khan', developer: 'Al Faisal Development', amount: 'SAR 29,400', fee: 'SAR 4,410', date: 'May 04', status: 'Paid' },
]

export default function AdminCommissions() {
  const navigate = useNavigate()
  const [tab, setTab] = useState('All')
  return (
    <>
      <AdminTopbar title="Commissions" total={92} />
      <AdminTabs tabs={tabs} active={tab} onChange={setTab} />
      <AdminSearchBar placeholder="Search by deal, realtor or developer..." filters={['Developer', 'Status']} />
      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg }}>
        <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', margin: '16px 22px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '0.7fr 1.5fr 1.2fr 1fr 1fr 0.9fr', background: colors.bg, borderBottom: `1px solid ${colors.border}`, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            <span style={{ padding: '9px 16px' }}>Deal</span><span style={{ padding: '9px 8px' }}>Project</span><span style={{ padding: '9px 8px' }}>Realtor</span><span style={{ padding: '9px 8px' }}>Commission</span><span style={{ padding: '9px 8px' }}>Platform fee</span><span style={{ padding: '9px 8px' }}>Status</span>
          </div>
          {rows.map((r) => (
            <div key={r.id} onClick={() => navigate('/admin/commissions/' + r.id)} style={{ display: 'grid', gridTemplateColumns: '0.7fr 1.5fr 1.2fr 1fr 1fr 0.9fr', borderBottom: `1px solid ${colors.surfaceMuted}`, alignItems: 'center', cursor: 'pointer' }}>
              <span style={{ padding: '11px 16px', fontSize: 12, color: colors.textFaint }}>#{r.id}</span>
              <span style={{ padding: '11px 8px', fontSize: 13, fontWeight: 500 }}>{r.project}</span>
              <span style={{ padding: '11px 8px', fontSize: 12, color: colors.textMuted }}>{r.realtor}</span>
              <span style={{ padding: '11px 8px', fontSize: 13, fontWeight: 600 }}>{r.amount}</span>
              <span style={{ padding: '11px 8px', fontSize: 12, color: colors.green }}>{r.fee}</span>
              <span style={{ padding: '11px 8px' }}><StatusPill status={r.status} /></span>
            </div>
          ))}
        </div>
        <Pagination label="Showing 1–10 of 92 commissions" />
      </div>
    </>
  )
}
