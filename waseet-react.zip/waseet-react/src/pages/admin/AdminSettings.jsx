import React, { useState } from 'react'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const settingsNav = [
  { id: 'commission', label: 'Commission', d: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 7v10' },
  { id: 'email', label: 'Email settings', d: 'M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM22 6l-10 7L2 6' },
  { id: 'security', label: 'Security', d: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z' },
  { id: 'info', label: 'Platform info', d: 'M3 21h18M5 21V7l8-4v18M19 21V11l-6-4' },
  { id: 'danger', label: 'Danger zone', d: 'M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01' },
]

const overrides = [
  { name: 'Al Faisal Development', pct: '20', since: 'June 1, 2026' },
  { name: 'Marina Corp', pct: '12', since: 'May 15, 2026' },
  { name: 'Emerald Builders', pct: '18', since: 'Apr 20, 2026' },
]

const emailFields = [
  { label: 'From email (no-reply)', desc: 'All platform emails sent from this address', value: 'noreply@waseet.io', placeholder: '' },
  { label: 'Support email', desc: 'Shown to users for support inquiries', value: 'support@waseet.io', placeholder: '' },
  { label: 'Admin alert email', desc: 'Receives critical alerts and system notifications', value: 'admin@waseet.io', placeholder: '' },
  { label: 'Emergency backup email', desc: 'Secondary contact for critical issues', value: '', placeholder: 'backup@waseet.io' },
]

const mailIcon = 'M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM22 6l-10 7L2 6'
const chevronDownD = 'M6 9l6 6 6-6'

function LockIcon() {
  return (
    <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8}>
      <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  )
}

function FixedOnToggle() {
  return (
    <span style={{ position: 'relative', width: 36, height: 20, background: colors.green, opacity: 0.6, borderRadius: 999, display: 'inline-block' }}>
      <span style={{ position: 'absolute', top: 2, right: 2, width: 16, height: 16, background: '#fff', borderRadius: '50%', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }} />
    </span>
  )
}

export default function AdminSettings() {
  const [section, setSection] = useState('commission')
  const [saveState, setSaveState] = useState('idle') // idle | saving | saved
  const [toast, setToast] = useState(false)
  const [maint, setMaint] = useState(false)
  const [maintModal, setMaintModal] = useState(false)

  const save = () => {
    if (saveState === 'saving') return
    setSaveState('saved'); setToast(true)
    setTimeout(() => { setSaveState('idle'); setToast(false) }, 3000)
  }
  const toggleMaint = () => { if (!maint) setMaintModal(true); else setMaint(false) }
  const cancelMaint = () => setMaintModal(false)
  const confirmMaint = () => { setMaint(true); setMaintModal(false) }

  const saveLabel = saveState === 'saved' ? 'Saved ✓' : 'Save'
  const saveBtnStyle = {
    height: 32, padding: '0 14px', borderRadius: 7, fontSize: 12, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer',
    ...(saveState === 'saved'
      ? { background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, color: colors.greenDark }
      : { background: colors.green, border: 'none', color: '#fff' }),
  }

  return (
    <>
      <style>{`@keyframes pulse-dot { 0%,100% { opacity: 1; } 50% { opacity: 0.35; } }`}</style>
      <Topbar
        title="Platform Settings"
        right={<span style={{ fontSize: 11, color: colors.textFaint }}>Last saved: June 28 · 9:32 AM</span>}
      />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>

          {/* SETTINGS NAV */}
          <div style={{ width: 200, flexShrink: 0, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '10px 8px', position: 'sticky', top: 0 }}>
            {settingsNav.map((n) => {
              const on = section === n.id
              return (
                <div key={n.id} onClick={() => setSection(n.id)} style={{ display: 'flex', gap: 8, alignItems: 'center', padding: '8px 12px', borderRadius: 8, cursor: 'pointer', marginBottom: 1, fontSize: 12, ...(on ? { background: colors.greenTint, color: colors.greenDark } : { color: colors.textMuted }) }}>
                  <svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke={on ? colors.green : colors.textFaint} strokeWidth={1.7}><path d={n.d} /></svg>
                  <span>{n.label}</span>
                </div>
              )
            })}
          </div>

          {/* CONTENT */}
          <div style={{ flex: 1, minWidth: 0 }}>

            {/* COMMISSION */}
            {section === 'commission' && (
              <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                  <span style={{ fontSize: 15, fontWeight: 600 }}>Commission settings</span>
                  <button onClick={save} style={saveBtnStyle}>{saveLabel}</button>
                </div>
                <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 18 }}>Platform commission rates and overrides.</div>
                <div style={{ paddingBottom: 16, borderBottom: `1px solid ${colors.surfaceMuted}`, marginBottom: 16 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: colors.textMuted, marginBottom: 4 }}>Global default commission</div>
                  <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 12 }}>Applied to all new developers unless overridden individually.</div>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <span style={{ fontSize: 12, color: colors.textMuted }}>Platform takes:</span>
                    <input defaultValue="15" style={{ width: 80, height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 8px', fontSize: 14, fontWeight: 600, textAlign: 'right', fontFamily: 'inherit' }} />
                    <span style={{ fontSize: 12, color: colors.textMuted }}>% of developer commission</span>
                    <button onClick={save} style={{ marginLeft: 'auto', height: 30, padding: '0 10px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Save default</button>
                  </div>
                  <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '10px 12px', marginTop: 10 }}>
                    <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 6 }}>Example: If developer commission = SAR 27,000</div>
                    <div style={{ display: 'flex', gap: 20 }}>
                      <span style={{ fontSize: 12, color: colors.textMuted }}>Platform earns: <span style={{ color: colors.textMuted }}>SAR 4,050</span></span>
                      <span style={{ fontSize: 12, color: colors.textMuted }}>Realtor receives: <span style={{ fontWeight: 600 }}>SAR 22,950</span></span>
                    </div>
                  </div>
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, color: colors.textMuted, marginBottom: 4 }}>Per-developer overrides</div>
                <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 12 }}>These override the global default for specific developers.</div>
                <div style={{ border: `1px solid ${colors.border}`, borderRadius: 10, overflow: 'hidden' }}>
                  <div style={{ background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 12 }}>
                    <span style={{ flex: 2, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Developer</span>
                    <span style={{ flex: 1, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Override %</span>
                    <span style={{ flex: 1, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Applied since</span>
                    <span style={{ width: 70, textAlign: 'right', fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Remove</span>
                  </div>
                  {overrides.map((o, i) => (
                    <div key={i} style={{ padding: '10px 14px', borderBottom: `1px solid ${colors.surfaceMuted}`, display: 'flex', alignItems: 'center', gap: 12 }}>
                      <span style={{ flex: 2, fontSize: 13, color: colors.textMuted }}>{o.name}</span>
                      <span style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 4 }}>
                        <input defaultValue={o.pct} style={{ width: 60, height: 30, border: `1px solid ${colors.border}`, borderRadius: 6, padding: '0 8px', fontSize: 13, textAlign: 'right', fontFamily: 'inherit' }} />
                        <span style={{ fontSize: 12, color: colors.textMuted }}>%</span>
                      </span>
                      <span style={{ flex: 1, fontSize: 11, color: colors.textFaint }}>{o.since}</span>
                      <span style={{ width: 70, textAlign: 'right', fontSize: 11, color: colors.red, cursor: 'pointer' }}>Remove ×</span>
                    </div>
                  ))}
                  <div style={{ padding: '10px 14px', borderTop: `1px solid ${colors.surfaceMuted}`, display: 'flex', gap: 8, alignItems: 'center' }}>
                    <input placeholder="Search developer..." style={{ flex: 1, height: 30, border: `1px solid ${colors.border}`, borderRadius: 6, padding: '0 10px', fontSize: 11, fontFamily: 'inherit' }} />
                    <input placeholder="%" style={{ width: 60, height: 30, border: `1px solid ${colors.border}`, borderRadius: 6, padding: '0 8px', fontSize: 13, textAlign: 'right', fontFamily: 'inherit' }} />
                    <span style={{ height: 28, padding: '0 10px', background: colors.green, borderRadius: 6, fontSize: 11, fontWeight: 600, color: '#fff', display: 'flex', alignItems: 'center', cursor: 'pointer' }}>+ Add</span>
                  </div>
                </div>
              </div>
            )}

            {/* EMAIL */}
            {section === 'email' && (
              <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                  <span style={{ fontSize: 15, fontWeight: 600 }}>Email settings</span>
                  <button onClick={save} style={saveBtnStyle}>{saveLabel}</button>
                </div>
                <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 18 }}>Platform email addresses for notifications and support.</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {emailFields.map((f, i) => (
                    <div key={i}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: colors.textMuted }}>{f.label}</div>
                      <div style={{ fontSize: 11, color: colors.textFaint, margin: '2px 0 6px' }}>{f.desc}</div>
                      <div style={{ display: 'flex', gap: 8 }}>
                        <div style={{ flex: 1, position: 'relative' }}>
                          <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}><path d={mailIcon} /></svg>
                          <input defaultValue={f.value} placeholder={f.placeholder} style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 13, fontFamily: 'inherit' }} />
                        </div>
                        <span style={{ height: 34, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>Save</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${colors.surfaceMuted}`, display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span style={{ fontSize: 12, color: colors.textMuted }}>Test platform emails:</span>
                  <input placeholder="your@email.com" style={{ flex: 1, height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 12, fontFamily: 'inherit' }} />
                  <span style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>Send test email</span>
                </div>
              </div>
            )}

            {/* SECURITY */}
            {section === 'security' && (
              <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px' }}>
                <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Security settings</div>
                <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 18 }}>Platform-wide security configuration.</div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>Max failed login attempts</div>
                    <div style={{ fontSize: 11, color: colors.textFaint }}>Lock account after X failed attempts</div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    <input defaultValue="5" style={{ width: 70, height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, textAlign: 'center', fontSize: 13, fontFamily: 'inherit' }} />
                    <span style={{ height: 28, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 11, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', marginLeft: 8, background: '#fff' }}>Save</span>
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>Account lockout duration</div>
                    <div style={{ fontSize: 11, color: colors.textFaint }}>How long accounts stay locked</div>
                  </div>
                  <span style={{ height: 34, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff' }}>30 minutes <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={2}><path d={chevronDownD} /></svg></span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>Session timeout</div>
                    <div style={{ fontSize: 11, color: colors.textFaint }}>Auto-logout inactive users after</div>
                  </div>
                  <span style={{ height: 34, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff' }}>24 hours <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={2}><path d={chevronDownD} /></svg></span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>Require 2FA for admin</div>
                    <div style={{ fontSize: 11, color: colors.textFaint }}>All admin accounts must use 2FA</div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <FixedOnToggle />
                    <LockIcon />
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 0' }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>Phone reveal logging</div>
                    <div style={{ fontSize: 11, color: colors.textFaint }}>Log all phone number reveal actions</div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <FixedOnToggle />
                    <LockIcon />
                  </div>
                </div>
              </div>
            )}

            {/* PLATFORM INFO */}
            {section === 'info' && (
              <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px' }}>
                <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Platform information</div>
                <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 18 }}>Read-only platform details.</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px 16px' }}>
                  <div>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', marginBottom: 2 }}>Platform name</div>
                    <div style={{ fontSize: 13, color: colors.textMuted }}>Waseet</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', marginBottom: 2 }}>Environment</div>
                    <div style={{ fontSize: 13, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6 }}>Production <span style={{ width: 6, height: 6, borderRadius: '50%', background: colors.green, animation: 'pulse-dot 1.6s infinite' }} /><span style={{ fontSize: 10, color: colors.green }}>Live</span></div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', marginBottom: 2 }}>Version</div>
                    <div style={{ fontSize: 13, color: colors.textMuted }}>v1.0.4</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', marginBottom: 2 }}>Database region</div>
                    <div style={{ fontSize: 13, color: colors.textMuted }}>Bahrain (Middle East)</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', marginBottom: 2 }}>Last backup</div>
                    <div style={{ fontSize: 13, color: colors.textMuted }}>June 28 · 3:00 AM</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', marginBottom: 2 }}>Storage used</div>
                    <div style={{ fontSize: 13, color: colors.textMuted }}>14.2 GB / 100 GB</div>
                    <div style={{ height: 3, background: colors.surfaceMuted, borderRadius: 999, overflow: 'hidden', marginTop: 4 }}><div style={{ height: '100%', width: '14.2%', background: colors.green, borderRadius: 999 }} /></div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', marginBottom: 2 }}>API calls today</div>
                    <div style={{ fontSize: 13, color: colors.textMuted }}>12,847</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', marginBottom: 2 }}>Uptime</div>
                    <div style={{ fontSize: 13, color: colors.textMuted }}>99.98% (30 days)</div>
                  </div>
                </div>
                <div style={{ marginTop: 16, paddingTop: 16, borderTop: `1px solid ${colors.surfaceMuted}` }}>
                  <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 4 }}>Maintenance mode</div>
                  <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 10 }}>Enable to show maintenance page to all users.</div>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <span onClick={toggleMaint} style={{ position: 'relative', width: 36, height: 20, borderRadius: 999, cursor: 'pointer', display: 'inline-block', background: maint ? colors.red : colors.border }}>
                      <span style={{ position: 'absolute', top: 2, ...(maint ? { right: 2 } : { left: 2 }), width: 16, height: 16, background: '#fff', borderRadius: '50%', boxShadow: '0 1px 3px rgba(0,0,0,0.2)' }} />
                    </span>
                    {!maint && (
                      <span style={{ fontSize: 12, color: colors.green, display: 'flex', alignItems: 'center', gap: 4 }}><span style={{ width: 6, height: 6, borderRadius: '50%', background: colors.green, animation: 'pulse-dot 1.6s infinite' }} />Platform is live</span>
                    )}
                    {maint && (
                      <span style={{ fontSize: 12, color: colors.red }}>Maintenance mode active</span>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* DANGER ZONE */}
            {section === 'danger' && (
              <div style={{ background: '#fff', border: `1px solid ${colors.redTintBorder}`, borderRadius: 12, padding: '18px 20px' }}>
                <div style={{ fontSize: 15, fontWeight: 600, color: colors.red, marginBottom: 4 }}>Danger zone</div>
                <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 18 }}>These actions are irreversible. Proceed with extreme caution.</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 10, padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 2 }}>Reset commission overrides</div>
                      <div style={{ fontSize: 11, color: colors.textFaint, lineHeight: 1.4 }}>Remove all per-developer overrides. All developers revert to default 15%.</div>
                    </div>
                    <span style={{ height: 32, padding: '0 12px', border: `1px solid ${colors.redTintBorder}`, borderRadius: 7, fontSize: 11, color: colors.red, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff', flexShrink: 0 }}>Reset</span>
                  </div>
                  <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 10, padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 2 }}>Clear all announcement history</div>
                      <div style={{ fontSize: 11, color: colors.textFaint, lineHeight: 1.4 }}>Permanently delete all sent announcement records.</div>
                    </div>
                    <span style={{ height: 32, padding: '0 12px', border: `1px solid ${colors.redTintBorder}`, borderRadius: 7, fontSize: 11, color: colors.red, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff', flexShrink: 0 }}>Clear</span>
                  </div>
                  <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 10, padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 2 }}>Export all platform data</div>
                      <div style={{ fontSize: 11, color: colors.textFaint, lineHeight: 1.4 }}>Download complete platform backup including all users, leads, commissions.</div>
                    </div>
                    <span style={{ height: 32, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff', flexShrink: 0 }}>Export all</span>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      </div>

      {/* MAINTENANCE MODAL */}
      {maintModal && (
        <div onClick={cancelMaint} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px', maxWidth: 420, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>Enable maintenance mode?</span>
              <span onClick={cancelMaint} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span>
            </div>
            <div style={{ background: colors.redTint, border: `1px solid ${colors.redTintBorder}`, borderRadius: 8, padding: '10px 12px', marginBottom: 14, fontSize: 13, color: '#991B1B', lineHeight: 1.5 }}>All users will see the maintenance page immediately. Admins can still access the platform.</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
              <button onClick={cancelMaint} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Cancel</button>
              <button onClick={confirmMaint} style={{ height: 34, padding: '0 14px', background: colors.red, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Enable Maintenance</button>
            </div>
          </div>
        </div>
      )}

      {/* TOAST */}
      {toast && (
        <div style={{ position: 'fixed', right: 22, bottom: 22, zIndex: 60, background: '#fff', border: `1px solid ${colors.greenTintBorder}`, borderRadius: 10, padding: '12px 14px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2} style={{ flexShrink: 0, marginTop: 1 }}><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></svg>
          <div><div style={{ fontSize: 13, fontWeight: 500 }}>Settings saved</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>Changes applied immediately</div></div>
        </div>
      )}
    </>
  )
}
