import React, { useState } from 'react'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const radioStyle = (on) => ({
  width: 18,
  height: 18,
  borderRadius: '50%',
  flexShrink: 0,
  ...(on
    ? { background: colors.ink, boxShadow: 'inset 0 0 0 3px #fff, 0 0 0 1.5px #0A0A0A' }
    : { background: '#fff', border: `1.5px solid ${colors.borderStrong}` }),
})
const optRowStyle = (on) => ({
  display: 'flex',
  gap: 10,
  alignItems: 'center',
  padding: '10px 14px',
  borderRadius: 10,
  cursor: 'pointer',
  border: on ? '1.5px solid #0A0A0A' : `1px solid ${colors.border}`,
  background: on ? colors.bg : '#fff',
})

const recDefs = [
  ['all', 'All users', '210 realtors + 32 developers = 242 users'],
  ['realtors', 'All realtors only', '210 realtors'],
  ['developers', 'All developers only', '32 developers'],
  ['specific', 'Specific user', 'Search for a user below'],
]

const tools = [
  { label: 'B', weight: 700 },
  { label: 'I', fontStyle: 'italic' },
  { label: 'U' },
  { divider: true },
  { label: '☰' },
  { label: '⋮≡' },
  { divider: true },
  { label: '🔗' },
]

const reachMap = { all: 242, realtors: 210, developers: 32, specific: 1 }
const recLabelMap = {
  all: 'All users (242)',
  realtors: 'All realtors (210)',
  developers: 'All developers (32)',
  specific: 'Specific user (1)',
}

const scheduleDefs = [
  ['now', 'Send immediately', 'Will be sent right now'],
  ['later', 'Schedule for later', 'Pick a date and time'],
]

const tips = [
  'Keep subject under 60 characters for best email open rates',
  'Start with the most important information first',
  'Include a clear call-to-action if linking to a feature',
  'Avoid sending more than 2 announcements per week',
]

const history = [
  { subject: 'New feature: Project analytics', recipients: 'All users (242)', sent: 'Jun 26 · 9:00 AM', delivered: '238 / 242', rate: '98.3% delivered' },
  { subject: 'Scheduled maintenance: June 20', recipients: 'All users (238)', sent: 'Jun 19 · 5:00 PM', delivered: '235 / 238', rate: '98.7% delivered' },
  { subject: 'Welcome new realtors — June batch', recipients: 'Realtors (198)', sent: 'Jun 15 · 9:00 AM', delivered: '196 / 198', rate: '99.0% delivered' },
]

export default function AdminAnnouncements() {
  const [recipient, setRecipient] = useState('all')
  const [schedule, setSchedule] = useState('now')
  const [subject, setSubject] = useState('')
  const [message, setMessage] = useState('')
  const [link, setLink] = useState('')
  const [sendOpen, setSendOpen] = useState(false)
  const [sent, setSent] = useState(false)

  const canSend = subject.trim().length > 0 && message.trim().length > 0
  const openSend = () => { if (canSend) { setSendOpen(true); setSent(false) } }
  const closeSend = () => { setSendOpen(false); setSent(false) }
  const doSend = () => setSent(true)

  const reachCount = reachMap[recipient]
  const summaryRecipients = recLabelMap[recipient]
  const scheduleLater = schedule === 'later'
  const scheduleLabel = scheduleLater ? 'June 30, 2026 · 9:00 AM' : 'Send immediately'

  const subj = subject || 'New feature: Project analytics'
  const msg = message || 'Write your announcement here...'
  const previewSubjectShort = subj.length > 40 ? subj.slice(0, 40) + '…' : subj
  const hasLink = link.trim().length > 0

  const sendBtnStyle = {
    height: 36,
    padding: '0 18px',
    border: 'none',
    borderRadius: 8,
    fontSize: 13,
    fontWeight: 600,
    color: '#fff',
    fontFamily: 'inherit',
    background: canSend ? colors.green : colors.textFaint,
    cursor: canSend ? 'pointer' : 'not-allowed',
  }

  return (
    <>
      <style>{`@media (max-width: 900px) { .an-cols { flex-direction: column !important; } }`}</style>
      <Topbar title="Announcements" />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div className="an-cols" style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>

          {/* LEFT: COMPOSE */}
          <div style={{ flex: 2, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px' }}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16 }}>New announcement</div>

              <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Send to *</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
                {recDefs.map(([id, label, count]) => {
                  const on = recipient === id
                  return (
                    <div key={id} onClick={() => setRecipient(id)} style={optRowStyle(on)}>
                      <span style={radioStyle(on)}></span>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 1 }}>{label}</div>
                        <div style={{ fontSize: 11, color: colors.textFaint }}>{count}</div>
                      </div>
                    </div>
                  )
                })}
              </div>
              {recipient === 'specific' && (
                <div style={{ marginBottom: 16, position: 'relative' }}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: 17, transform: 'translateY(-50%)' }}><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.3-4.3" /></svg>
                  <input placeholder="Search by name or email..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 12, fontFamily: 'inherit' }} />
                </div>
              )}

              <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Subject *</div>
              <div style={{ position: 'relative', marginBottom: 14 }}>
                <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="e.g. New feature: Project analytics" maxLength={80} style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 13, fontFamily: 'inherit' }} />
                <span style={{ position: 'absolute', right: 4, bottom: -16, fontSize: 10, color: colors.textFaint }}>{subject.length} / 80</span>
              </div>

              <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, margin: '8px 0 4px' }}>Message *</div>
              <div style={{ border: `1px solid ${colors.border}`, borderRadius: '7px 7px 0 0', borderBottom: `1px solid ${colors.surfaceMuted}`, padding: '7px 10px', display: 'flex', gap: 2, background: colors.bg, alignItems: 'center' }}>
                {tools.map((t, i) =>
                  t.divider ? (
                    <span key={i} style={{ width: 1, height: 16, background: colors.border, margin: '0 4px' }}></span>
                  ) : (
                    <span key={i} style={{ width: 28, height: 28, borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center', color: colors.textFaint, cursor: 'pointer', fontSize: 13, fontWeight: t.weight || 400, fontStyle: t.fontStyle || 'normal' }}>{t.label}</span>
                  )
                )}
              </div>
              <textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Write your announcement here..." style={{ width: '100%', minHeight: 160, border: `1px solid ${colors.border}`, borderTop: 'none', borderRadius: '0 0 7px 7px', padding: '12px 14px', fontSize: 13, fontFamily: 'inherit', lineHeight: 1.7, resize: 'vertical' }} />
              <div style={{ textAlign: 'right', fontSize: 10, color: colors.textFaint, marginTop: 4 }}>{message.length} / 1000 characters</div>

              <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, margin: '14px 0 4px' }}>Link (optional)</div>
              <div style={{ position: 'relative' }}>
                <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}><circle cx="12" cy="12" r="10" /><path d="M2 12h20M12 2a15 15 0 0 1 0 20a15 15 0 0 1 0-20z" /></svg>
                <input value={link} onChange={(e) => setLink(e.target.value)} placeholder="https://..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 13, fontFamily: 'inherit' }} />
              </div>
              <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 4 }}>Appears as a button in the notification</div>
            </div>

            {/* EMAIL PREVIEW */}
            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>Email preview</span>
                <span style={{ fontSize: 13, color: colors.textFaint, cursor: 'pointer' }}>In-app preview</span>
              </div>
              <div style={{ border: `1px solid ${colors.border}`, borderRadius: 10, overflow: 'hidden' }}>
                <div style={{ background: colors.ink, padding: '14px 20px' }}>
                  <span style={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>waseet</span>
                  <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginLeft: 6 }}>وسيط</span>
                </div>
                <div style={{ background: colors.bg, padding: '20px 24px' }}>
                  <div style={{ fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 12 }}>Platform Announcement</div>
                  <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>{subj}</div>
                  <div style={{ fontSize: 14, color: colors.textMuted, lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{msg}</div>
                  {hasLink && <span style={{ display: 'inline-block', background: colors.green, color: '#fff', borderRadius: 7, padding: '8px 16px', fontSize: 13, fontWeight: 600, marginTop: 12 }}>Read more →</span>}
                </div>
                <div style={{ background: colors.surfaceMuted, borderTop: `1px solid ${colors.border}`, padding: '14px 24px' }}>
                  <div style={{ fontSize: 11, color: colors.textFaint }}>© 2026 Waseet · waseet.io</div>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 4 }}>Unsubscribe from announcements</div>
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={openSend} disabled={!canSend} style={sendBtnStyle}>Preview &amp; Send →</button>
              <button style={{ height: 36, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Save as Draft</button>
            </div>

            {/* SENT HISTORY */}
            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 18px', borderBottom: `1px solid ${colors.border}` }}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>Sent announcements</span>
                <span style={{ height: 32, padding: '0 12px', background: colors.green, borderRadius: 7, fontSize: 11, fontWeight: 600, color: '#fff', display: 'flex', alignItems: 'center', gap: 4, cursor: 'pointer' }}>
                  <svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2}><path d="M12 5v14M5 12h14" /></svg>New announcement
                </span>
              </div>
              <div style={{ background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '8px 16px', display: 'flex' }}>
                <span style={{ flex: 2, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Subject</span>
                <span style={{ flex: 1, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Recipients</span>
                <span style={{ flex: 1, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Sent</span>
                <span style={{ flex: 1, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Delivered</span>
                <span style={{ flex: 0.8, textAlign: 'right', fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Actions</span>
              </div>
              {history.map((h, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', padding: '10px 16px', borderBottom: `1px solid ${colors.surfaceMuted}`, minHeight: 52 }}>
                  <span style={{ flex: 2, fontSize: 13, fontWeight: 500 }}>{h.subject}</span>
                  <span style={{ flex: 1, fontSize: 12, color: colors.textMuted }}>{h.recipients}</span>
                  <span style={{ flex: 1, fontSize: 12, color: colors.textFaint }}>{h.sent}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, color: colors.textMuted }}>{h.delivered}</div>
                    <div style={{ fontSize: 10, color: colors.green }}>{h.rate}</div>
                  </div>
                  <span style={{ flex: 0.8, display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                    <span style={{ fontSize: 11, color: colors.greenDark, cursor: 'pointer' }}>View</span>
                    <span style={{ fontSize: 11, color: colors.textMuted, cursor: 'pointer' }}>Resend</span>
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT */}
          <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px' }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>Send summary</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 12, color: colors.textFaint }}>Recipients:</span><span style={{ fontSize: 12, color: colors.textMuted, fontWeight: 500 }}>{summaryRecipients}</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 12, color: colors.textFaint }}>Channels:</span><span style={{ fontSize: 12, color: colors.textMuted, fontWeight: 500 }}>Email + In-app</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 12, color: colors.textFaint }}>Scheduled:</span><span style={{ fontSize: 12, color: colors.textMuted, fontWeight: 500 }}>{scheduleLabel}</span></div>
              </div>
              <div style={{ borderTop: `1px solid ${colors.surfaceMuted}`, margin: '10px 0' }}></div>
              <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 8 }}>Total reach</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8}><path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM22 6l-10 7L2 6" /></svg>
                  <span style={{ fontSize: 12, color: colors.textMuted }}>Email</span>
                </span>
                <span style={{ fontSize: 12, color: colors.textMuted }}>{reachCount} emails</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0' }}>
                <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8}><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0" /></svg>
                  <span style={{ fontSize: 12, color: colors.textMuted }}>In-app</span>
                </span>
                <span style={{ fontSize: 12, color: colors.textMuted }}>{reachCount} users</span>
              </div>
            </div>

            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px' }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>Schedule</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {scheduleDefs.map(([id, label, sub]) => {
                  const on = schedule === id
                  return (
                    <div key={id} onClick={() => setSchedule(id)} style={optRowStyle(on)}>
                      <span style={radioStyle(on)}></span>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 1 }}>{label}</div>
                        <div style={{ fontSize: 11, color: colors.textFaint }}>{sub}</div>
                      </div>
                    </div>
                  )
                })}
              </div>
              {scheduleLater && (
                <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <span style={{ height: 34, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }}>
                    June 30, 2026 <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8}><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></svg>
                  </span>
                  <span style={{ height: 34, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }}>
                    9:00 AM <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={2}><path d="M6 9l6 6 6-6" /></svg>
                  </span>
                  <span style={{ fontSize: 11, color: colors.textFaint }}>Timezone: Asia/Riyadh (automatically)</span>
                </div>
              )}
            </div>

            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px' }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10 }}>Writing tips</div>
              {tips.map((t, i) => (
                <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginBottom: 8 }}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2} style={{ flexShrink: 0, marginTop: 1 }}><path d="M20 6L9 17l-5-5" /></svg>
                  <span style={{ fontSize: 12, color: colors.textSoft, lineHeight: 1.5 }}>{t}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* SEND MODAL */}
      {sendOpen && (
        <div onClick={closeSend} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '20px 24px', maxWidth: 560, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)', maxHeight: '90vh', overflowY: 'auto' }}>
            {!sent && (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                  <span style={{ fontSize: 15, fontWeight: 600 }}>Send announcement</span>
                  <span onClick={closeSend} style={{ fontSize: 20, color: colors.textFaint, cursor: 'pointer' }}>×</span>
                </div>
                <div style={{ border: `1px solid ${colors.border}`, borderRadius: 10, overflow: 'hidden', marginBottom: 16 }}>
                  <div style={{ background: colors.ink, padding: '12px 18px' }}><span style={{ fontSize: 13, fontWeight: 700, color: '#fff' }}>waseet</span></div>
                  <div style={{ background: colors.bg, padding: '16px 20px' }}>
                    <div style={{ fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Platform Announcement</div>
                    <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>{subj}</div>
                    <div style={{ fontSize: 13, color: colors.textMuted, lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>{msg}</div>
                  </div>
                </div>
                <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '12px 14px', marginBottom: 16, display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <div style={{ display: 'flex', gap: 8 }}><span style={{ fontSize: 11, color: colors.textFaint, width: 60 }}>To:</span><span style={{ fontSize: 12, color: colors.textMuted }}>{summaryRecipients}</span></div>
                  <div style={{ display: 'flex', gap: 8 }}><span style={{ fontSize: 11, color: colors.textFaint, width: 60 }}>Subject:</span><span style={{ fontSize: 12, color: colors.textMuted }}>{previewSubjectShort}</span></div>
                  <div style={{ display: 'flex', gap: 8 }}><span style={{ fontSize: 11, color: colors.textFaint, width: 60 }}>Send:</span><span style={{ fontSize: 12, color: colors.textMuted }}>{scheduleLabel}</span></div>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginBottom: 14 }}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.9} style={{ flexShrink: 0, marginTop: 1 }}><path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" /><path d="M12 9v4M12 17h.01" /></svg>
                  <span style={{ fontSize: 12, color: colors.amberText, lineHeight: 1.5 }}>This will send emails to {reachCount} users. This action cannot be undone.</span>
                </div>
                <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 6 }}>Send a test first (recommended):</div>
                <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
                  <input placeholder="admin@waseet.io" style={{ flex: 1, height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 12, fontFamily: 'inherit' }} />
                  <span style={{ height: 34, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>Send test</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
                  <button onClick={closeSend} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Cancel</button>
                  <button onClick={doSend} style={{ height: 34, padding: '0 16px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
                    <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={1.8}><path d="M3 11l18-5v12L3 14v-3z" /></svg>Send to {reachCount} users
                  </button>
                </div>
              </>
            )}
            {sent && (
              <div style={{ textAlign: 'center', padding: '12px 0' }}>
                <svg width={40} height={40} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2} style={{ marginBottom: 12 }}><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></svg>
                <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 8 }}>Announcement sent!</div>
                <div style={{ fontSize: 13, color: colors.textSoft, lineHeight: 1.6, marginBottom: 16 }}>Delivered to {reachCount} users via email and in-app notifications.</div>
                <div style={{ display: 'flex', gap: 20, justifyContent: 'center', marginBottom: 16 }}>
                  <div><div style={{ fontSize: 18, fontWeight: 700 }}>{reachCount}</div><div style={{ fontSize: 11, color: colors.textFaint }}>Sent to</div></div>
                  <div><div style={{ fontSize: 18, fontWeight: 700, color: colors.green }}>~99%</div><div style={{ fontSize: 11, color: colors.textFaint }}>Delivery rate</div></div>
                </div>
                <button onClick={closeSend} style={{ height: 36, padding: '0 24px', background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Done</button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  )
}
