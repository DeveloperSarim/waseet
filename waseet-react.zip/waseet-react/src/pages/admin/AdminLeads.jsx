import React, { useState } from 'react'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const sBadge = (bg, color, border) => ({ borderRadius: 999, padding: '2px 8px', fontSize: 10, fontWeight: 600, background: bg, color, border: `1px solid ${border}` })
const ST = {
  New: sBadge('#EEF3FF', '#1B4FD8', '#BFDBFE'),
  Contacted: sBadge('#F5F3FF', '#5B5BD6', '#DDD6FE'),
  'Site Visit': sBadge('#EEF3FF', '#3730A3', '#C7D2FE'),
  Negotiation: sBadge('#FFFBEB', '#92400E', '#FDE68A'),
  Closed: sBadge('#F0FDF4', '#15803D', '#BBF7D0'),
}
const filters = ['All Developers', 'All Realtors', 'All Projects', 'All Status']
const chips = ['Developer: Al Faisal', 'Status: New']
const rows = [
  { initials: 'AR', realtor: 'Ahmed', tier: '🥇 Gold', client: 'Khalid Al-Ansari', phone: '+966 50 123 4567', project: 'Palm Residence · 2BR', dev: 'Al Faisal', status: 'Negotiation', date: 'Jun 24', dateFull: 'June 24, 2026 10:32 AM', isDup: false },
  { initials: 'FA', realtor: 'Fatima', tier: '🥈 Silver', client: 'Sara Al-Otaibi', phone: '+966 55 234 5678', project: 'Al Noor Tower · 1BR', dev: 'Noor Group', status: 'Closed', date: 'Jun 20', dateFull: 'June 20, 2026 3:15 PM', isDup: false },
  { initials: 'BK', realtor: 'Bilal', tier: '🥉 Bronze', client: 'Khalid Al-Ansari', phone: '+966 50 123 4567', project: 'Palm Residence · 1BR', dev: 'Al Faisal', status: 'New', date: 'Jun 24', dateFull: 'June 24, 2026 11:45 AM', isDup: true },
  { initials: 'MH', realtor: 'Mohammed', tier: '🥉 Bronze', client: 'Omar Al-Rashidi', phone: '+92 50 345 6789', project: 'Green Valley', dev: 'Emerald', status: 'Site Visit', date: 'Jun 23', dateFull: 'June 23, 2026 9:00 AM', isDup: false },
  { initials: 'SA', realtor: 'Sara', tier: '🥉 Bronze', client: 'Hassan Al-Mansouri', phone: '+971 55 456 7890', project: 'Marina Heights', dev: 'Marina Corp', status: 'Contacted', date: 'Jun 22', dateFull: 'June 22, 2026 1:20 PM', isDup: false },
]
const pages = ['1', '2', '3', '63']
const chevron = <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={2}><path d="M6 9l6 6 6-6" /></svg>
const colFlex = { realtor: 1.5, client: 1.2, phone: 1.5, project: 1.5, status: 1, date: 1 }
const headCell = { fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em' }
const dateInput = { height: 34, width: 110, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 12, fontFamily: 'inherit' }

export default function AdminLeads() {
  const [exportState, setExportState] = useState('idle') // idle | loading | done
  const [toast, setToast] = useState(false)
  const [hoverDate, setHoverDate] = useState(null)
  const [hoverDup, setHoverDup] = useState(null)

  const doExport = () => {
    if (exportState !== 'idle') return
    setExportState('loading')
    setTimeout(() => { setExportState('done'); setToast(true) }, 1100)
    setTimeout(() => { setExportState('idle'); setToast(false) }, 4500)
  }
  const exportLabel = exportState === 'loading' ? 'Preparing export…' : exportState === 'done' ? 'Downloaded ✓' : 'Export CSV'
  const exportDone = exportState === 'done'

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>All Leads</span>
            <span style={{ fontSize: 13, color: colors.textFaint }}>1,248 total</span>
          </div>
        }
        actions={
          <button onClick={doExport} style={{ height: 34, padding: '0 14px', background: exportDone ? colors.greenTint : '#fff', border: `1px solid ${exportDone ? colors.greenTintBorder : colors.border}`, borderRadius: 7, fontSize: 12, color: exportDone ? colors.greenDark : colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={exportDone ? colors.greenDark : colors.textMuted} strokeWidth={1.8}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" /></svg>{exportLabel}
          </button>
        }
      />

      {/* Filter bar */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '10px 22px', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }} className="wa-form">
        {filters.map((f) => (
          <div key={f} style={{ height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 12px', fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>{f}{chevron}</div>
        ))}
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8}><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></svg>
          <input placeholder="From" style={dateInput} /><span style={{ fontSize: 12, color: colors.textFaint }}>to</span><input placeholder="To" style={dateInput} />
        </div>
        <div style={{ flex: 1, minWidth: 200, position: 'relative' }}>
          <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.3-4.3" /></svg>
          <input placeholder="Search by client name or phone..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 12, fontFamily: 'inherit' }} />
        </div>
        <span style={{ fontSize: 12, color: colors.textFaint, cursor: 'pointer', marginLeft: 'auto' }}>Clear all</span>
      </div>

      {/* Active chips */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '0 22px 10px', display: 'flex', gap: 6 }}>
        {chips.map((c) => (
          <span key={c} style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 500, color: colors.greenDark, display: 'flex', gap: 6, alignItems: 'center' }}>{c}<span style={{ cursor: 'pointer', color: colors.greenDark }}>×</span></span>
        ))}
      </div>

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg }}>
        <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', margin: '16px 22px' }}>
          {/* Table header */}
          <div style={{ background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '10px 16px', display: 'flex', alignItems: 'center' }}>
            <span style={{ flex: colFlex.realtor, ...headCell }}>Realtor</span>
            <span style={{ flex: colFlex.client, ...headCell }}>Client</span>
            <span style={{ flex: colFlex.phone, ...headCell }}>Phone</span>
            <span style={{ flex: colFlex.project, ...headCell }}>Project</span>
            <span style={{ flex: colFlex.status, ...headCell }}>Status</span>
            <span style={{ flex: colFlex.date, ...headCell }}>Date</span>
            <span style={{ width: 60, ...headCell, textAlign: 'right' }}>Flag</span>
          </div>
          {/* Rows */}
          {rows.map((r, i) => (
            <div key={i} style={{ borderBottom: `1px solid ${colors.surfaceMuted}`, padding: '12px 16px', display: 'flex', alignItems: 'center', minHeight: 56 }}>
              <div style={{ flex: colFlex.realtor, display: 'flex', gap: 8, alignItems: 'center' }}>
                <div style={{ width: 26, height: 26, borderRadius: '50%', background: colors.surfaceMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 600, color: colors.textMuted }}>{r.initials}</div>
                <div><div style={{ fontSize: 13, fontWeight: 500 }}>{r.realtor}</div><div style={{ fontSize: 10, color: colors.textFaint }}>{r.tier}</div></div>
              </div>
              <div style={{ flex: colFlex.client, fontSize: 13, color: colors.textMuted }}>{r.client}</div>
              <div style={{ flex: colFlex.phone, display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontSize: 13, fontWeight: 600, color: colors.ink }}>{r.phone}</span>
                <svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8} style={{ cursor: 'pointer' }}><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>
              </div>
              <div style={{ flex: colFlex.project }}><div style={{ fontSize: 13, color: colors.textMuted }}>{r.project}</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>{r.dev}</div></div>
              <div style={{ flex: colFlex.status }}><span style={ST[r.status]}>{r.status}</span></div>
              <div style={{ flex: colFlex.date, position: 'relative' }} onMouseEnter={() => setHoverDate(i)} onMouseLeave={() => setHoverDate(null)}>
                <span style={{ fontSize: 12, color: colors.textFaint }}>{r.date}</span>
                {hoverDate === i && <span style={{ position: 'absolute', left: 0, bottom: 22, zIndex: 30, background: colors.ink, color: '#fff', borderRadius: 6, padding: '4px 8px', fontSize: 11, whiteSpace: 'nowrap' }}>{r.dateFull}</span>}
              </div>
              <div style={{ width: 60, display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 8 }}>
                {r.isDup && (
                  <span style={{ position: 'relative' }} onMouseEnter={() => setHoverDup(i)} onMouseLeave={() => setHoverDup(null)}>
                    <span style={{ background: '#FEF9EC', border: '1px solid #FDE68A', borderRadius: 5, padding: '2px 6px', fontSize: 10, fontWeight: 600, color: '#92400E' }}>Dup</span>
                    {hoverDup === i && (
                      <span style={{ position: 'absolute', right: 0, bottom: 26, zIndex: 30, background: colors.ink, borderRadius: 10, padding: '12px 14px', boxShadow: '0 8px 24px rgba(0,0,0,0.2)', minWidth: 260, textAlign: 'left' }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: '#fff', marginBottom: 8 }}>Duplicate lead detected</div>
                        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)', lineHeight: 1.5, marginBottom: 8 }}>Same client (+966 50 123 4567) submitted by 2 different realtors for the same project.</div>
                        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginBottom: 4 }}>Submitted by:</div>
                        <div style={{ fontSize: 11, color: '#fff' }}>Ahmed Al-Rashid · Jun 24 10:32 AM</div>
                        <div style={{ fontSize: 11, color: '#fff' }}>Bilal Khan · Jun 24 11:45 AM</div>
                      </span>
                    )}
                  </span>
                )}
                <span style={{ fontSize: 14, color: colors.greenDark, cursor: 'pointer' }}>→</span>
              </div>
            </div>
          ))}
        </div>

        {/* Pagination */}
        <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '14px 22px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: colors.textSoft }}>Showing 1–20 of 1,248 leads</span>
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <span style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textSoft, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>← Prev</span>
            {pages.map((p, i) => (
              <span key={p} style={{ height: 30, minWidth: 30, padding: '0 8px', borderRadius: 6, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', ...(i === 0 ? { background: colors.ink, color: '#fff' } : { border: `1px solid ${colors.border}`, color: colors.textMuted, background: '#fff' }) }}>{p}</span>
            ))}
            <span style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>Next →</span>
          </div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span style={{ fontSize: 12, color: colors.textSoft }}>Per page:</span>
            <span style={{ height: 34, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff' }}>20 {chevron}</span>
          </div>
        </div>
      </div>

      {/* Export toast */}
      {toast && (
        <div style={{ position: 'fixed', right: 22, bottom: 22, zIndex: 60, background: '#fff', border: `1px solid ${colors.greenTintBorder}`, borderRadius: 10, padding: '12px 14px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2} style={{ flexShrink: 0, marginTop: 1 }}><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></svg>
          <div><div style={{ fontSize: 13, fontWeight: 500 }}>Export ready — waseet_leads_Jun28.csv</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>1,248 leads · 48 KB</div></div>
        </div>
      )}
    </>
  )
}
