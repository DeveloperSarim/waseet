import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const card = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 18px', marginBottom: 12 }
const capLabel = { fontSize: 9, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em' }
const rLabel = { fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }
const pdfHatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 9px)'

const dealDetails = [
  ['Project', 'Palm Residence'], ['Unit', 'Unit 4B · 2BR'],
  ['Realtor', 'Ahmed Al-Rashid 🥇'], ['Client', 'Khalid Al-Ansari'],
  ['Deal Closed', 'June 24, 2026'], ['Payment Due', 'July 1, 2026'],
]
const breakdown = [
  ['Sale Price (2BR Unit 4B)', 'SAR 900,000', false, false],
  ['Commission Rate', '3%', false, false],
  ['Gross Commission (3% of SAR 900k)', 'SAR 27,000', true, false],
  ['Platform Fee (15% of SAR 27,000)', '− SAR 4,050', false, true],
]
const realtorBank = [
  ['Bank', 'Al Rajhi Bank'], ['Account Name', 'Ahmed Mohammed Al-Rashid'],
  ['IBAN', 'SA** **** **** **** 1234'], ['Country', 'Saudi Arabia 🇸🇦'],
]

const payMap = {
  pending: ['#FEF9EC', '#92400E', '#F3E2B8', 'Pending'],
  uploaded: ['#FEF9EC', '#92400E', '#F3E2B8', 'Proof uploaded'],
  verified: ['#F0FDF4', '#15803D', '#BBF7D0', 'Received'],
  disbursed: ['#F0FDF4', '#15803D', '#BBF7D0', 'Received'],
}
const csMap = {
  pending: ['#FEF9EC', '#92400E', '#F3E2B8', 'Pending Payment'],
  uploaded: ['#EEF3FF', '#1B4FD8', '#BFDBFE', 'Proof Uploaded'],
  verified: ['#F0FDF4', '#15803D', '#BBF7D0', 'Payment Received'],
  disbursed: ['#F0FDF4', '#15803D', '#BBF7D0', 'Disbursed'],
}
const stageIdxMap = { pending: 0, uploaded: 1, verified: 2, disbursed: 3 }
const tabs = [['pending', 'Pending'], ['uploaded', 'Proof'], ['verified', 'Verified'], ['disbursed', 'Disbursed']]

const modalShell = { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }
const modalCard = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px', maxWidth: 420, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)' }
const btnGhost = { height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }
const boxField = { fontSize: 10, color: colors.textFaint, marginBottom: 2 }

export default function AdminCommissionDetail() {
  const navigate = useNavigate()
  const [stage, setStage] = useState('uploaded') // pending | uploaded | verified | disbursed
  const [modal, setModal] = useState(null) // verify | disburse | reject
  const [toast, setToast] = useState(null)

  const close = () => setModal(null)
  const idx = stageIdxMap[stage]
  const pay = payMap[stage]
  const cs = csMap[stage]

  const showToast = (msg) => {
    setToast(msg)
    setTimeout(() => setToast((t) => (t === msg ? null : t)), 4000)
  }

  const flowSteps = [
    { label: 'Deal closed', date: 'Jun 24' },
    { label: 'Payment received', date: idx >= 2 ? 'Jun 27' : '—' },
    { label: 'Waseet verified', date: idx >= 2 ? 'Jun 27' : '—' },
    { label: 'Disbursed to realtor', date: idx >= 3 ? 'Jun 28' : '—' },
  ]
  const doneCount = idx >= 3 ? 4 : idx >= 2 ? 3 : 1
  const flow = flowSteps.map((st, i) => {
    const isDone = i < doneCount
    const isCurrent = i === doneCount
    return {
      ...st, isDone, isCurrent: isCurrent && stage !== 'disbursed',
      hasLine: i < flowSteps.length - 1,
      lineColor: i < doneCount - 1 ? colors.green : colors.border,
      circleBg: isDone ? colors.green : isCurrent ? colors.ink : '#fff',
      circleBorder: isDone || isCurrent ? 'none' : `1.5px solid ${colors.border}`,
      weight: isCurrent ? 600 : 500,
      color: isDone || isCurrent ? colors.ink : colors.textFaint,
    }
  })

  const tabStyle = (on) => ({ padding: '5px 10px', fontSize: 12, borderRadius: 6, cursor: 'pointer', ...(on ? { background: '#fff', color: colors.ink, fontWeight: 600, boxShadow: '0 1px 2px rgba(0,0,0,0.06)' } : { color: colors.textSoft }) })
  const fromToBox = (label, name, email) => (
    <div style={{ flex: 1, background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '12px 14px' }}>
      <div style={{ ...capLabel, marginBottom: 8 }}>{label}</div>
      <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 3 }}>{name}</div>
      <div style={{ fontSize: 12, color: colors.textSoft }}>{email}</div>
      <div style={{ fontSize: 12, color: colors.textSoft }}>Jeddah, Saudi Arabia</div>
    </div>
  )

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span onClick={() => navigate('/admin/commissions')} style={{ fontSize: 13, color: colors.textFaint, cursor: 'pointer' }}>Commissions</span>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.borderStrong} strokeWidth={2}><path d="M9 18l6-6-6-6" /></svg>
            <span style={{ fontSize: 13, fontWeight: 500 }}>Deal #WS-2026-042</span>
          </div>
        }
        actions={
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: 4, background: colors.surfaceMuted, borderRadius: 8, padding: 3 }}>
              {tabs.map(([key, label]) => <span key={key} onClick={() => setStage(key)} style={tabStyle(stage === key)}>{label}</span>)}
            </div>
            <button style={btnGhost}>Download Invoice PDF</button>
            <button onClick={() => navigate('/admin/commissions')} style={btnGhost}>← Back</button>
          </div>
        }
      />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div className="rp-cols" style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
          {/* LEFT */}
          <div style={{ flex: 2.5, minWidth: 0 }}>
            {/* Invoice */}
            <div style={{ ...card, padding: '18px 20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20, paddingBottom: 16, borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.ink} strokeWidth={1.8}><path d="M12 22s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11z" /><circle cx="12" cy="11" r="2.4" /></svg>
                    <span style={{ fontSize: 18, fontWeight: 700 }}>waseet</span><span style={{ fontSize: 12, color: colors.textFaint }}>وسيط</span>
                  </div>
                  <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 6 }}>Commission Invoice</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>Invoice #WS-2026-042</div>
                  <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 4 }}>Issued: June 24, 2026</div>
                  <div style={{ fontSize: 12, color: colors.amber, marginTop: 2 }}>Due: July 1, 2026</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 24, marginBottom: 20 }}>
                {fromToBox('From', 'Waseet', 'support@waseet.io')}
                {fromToBox('To', 'Al Faisal Development', 'm.faisal@alfaisal.com')}
              </div>
              <div style={{ ...capLabel, marginBottom: 12 }}>Deal Details</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px 16px', marginBottom: 20 }}>
                {dealDetails.map(([label, value]) => (
                  <div key={label}><div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 1 }}>{label}</div><div style={{ fontSize: 13, color: colors.textMuted }}>{value}</div></div>
                ))}
              </div>
              <div style={{ ...capLabel, marginBottom: 12 }}>Commission Breakdown</div>
              <div style={{ border: `1px solid ${colors.border}`, borderRadius: 8, overflow: 'hidden' }}>
                <div style={{ background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '8px 14px', display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Description</span>
                  <span style={{ fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Amount</span>
                </div>
                {breakdown.map(([desc, amt, bold, muted]) => (
                  <div key={desc} style={{ padding: '10px 14px', borderBottom: `1px solid ${colors.surfaceMuted}`, display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: muted ? 12 : 13, color: muted ? colors.textFaint : colors.textMuted }}>{desc}</span>
                    <span style={{ fontSize: muted ? 12 : 13, fontWeight: bold ? 600 : 400, color: muted ? colors.textFaint : colors.textMuted }}>{amt}</span>
                  </div>
                ))}
                <div style={{ background: colors.bg, padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>Total Due to Waseet</span>
                  <span style={{ fontSize: 18, fontWeight: 700, letterSpacing: '-0.02em' }}>SAR 27,000</span>
                </div>
              </div>
              <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 8 }}>Realtor (Ahmed Al-Rashid) will receive SAR 22,950 after payment is verified.</div>
            </div>

            {/* Payment instructions */}
            <div style={card}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <span style={capLabel}>Payment Instructions</span>
                <span style={{ background: pay[0], color: pay[1], border: `1px solid ${pay[2]}`, borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 700 }}>{pay[3]}</span>
              </div>
              <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '12px 14px', marginBottom: 14 }}>
                <div style={{ fontSize: 13, fontWeight: 500, color: colors.textMuted, marginBottom: 12 }}>Transfer SAR 27,000 via bank transfer:</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><span style={{ fontSize: 11, color: colors.textFaint }}>Bank Name</span><span style={{ fontSize: 13, fontWeight: 600 }}>Al Rajhi Bank</span></div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><span style={{ fontSize: 11, color: colors.textFaint }}>Account Name</span><span style={{ fontSize: 13, fontWeight: 600 }}>Waseet Platform</span></div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>IBAN</span>
                    <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}><span style={{ fontSize: 13, fontWeight: 600 }}>SA44 2000 0001 2345 6789 1234</span><span style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, color: colors.greenDark, borderRadius: 6, padding: '4px 10px', fontSize: 12, fontWeight: 500, cursor: 'pointer' }}>Copy IBAN</span></span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>Reference</span>
                    <span style={{ textAlign: 'right' }}><span style={{ fontSize: 13, fontWeight: 600 }}>WS-2026-042</span><div style={{ fontSize: 10, color: colors.amber }}>⚠ Include this reference</div></span>
                  </div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8} style={{ flexShrink: 0, marginTop: 1 }}><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" /><path d="M12 9v4M12 17h.01" /></svg>
                <span style={{ fontSize: 12, color: '#92400E', lineHeight: 1.5 }}>Always include reference WS-2026-042 in your transfer to ensure payment is matched correctly.</span>
              </div>
            </div>

            {/* Payment proof */}
            <div style={{ ...card, marginBottom: 0 }}>
              <div style={{ ...capLabel, marginBottom: 14 }}>Payment Proof</div>
              {stage === 'pending' ? (
                <div>
                  <div style={{ border: `2px dashed ${colors.borderStrong}`, borderRadius: 10, padding: 24, textAlign: 'center' }}>
                    <svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke={colors.borderStrong} strokeWidth={1.6} style={{ margin: '0 auto 8px' }}><path d="M12 16V4M7 9l5-5 5 5M5 20h14" /></svg>
                    <div style={{ fontSize: 13, color: colors.textFaint, marginBottom: 4 }}>No payment proof uploaded yet</div>
                    <div style={{ fontSize: 12, color: colors.textFaint }}>Developer will upload after transfer</div>
                  </div>
                  <div style={{ fontSize: 12, color: colors.textFaint, textAlign: 'center', marginTop: 8 }}>Awaiting developer action</div>
                </div>
              ) : (
                <div style={{ border: `1px solid ${colors.border}`, borderRadius: 10, overflow: 'hidden' }}>
                  <div style={{ background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '10px 14px', display: 'flex', gap: 10, alignItems: 'center' }}>
                    <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.6}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></svg>
                    <div style={{ flex: 1 }}><div style={{ fontSize: 13, fontWeight: 500 }}>payment_proof.pdf</div><div style={{ fontSize: 11, color: colors.textFaint }}>2.1 MB · Uploaded June 27</div></div>
                    <span style={{ fontSize: 11, color: colors.textMuted, border: `1px solid ${colors.border}`, background: '#fff', borderRadius: 6, padding: '4px 10px', cursor: 'pointer' }}>Download ↓</span>
                  </div>
                  <div style={{ height: 280, background: colors.surfaceMuted, backgroundImage: pdfHatch, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ fontSize: 13, color: colors.textFaint, background: 'rgba(249,250,251,0.9)', padding: '6px 12px', borderRadius: 6 }}>Payment receipt preview</span>
                  </div>
                  <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, padding: '10px 14px', display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>Uploaded by developer</span>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>June 27, 2026 · 3:42 PM</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* RIGHT */}
          <div style={{ flex: 1, minWidth: 250, position: 'sticky', top: 0 }}>
            {/* Commission status */}
            <div style={card}>
              <div style={rLabel}>Commission Status</div>
              <div style={{ textAlign: 'center', marginBottom: 14 }}>
                <div style={{ display: 'inline-block', width: '100%', boxSizing: 'border-box', background: cs[0], color: cs[1], border: `1px solid ${cs[2]}`, borderRadius: 8, padding: '8px 14px', fontSize: 14, fontWeight: 700 }}>{cs[3]}</div>
              </div>
              {flow.map((t, i) => (
                <div key={i} style={{ display: 'flex', gap: 12 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <div style={{ width: 20, height: 20, minWidth: 20, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: t.circleBg, border: t.circleBorder }}>
                      {t.isDone && <svg width={11} height={11} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3}><path d="M5 12l4 4L19 7" /></svg>}
                      {t.isCurrent && <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#fff' }} />}
                    </div>
                    {t.hasLine && <div style={{ width: 1.5, height: 26, background: t.lineColor, margin: '2px 0' }} />}
                  </div>
                  <div style={{ paddingBottom: 14 }}>
                    <div style={{ fontSize: 13, fontWeight: t.weight, color: t.color }}>{t.label}</div>
                    <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>{t.date}</div>
                  </div>
                </div>
              ))}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8, paddingTop: 12, borderTop: `1px solid ${colors.surfaceMuted}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 11, color: colors.textFaint }}>Developer paid</span><span style={{ fontSize: 13, color: colors.textMuted }}>SAR 27,000</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 11, color: colors.textFaint }}>Platform earned</span><span style={{ fontSize: 13, color: colors.textMuted }}>SAR 4,050</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 11, color: colors.textFaint }}>To disburse</span><span style={{ fontSize: 13, fontWeight: 600 }}>SAR 22,950</span></div>
              </div>
            </div>

            {/* Realtor bank */}
            <div style={card}>
              <div style={rLabel}>Realtor Bank Details</div>
              <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 12 }}>
                <div style={{ width: 32, height: 32, borderRadius: '50%', background: colors.surfaceMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600, color: colors.textMuted }}>AR</div>
                <div><div style={{ fontSize: 13, fontWeight: 600 }}>Ahmed Al-Rashid 🥇</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>Gold Realtor</div></div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {realtorBank.map(([label, value]) => (
                  <div key={label}><div style={boxField}>{label}</div><div style={{ fontSize: 13, color: colors.textMuted }}>{value}</div></div>
                ))}
              </div>
              <div style={{ display: 'flex', gap: 4, alignItems: 'center', marginTop: 8 }}>
                <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8}><rect x="4" y="11" width="16" height="9" rx="2" /><path d="M8 11V7a4 4 0 0 1 8 0v4" /></svg>
                <span style={{ fontSize: 11, color: colors.textFaint, fontStyle: 'italic' }}>Full IBAN visible only during disbursement</span>
              </div>
            </div>

            {/* Admin actions */}
            <div style={card}>
              <div style={rLabel}>Admin Actions</div>
              {stage === 'pending' && (
                <div>
                  <button onClick={() => setModal('verify')} style={{ width: '100%', height: 36, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Mark as Manually Verified</button>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 4 }}>Use only if you've confirmed payment via bank records.</div>
                </div>
              )}
              {stage === 'uploaded' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <button onClick={() => setModal('verify')} style={{ width: '100%', height: 36, background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                    <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2.5}><path d="M20 6L9 17l-5-5" /></svg>Verify Payment
                  </button>
                  <button onClick={() => setModal('reject')} style={{ width: '100%', height: 36, background: '#fff', border: `1px solid ${colors.redTintBorder}`, borderRadius: 8, fontSize: 13, color: colors.red, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                    <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.red} strokeWidth={2}><circle cx="12" cy="12" r="10" /><path d="M15 9l-6 6M9 9l6 6" /></svg>Reject Proof
                  </button>
                </div>
              )}
              {stage === 'verified' && (
                <div>
                  <button onClick={() => setModal('disburse')} style={{ width: '100%', height: 36, background: colors.ink, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>Trigger Disbursement →</button>
                  <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 6, textAlign: 'center' }}>SAR 22,950 will be sent to Ahmed Al-Rashid's Al Rajhi account.</div>
                </div>
              )}
              {stage === 'disbursed' && (
                <div style={{ width: '100%', height: 36, background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 8, fontSize: 13, fontWeight: 600, color: colors.greenDark, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.greenDark} strokeWidth={2.5}><path d="M20 6L9 17l-5-5" /></svg>Disbursement Complete
                </div>
              )}
            </div>

            {/* Internal notes */}
            <div style={{ ...card, marginBottom: 0 }} className="wa-form">
              <div style={{ ...rLabel, marginBottom: 10 }}>Internal Notes</div>
              <textarea placeholder="Add review notes..." style={{ width: '100%', height: 80, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', resize: 'none' }} />
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                <button style={{ height: 28, padding: '0 10px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 11, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Save</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Verify modal */}
      {modal === 'verify' && (
        <div onClick={close} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={modalCard}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}><div><div style={{ fontSize: 14, fontWeight: 600 }}>Verify payment?</div><div style={{ fontSize: 12, color: colors.textFaint, marginTop: 4 }}>Deal #WS-2026-042 · SAR 27,000</div></div><span onClick={close} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 8, padding: '10px 12px', marginBottom: 14, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.8} style={{ flexShrink: 0, marginTop: 1 }}><circle cx="12" cy="12" r="10" /><path d="M8 12l2.5 2.5L16 9" /></svg>
              <span style={{ fontSize: 13, color: colors.textMuted, lineHeight: 1.6 }}>Verifying payment will trigger the disbursement flow for Ahmed Al-Rashid (SAR 22,950 to Al Rajhi Bank).</span>
            </div>
            <div style={{ fontSize: 13, color: colors.textMuted, marginBottom: 14 }}>Are you sure the payment of SAR 27,000 has been received from Al Faisal Development?</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}><button onClick={close} style={btnGhost}>Cancel</button><button onClick={() => { close(); setStage('verified'); showToast('Payment verified — disbursement flow initiated.') }} style={{ height: 34, padding: '0 14px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Confirm Verification</button></div>
          </div>
        </div>
      )}

      {/* Disburse modal */}
      {modal === 'disburse' && (
        <div onClick={close} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={modalCard}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}><div><div style={{ fontSize: 14, fontWeight: 600 }}>Confirm disbursement?</div><div style={{ fontSize: 12, color: colors.textFaint, marginTop: 4 }}>Deal #WS-2026-042</div></div><span onClick={close} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ background: colors.bg, border: `1px solid ${colors.border}`, borderRadius: 8, padding: '12px 14px', marginBottom: 14 }}>
              <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 4 }}>Sending:</div>
              <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em' }}>SAR 22,950</div>
              <div style={{ height: 1, background: colors.surfaceMuted, margin: '10px 0' }} />
              <div style={{ fontSize: 13, color: colors.textMuted }}>To: Ahmed Al-Rashid</div>
              <div style={{ fontSize: 13, color: colors.textMuted }}>Bank: Al Rajhi Bank</div>
              <div style={{ fontSize: 13, color: colors.textMuted }}>IBAN ending: ···· 1234</div>
            </div>
            <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 14 }}>
              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" /><path d="M12 9v4M12 17h.01" /></svg>
              <span style={{ fontSize: 12, color: colors.amber }}>This action cannot be undone.</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}><button onClick={close} style={btnGhost}>Cancel</button><button onClick={() => { close(); setStage('disbursed'); showToast('SAR 22,950 disbursement initiated for Ahmed Al-Rashid.') }} style={{ height: 34, padding: '0 14px', background: colors.ink, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Confirm &amp; Disburse</button></div>
          </div>
        </div>
      )}

      {/* Reject modal */}
      {modal === 'reject' && (
        <div onClick={close} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={modalCard} className="wa-form">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}><span style={{ fontSize: 14, fontWeight: 600 }}>Reject payment proof?</span><span onClick={close} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <textarea placeholder="Reason — e.g. receipt is unclear, amount doesn't match..." style={{ width: '100%', height: 90, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, fontFamily: 'inherit', resize: 'none' }} />
            <div style={{ fontSize: 12, color: colors.textSoft, marginTop: 8 }}>Developer will be notified to upload a clearer proof.</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 14 }}><button onClick={close} style={btnGhost}>Cancel</button><button onClick={close} style={{ height: 34, padding: '0 14px', background: colors.red, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Reject &amp; Notify</button></div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div style={{ position: 'fixed', bottom: 22, right: 22, zIndex: 60, background: '#fff', border: `1px solid ${colors.greenTintBorder}`, borderRadius: 10, padding: '12px 14px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', display: 'flex', gap: 10, alignItems: 'center' }}>
          <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2}><circle cx="12" cy="12" r="10" /><path d="M8 12l2.5 2.5L16 9" /></svg>
          <span style={{ fontSize: 13, fontWeight: 500 }}>{toast}</span>
        </div>
      )}
    </>
  )
}
