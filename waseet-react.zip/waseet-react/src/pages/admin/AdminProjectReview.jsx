import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const card = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 18px', marginBottom: 12 }
const sectionLabel = { fontSize: 9, fontWeight: 700, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 14 }
const rLabel = { fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }
const fieldLabel = { fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 2 }
const galleryHatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 10px)'
const thumbHatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 8px)'
const pdfHatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 9px)'
const chevronBtn = { position: 'absolute', top: '50%', transform: 'translateY(-50%)', width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.9)', border: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }

const projectInfo = [
  ['Project Name', 'Palm Residence'], ['Type', 'Apartments'],
  ['Status', 'Under Construction'], ['Handover', 'Q4 2027'],
  ['Total Floors', '12'], ['Total Units', '96'],
  ['Completion', '68%'], ['City', 'Jeddah'],
  ['Area', 'Al Rawdhah'], ['Address', 'King Abdullah Road, District 7'],
  ['Coordinates', '21.5433°N, 39.1728°E'], ['Submitted', 'June 24, 2026'],
]
const unitRows = [
  { type: 'Studio', size: '45–55m²', price: 'SAR 420k–480k', units: '8 units', comm: '3%' },
  { type: '1BR', size: '75–90m²', price: 'SAR 600k–700k', units: '12 units', comm: '3%' },
  { type: '2BR', size: '110–130m²', price: 'SAR 850k–1M', units: '8 units', comm: '3%' },
  { type: '3BR', size: '150–170m²', price: 'SAR 1.1M–1.3M', units: '4 units', comm: '2.5%' },
]
const amenities = ['Pool', 'Gym', 'Security', 'Parking', 'Garden', 'Elevators', 'Smart Home']
const landmarks = [
  { name: 'Al-Noor School', dist: '0.5 km' },
  { name: 'Al-Hamra Medical', dist: '1.2 km' },
  { name: 'Red Sea Mall', dist: '2.0 km' },
]
const docs = [
  { name: 'Project Brochure.pdf', meta: '4.2 MB · PDF' },
  { name: 'Payment Plan.pdf', meta: '1.8 MB · PDF' },
  { name: 'NOC Document.pdf', meta: '2.3 MB · PDF' },
  { name: 'Master Plan.pdf', meta: '6.1 MB · PDF' },
]
const unitGrid = '0.8fr 1.1fr 1.4fr 0.8fr 0.9fr'
const modalShell = { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }
const modalCard = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px', maxWidth: 420, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)' }
const btnGhost = { height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }

export default function AdminProjectReview() {
  const navigate = useNavigate()
  const [galleryIdx, setGalleryIdx] = useState(1)
  const [previewIdx, setPreviewIdx] = useState(null)
  const [modal, setModal] = useState(null) // approve | reject
  const [rejectReason, setRejectReason] = useState('')
  const [reasonError, setReasonError] = useState(false)
  const [toast, setToast] = useState(null) // approve | reject

  const close = () => setModal(null)
  const pv = previewIdx != null ? docs[previewIdx] : null
  const hasReason = !!rejectReason.trim()

  const showToast = (kind) => {
    setToast(kind)
    setTimeout(() => setToast((t) => (t === kind ? null : t)), 4000)
  }
  const tryReject = () => (hasReason ? setModal('reject') : setReasonError(true))

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span onClick={() => navigate('/admin/projects')} style={{ fontSize: 13, color: colors.textFaint, cursor: 'pointer' }}>Projects</span>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.borderStrong} strokeWidth={2}><path d="M9 18l6-6-6-6" /></svg>
            <span style={{ fontSize: 13, fontWeight: 500 }}>Palm Residence</span>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.borderStrong} strokeWidth={2}><path d="M9 18l6-6-6-6" /></svg>
            <span style={{ fontSize: 13, color: colors.textFaint }}>Review</span>
          </div>
        }
        actions={<button onClick={() => navigate('/admin/projects')} style={btnGhost}>← Back to list</button>}
      />

      {/* Review banner */}
      <div style={{ background: colors.amberTint, borderBottom: `1px solid ${colors.amberTintBorder}`, padding: '10px 22px', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8} style={{ flexShrink: 0 }}><path d="M12 2l8 4v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V6z" /></svg>
        <span style={{ fontSize: 13, fontWeight: 600, color: '#92400E' }}>Admin Review Mode</span>
        <span style={{ fontSize: 13, color: '#92400E' }}>· This project is not yet live</span>
        <span style={{ fontSize: 13, color: colors.borderStrong }}>·</span>
        <span style={{ fontSize: 13, color: '#92400E' }}>Submitted by Al Faisal Development</span>
        <span style={{ fontSize: 13, color: colors.borderStrong }}>·</span>
        <span style={{ fontSize: 13, color: colors.textFaint }}>June 24, 2026 at 10:32 AM</span>
        <button onClick={() => navigate('/project/palm-residence')} style={{ marginLeft: 'auto', height: 30, padding: '0 12px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Preview as Realtor ↗</button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div className="rp-cols" style={{ display: 'flex', gap: 20, alignItems: 'flex-start', padding: '18px 22px' }}>
          {/* LEFT */}
          <div style={{ flex: 2.5, minWidth: 0 }}>
            {/* Gallery */}
            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', marginBottom: 12 }}>
              <div style={{ height: 280, background: colors.surfaceMuted, backgroundImage: galleryHatch, position: 'relative' }}>
                <div onClick={() => setGalleryIdx((i) => (i > 1 ? i - 1 : 8))} style={{ ...chevronBtn, left: 12 }}>
                  <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2}><path d="M15 18l-6-6 6-6" /></svg>
                </div>
                <div onClick={() => setGalleryIdx((i) => (i < 8 ? i + 1 : 1))} style={{ ...chevronBtn, right: 12 }}>
                  <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2}><path d="M9 18l6-6-6-6" /></svg>
                </div>
                <div style={{ position: 'absolute', bottom: 12, right: 12, background: 'rgba(0,0,0,0.5)', borderRadius: 999, padding: '3px 8px', fontSize: 11, color: '#fff' }}>{galleryIdx} / 8</div>
              </div>
              <div style={{ padding: '10px 12px', display: 'flex', gap: 6, overflowX: 'auto', background: colors.bg }}>
                {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                  <div key={n} onClick={() => setGalleryIdx(n)} style={{ width: 64, height: 48, minWidth: 64, borderRadius: 6, background: colors.surfaceMuted, backgroundImage: thumbHatch, cursor: 'pointer', border: galleryIdx === n ? `1.5px solid ${colors.ink}` : '1px solid transparent' }} />
                ))}
              </div>
            </div>

            {/* Project info */}
            <div style={card}>
              <div style={sectionLabel}>Project Information</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 16px' }}>
                {projectInfo.map(([label, value]) => (
                  <div key={label}><div style={fieldLabel}>{label}</div><div style={{ fontSize: 13, color: colors.textMuted }}>{value}</div></div>
                ))}
              </div>
              <div style={{ marginTop: 12, height: 180, borderRadius: 8, overflow: 'hidden', background: '#EDF0F2', backgroundImage: 'linear-gradient(rgba(0,0,0,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.04) 1px, transparent 1px)', backgroundSize: '28px 28px', position: 'relative' }}>
                <div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)' }}>
                  <svg width={28} height={28} viewBox="0 0 24 24" fill={colors.red} stroke="#fff" strokeWidth={1.5}><path d="M12 22s7-6 7-12a7 7 0 1 0-14 0c0 6 7 12 7 12z" /><circle cx="12" cy="10" r="2.5" fill="#fff" /></svg>
                </div>
              </div>
            </div>

            {/* Unit types */}
            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', marginBottom: 12 }}>
              <div style={{ padding: '12px 16px', borderBottom: `1px solid ${colors.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 9, fontWeight: 700, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Unit Types</span>
                <span style={{ fontSize: 11, color: colors.textFaint }}>4 types</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: unitGrid, background: colors.bg, borderBottom: `1px solid ${colors.border}`, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                <span style={{ padding: '8px 16px' }}>Type</span><span style={{ padding: '8px 8px' }}>Size</span><span style={{ padding: '8px 8px' }}>Price</span><span style={{ padding: '8px 8px' }}>Units</span><span style={{ padding: '8px 8px' }}>Comm.</span>
              </div>
              {unitRows.map((u) => (
                <div key={u.type} style={{ display: 'grid', gridTemplateColumns: unitGrid, borderBottom: `1px solid ${colors.surfaceMuted}`, alignItems: 'center', fontSize: 13, color: colors.textMuted }}>
                  <span style={{ padding: '10px 16px', fontWeight: 500 }}>{u.type}</span>
                  <span style={{ padding: '10px 8px' }}>{u.size}</span>
                  <span style={{ padding: '10px 8px' }}>{u.price}</span>
                  <span style={{ padding: '10px 8px' }}>{u.units}</span>
                  <span style={{ padding: '10px 8px' }}><span style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, color: colors.greenDark, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>{u.comm}</span></span>
                </div>
              ))}
            </div>

            {/* Content */}
            <div style={card}>
              <div style={sectionLabel}>Content</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: colors.textMuted, marginBottom: 6 }}>About the project</div>
              <div style={{ fontSize: 13, color: colors.textMuted, lineHeight: 1.7 }}>Palm Residence is a premium residential development in Al Rawdhah district, Jeddah. Offering 96 units across 12 floors with panoramic Red Sea views, smart-home integration, and resort-grade amenities designed for modern coastal living.</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: colors.textMuted, margin: '14px 0 8px' }}>Amenities</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {amenities.map((a) => <span key={a} style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, color: colors.greenDark, borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 500 }}>{a}</span>)}
              </div>
              <div style={{ fontSize: 12, fontWeight: 600, color: colors.textMuted, margin: '14px 0 8px' }}>Nearby</div>
              {landmarks.map((m) => (
                <div key={m.name} style={{ display: 'flex', gap: 6, alignItems: 'center', padding: '5px 0' }}>
                  <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8}><path d="M12 22s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11z" /><circle cx="12" cy="11" r="2" /></svg>
                  <span style={{ fontSize: 12, color: colors.textMuted }}>{m.name}</span>
                  <span style={{ fontSize: 11, color: colors.textFaint, marginLeft: 'auto' }}>{m.dist}</span>
                </div>
              ))}
            </div>

            {/* Payment plan */}
            <div style={card}>
              <div style={sectionLabel}>Payment Plan</div>
              <div style={{ height: 36, borderRadius: 8, overflow: 'hidden', display: 'flex' }}>
                <div style={{ width: '20%', background: colors.greenTint, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 500, color: colors.greenDark }}>20% Down</div>
                <div style={{ width: '60%', background: colors.greenSoft, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 500, color: colors.greenDark }}>60% During</div>
                <div style={{ width: '20%', background: colors.greenTintBorder, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 500, color: colors.greenDark }}>20% Handover</div>
              </div>
              <div style={{ display: 'flex', gap: 24, marginTop: 12 }}>
                {[['20%', 'Down payment'], ['60%', 'During construction'], ['20%', 'On handover Q4 2027']].map(([v, l]) => (
                  <div key={l}><div style={{ fontSize: 14, fontWeight: 600 }}>{v}</div><div style={{ fontSize: 10, color: colors.textFaint, marginTop: 2 }}>{l}</div></div>
                ))}
              </div>
            </div>

            {/* Documents */}
            <div style={{ ...card, marginBottom: 0 }}>
              <div style={{ ...sectionLabel, marginBottom: 8 }}>Documents</div>
              {docs.map((d, i) => (
                <div key={d.name} style={{ padding: '12px 0', borderBottom: `1px solid ${colors.surfaceMuted}`, display: 'flex', gap: 12, alignItems: 'center' }}>
                  <div style={{ flex: 1, display: 'flex', gap: 10, alignItems: 'center' }}>
                    <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.6} style={{ flexShrink: 0 }}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></svg>
                    <div><div style={{ fontSize: 13, fontWeight: 500 }}>{d.name}</div><div style={{ fontSize: 11, color: colors.textFaint }}>{d.meta}</div></div>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <span onClick={() => setPreviewIdx(previewIdx === i ? null : i)} style={{ display: 'flex', gap: 4, alignItems: 'center', fontSize: 11, color: colors.greenDark, border: `1px solid ${colors.greenTintBorder}`, background: colors.greenTint, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>
                      <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.greenDark} strokeWidth={1.8}><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z" /><circle cx="12" cy="12" r="3" /></svg>Preview
                    </span>
                    <span style={{ fontSize: 11, color: colors.textMuted, border: `1px solid ${colors.border}`, background: '#fff', borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>Download ↓</span>
                  </div>
                </div>
              ))}
              {pv && (
                <div style={{ marginTop: 10, background: colors.surfaceAlt, border: `1px solid ${colors.border}`, borderRadius: 10, overflow: 'hidden' }}>
                  <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '8px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={{ fontSize: 12, color: colors.textMuted }}>Page 1 of 4</span>
                      <span style={{ fontSize: 12, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>← Prev</span>
                      <span style={{ fontSize: 12, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>Next →</span>
                    </div>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <span style={{ fontSize: 12, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>−</span>
                      <span style={{ fontSize: 12, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 5, padding: '3px 8px', cursor: 'pointer' }}>+</span>
                      <span style={{ fontSize: 12, color: colors.textMuted, cursor: 'pointer' }}>Download ↓</span>
                    </div>
                  </div>
                  <div style={{ height: 300, background: colors.surfaceMuted, backgroundImage: pdfHatch, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ fontSize: 13, color: colors.textFaint, background: 'rgba(249,250,251,0.9)', padding: '6px 12px', borderRadius: 6 }}>PDF Preview — {pv.name}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* RIGHT */}
          <div style={{ flex: 1, minWidth: 250, position: 'sticky', top: 0 }}>
            <div style={card}>
              <div style={rLabel}>Review Status</div>
              <div style={{ background: '#FEF9EC', border: '1px solid #F3E2B8', borderRadius: 8, padding: '8px 12px', display: 'flex', gap: 8, alignItems: 'center' }}>
                <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>
                <span style={{ fontSize: 16, fontWeight: 700, color: '#92400E' }}>Pending Review</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 10 }}>
                {[['Submitted', 'Jun 24, 10:32 AM'], ['Developer', 'Al Faisal Development'], ['Projects listed', '3 (2 approved)'], ['First project', 'No']].map(([l, v]) => (
                  <div key={l} style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 11, color: colors.textFaint }}>{l}</span><span style={{ fontSize: 12, color: colors.textMuted }}>{v}</span></div>
                ))}
              </div>
            </div>

            <div style={card}>
              <div style={rLabel}>Developer</div>
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                <div style={{ width: 40, height: 40, borderRadius: 8, background: colors.surfaceMuted, border: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: colors.textMuted }}>AF</div>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>Al Faisal Development</div>
                  <div style={{ fontSize: 11, color: colors.green, marginTop: 2 }}>Verified ✓</div>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>3 projects · 8 deals closed</div>
                </div>
              </div>
              <div onClick={() => navigate('/admin/developers/1')} style={{ fontSize: 12, color: colors.greenDark, cursor: 'pointer', marginTop: 10 }}>View Developer Profile →</div>
            </div>

            <div style={card}>
              <div style={rLabel}>Commission Preview</div>
              <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 10 }}>If a 2BR sells at SAR 850,000:</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: colors.textMuted }}><span>Gross (3%)</span><span>SAR 25,500</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: colors.textFaint, marginTop: 4 }}><span>Platform (15%)</span><span>SAR 3,825</span></div>
              <div style={{ height: 1, background: colors.surfaceMuted, margin: '8px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, fontWeight: 700 }}><span>Realtor receives</span><span>SAR 21,675</span></div>
            </div>

            <div style={{ ...card, marginBottom: 0 }} className="wa-form">
              <div style={{ ...rLabel, marginBottom: 10 }}>Review Notes</div>
              <textarea placeholder="Add review notes..." style={{ width: '100%', height: 80, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', resize: 'none' }} />
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                <button style={{ height: 28, padding: '0 10px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 11, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Save</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky action bar */}
      <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, padding: '12px 22px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 16 }} className="wa-form">
        <div style={{ flex: 1, maxWidth: 420 }}>
          <input value={rejectReason} onChange={(e) => { setRejectReason(e.target.value); setReasonError(false) }} placeholder="Rejection reason (required if rejecting)..." style={{ width: '100%', height: 34, border: `1px solid ${reasonError ? colors.redTintBorder : colors.border}`, borderRadius: 7, padding: '0 12px', fontSize: 13, fontFamily: 'inherit' }} />
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <button onClick={() => navigate('/admin/projects')} style={{ height: 34, padding: '0 14px', background: 'transparent', border: 'none', fontSize: 12, color: colors.textSoft, fontFamily: 'inherit', cursor: 'pointer' }}>← Back</button>
          <button onClick={tryReject} style={{ height: 36, padding: '0 16px', background: '#fff', border: `1px solid ${colors.redTintBorder}`, borderRadius: 8, fontSize: 13, fontWeight: 500, color: colors.red, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, opacity: hasReason ? 1 : 0.5 }}>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.red} strokeWidth={2}><circle cx="12" cy="12" r="10" /><path d="M15 9l-6 6M9 9l6 6" /></svg>Reject &amp; Notify Developer
          </button>
          <button onClick={() => setModal('approve')} style={{ height: 36, padding: '0 20px', background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2.5}><path d="M20 6L9 17l-5-5" /></svg>Approve &amp; Publish
          </button>
        </div>
      </div>

      {/* Approve modal */}
      {modal === 'approve' && (
        <div onClick={close} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={modalCard}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}><div><div style={{ fontSize: 14, fontWeight: 600 }}>Approve &amp; publish project?</div><div style={{ fontSize: 12, color: colors.textFaint, marginTop: 4 }}>Palm Residence</div></div><span onClick={close} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 8, padding: '10px 12px', marginBottom: 14, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.8} style={{ flexShrink: 0, marginTop: 1 }}><circle cx="12" cy="12" r="10" /><path d="M8 12l2.5 2.5L16 9" /></svg>
              <span style={{ fontSize: 13, color: colors.textMuted, lineHeight: 1.6 }}>Project will go live immediately. Al Faisal Development and all active realtors will be notified by email.</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}><button onClick={close} style={btnGhost}>Cancel</button><button onClick={() => { close(); showToast('approve') }} style={{ height: 34, padding: '0 14px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Approve &amp; Publish ✓</button></div>
          </div>
        </div>
      )}

      {/* Reject modal */}
      {modal === 'reject' && (
        <div onClick={close} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={modalCard}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}><div><div style={{ fontSize: 14, fontWeight: 600 }}>Reject project?</div><div style={{ fontSize: 12, color: colors.textFaint, marginTop: 4 }}>Palm Residence</div></div><span onClick={close} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ background: colors.bg, border: `1px solid ${colors.border}`, borderRadius: 8, padding: '10px 12px', marginBottom: 14 }}><div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 4 }}>Rejection reason:</div><div style={{ fontSize: 13, color: colors.textMuted }}>{rejectReason.trim() || '—'}</div></div>
            <div style={{ fontSize: 12, color: colors.textSoft, marginBottom: 14 }}>This reason will be emailed to Al Faisal Development.</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}><button onClick={close} style={btnGhost}>Cancel</button><button onClick={() => { close(); showToast('reject') }} style={{ height: 34, padding: '0 14px', background: colors.red, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Reject &amp; Notify</button></div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div style={{ position: 'fixed', bottom: 84, right: 22, zIndex: 60, background: '#fff', border: `1px solid ${toast === 'reject' ? colors.redTintBorder : colors.greenTintBorder}`, borderRadius: 10, padding: '12px 14px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', display: 'flex', gap: 10, alignItems: 'center' }}>
          <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={toast === 'reject' ? colors.red : colors.green} strokeWidth={2}><circle cx="12" cy="12" r="10" /><path d={toast === 'reject' ? 'M15 9l-6 6M9 9l6 6' : 'M8 12l2.5 2.5L16 9'} /></svg>
          <span style={{ fontSize: 13, fontWeight: 500 }}>{toast === 'reject' ? 'Palm Residence rejected. Developer notified by email.' : 'Palm Residence approved and published!'}</span>
        </div>
      )}
    </>
  )
}
