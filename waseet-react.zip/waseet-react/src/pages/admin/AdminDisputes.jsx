import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 8px)'
const devBadge = { display: 'inline-block', marginTop: 2, background: '#F5F3FF', border: '1px solid #DDD6FE', color: '#5B5BD6', borderRadius: 4, padding: '0 5px', fontSize: 9, fontWeight: 600 }
const realtorBadge = { display: 'inline-block', marginTop: 2, background: '#FFF7ED', border: '1px solid #FDDCAB', color: '#C2410C', borderRadius: 4, padding: '0 5px', fontSize: 9, fontWeight: 600 }
const chevron = <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={2}><path d="M6 9l6 6 6-6" /></svg>

const ST = {
  Open: { label: 'Open', bg: '#FFF5F5', bd: '#FECACA', color: '#991B1B', icon: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 8v4M12 16h.01', iconColor: '#DC2626', actionLabel: 'Review →', actionColor: '#DC2626' },
  'Under Review': { label: 'Under Review', bg: '#FEF9EC', bd: '#F3E2B8', color: '#92400E', icon: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 7v5l3 2', iconColor: '#D97706', actionLabel: 'Review →', actionColor: '#92400E' },
  Resolved: { label: 'Resolved ✓', bg: '#F0FDF4', bd: '#BBF7D0', color: '#15803D', icon: 'M20 6L9 17l-5-5', iconColor: '#16A34A', actionLabel: 'View →', actionColor: '#15803D' },
}
const data = [
  { id: '#D-0012', raiser: 'dev', raiserName: 'Al Faisal Development', raiserInit: 'AF', against: 'realtor', againstName: 'Ahmed Al-Rashid 🥇', againstInit: 'AR', project: 'Palm Residence · 2BR', deal: 'Deal: SAR 900,000', days: '7 days', daysLevel: 3, evidence: '3 files', evHas: true, cat: 'Open' },
  { id: '#D-0011', raiser: 'realtor', raiserName: 'Fatima Hassan 💎', raiserInit: 'FA', against: 'dev', againstName: 'Marina Corp', againstInit: 'MC', project: 'Marina Heights · Office', deal: 'Deal: AED 980,000', days: '5 days', daysLevel: 2, evidence: '1 file', evHas: true, cat: 'Open' },
  { id: '#D-0010', raiser: 'dev', raiserName: 'Noor Group', raiserInit: 'NG', against: 'realtor', againstName: 'Bilal Khan 🥉', againstInit: 'BK', project: 'Al Noor Tower · 1BR', deal: 'Deal: SAR 650,000', days: '3 days', daysLevel: 1, evidence: '2 files', evHas: true, cat: 'Open' },
  { id: '#D-0009', raiser: 'realtor', raiserName: 'Omar Khalid 🥈', raiserInit: 'OK', against: 'dev', againstName: 'Coast Developers', againstInit: 'CD', project: 'Corniche Suites · 1BR', deal: 'Deal: SAR 720,000', days: '2 days', daysLevel: 1, evidence: 'No files', evHas: false, cat: 'Open' },
  { id: '#D-0008', raiser: 'dev', raiserName: 'Emerald Builders', raiserInit: 'EB', against: 'realtor', againstName: 'Sara Al-Otaibi 🥈', againstInit: 'SO', project: 'Green Valley · Villa', deal: 'Deal: PKR 65M', days: '1 day', daysLevel: 1, evidence: '4 files', evHas: true, cat: 'Open' },
  { id: '#D-0007', raiser: 'dev', raiserName: 'Bay Developers', raiserInit: 'BD', against: 'realtor', againstName: 'Mohammed Hassan 🥇', againstInit: 'MH', project: 'Business Bay · Office', deal: 'Deal: AED 1.2M', days: '2 days', daysLevel: 1, evidence: '2 files', evHas: true, cat: 'Under Review' },
  { id: '#D-0006', raiser: 'realtor', raiserName: 'Ahmed Al-Rashid 🥇', raiserInit: 'AR', against: 'dev', againstName: 'Al Faisal Development', againstInit: 'AF', project: 'Palm Residence · Studio', deal: 'Deal: SAR 480,000', days: 'Resolved', daysLevel: 0, evidence: '1 file', evHas: true, cat: 'Resolved' },
]
const counts = { Open: 5, 'Under Review': 3, Resolved: 7 }
const tabDefs = ['Open', 'Under Review', 'Resolved']
const summary = [
  ['15', colors.ink, 'Total disputes'], ['5', '#DC2626', 'Open'], ['3', '#D97706', 'Under review'],
  ['7', '#16A34A', 'Resolved'], ['47%', colors.textMuted, 'Resolution rate'], ['3.2 days', colors.textMuted, 'Avg. resolution time'],
]
const head = { fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }
const daysColor = (lvl) => (lvl >= 3 ? '#DC2626' : lvl === 2 ? '#D97706' : colors.textMuted)

function Party({ init, name, type }) {
  return (
    <div style={{ flex: 1.5, display: 'flex', gap: 8, alignItems: 'center' }}>
      <span style={{ width: 32, height: 32, borderRadius: type === 'dev' ? 8 : '50%', background: colors.surfaceMuted, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 600, color: colors.textMuted, flexShrink: 0 }}>{init}</span>
      <div><div style={{ fontSize: 12, fontWeight: 500 }}>{name}</div><span style={type === 'dev' ? devBadge : realtorBadge}>{type === 'dev' ? 'Developer' : 'Realtor'}</span></div>
    </div>
  )
}

export default function AdminDisputes() {
  const navigate = useNavigate()
  const [tab, setTab] = useState('Open')
  const visible = data.filter((r) => r.cat === tab)

  return (
    <>
      <Topbar
        left={<div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}><span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>Disputes</span><span style={{ fontSize: 13, color: colors.textFaint }}>15 total</span></div>}
        actions={<button style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={1.8}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" /></svg>Export CSV</button>}
      />

      {/* Tabs */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '0 22px', display: 'flex' }}>
        {tabDefs.map((id) => {
          const on = tab === id
          const red = id === 'Open'
          const badge = on
            ? { background: colors.ink, color: '#fff' }
            : red ? { background: '#FFF5F5', border: '1px solid #FECACA', color: '#991B1B' } : { background: colors.surfaceMuted, color: colors.textSoft }
          return (
            <div key={id} onClick={() => setTab(id)} style={{ padding: '11px 16px', fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', whiteSpace: 'nowrap', borderBottom: `2px solid ${on ? colors.ink : 'transparent'}`, color: on ? colors.ink : colors.textSoft, fontWeight: on ? 600 : 400 }}>
              {id}<span style={{ borderRadius: 999, padding: '1px 6px', fontSize: 10, fontWeight: 600, marginLeft: 5, ...badge }}>{counts[id]}</span>
            </div>
          )
        })}
      </div>

      {/* Urgent banner */}
      {tab === 'Open' && (
        <div style={{ background: colors.redTint, borderBottom: `1px solid ${colors.redTintBorder}`, padding: '10px 22px', display: 'flex', gap: 10, alignItems: 'center' }}>
          <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.red} strokeWidth={1.9} style={{ flexShrink: 0 }}><circle cx="12" cy="12" r="10" /><path d="M12 8v4M12 16h.01" /></svg>
          <span style={{ fontSize: 13, fontWeight: 600, color: '#991B1B' }}>5 open disputes need resolution</span>
          <span style={{ color: colors.borderStrong }}>·</span>
          <span style={{ fontSize: 13, color: colors.red }}>Oldest open: 7 days ago</span>
          <span style={{ fontSize: 12, color: colors.red, fontWeight: 500, marginLeft: 'auto', cursor: 'pointer' }}>Review all →</span>
        </div>
      )}

      {/* Filter bar */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '10px 22px', display: 'flex', gap: 8, alignItems: 'center' }} className="wa-form">
        <div style={{ flex: 1, maxWidth: 280, position: 'relative' }}>
          <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.3-4.3" /></svg>
          <input placeholder="Search by developer, realtor, or project..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 12, fontFamily: 'inherit' }} />
        </div>
        <span style={{ height: 34, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff' }}>All types {chevron}</span>
        <span style={{ height: 34, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff' }}>Project {chevron}</span>
        <span style={{ height: 34, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff', marginLeft: 'auto' }}>Oldest first {chevron}</span>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg }}>
        <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', margin: '16px 22px' }}>
          {/* Header */}
          <div style={{ background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ flex: 0.6, ...head }}>Dispute</span>
            <span style={{ flex: 1.5, ...head }}>Raised by</span>
            <span style={{ flex: 1.5, ...head }}>Against</span>
            <span style={{ flex: 1.5, ...head }}>Project</span>
            <span style={{ flex: 0.8, textAlign: 'right', ...head }}>Days open</span>
            <span style={{ flex: 0.6, textAlign: 'center', ...head }}>Evidence</span>
            <span style={{ flex: 1, ...head }}>Status</span>
            <span style={{ flex: 0.8, textAlign: 'right', ...head }}>Actions</span>
          </div>
          {/* Rows */}
          {visible.map((r) => {
            const st = ST[r.cat]
            const open = r.cat === 'Open', review = r.cat === 'Under Review'
            return (
              <div key={r.id} onClick={() => navigate('/admin/disputes/' + r.id.replace('#', ''))} style={{ display: 'flex', alignItems: 'center', gap: 12, borderBottom: `1px solid ${colors.surfaceMuted}`, padding: '14px 16px', minHeight: 64, cursor: 'pointer', background: open ? '#FFFCFC' : review ? '#FFFEF5' : '#fff', borderLeft: `2px solid ${open ? '#DC2626' : review ? '#D97706' : 'transparent'}` }}>
                <div style={{ flex: 0.6 }}><div style={{ fontSize: 12, fontWeight: 600, fontFamily: 'monospace' }}>{r.id}</div><div style={{ fontSize: 10, color: colors.textFaint }}>{r.raiser === 'dev' ? 'Developer' : 'Realtor'}</div></div>
                <Party init={r.raiserInit} name={r.raiserName} type={r.raiser} />
                <Party init={r.againstInit} name={r.againstName} type={r.against} />
                <div style={{ flex: 1.5, display: 'flex', gap: 8, alignItems: 'center' }}>
                  <div style={{ width: 36, height: 28, borderRadius: 5, background: colors.surfaceMuted, backgroundImage: hatch, flexShrink: 0 }} />
                  <div><div style={{ fontSize: 12, fontWeight: 500 }}>{r.project}</div><div style={{ fontSize: 10, color: colors.textFaint }}>{r.deal}</div></div>
                </div>
                <div style={{ flex: 0.8, textAlign: 'right', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 4 }}>
                  <span style={{ fontSize: 12, fontWeight: r.daysLevel >= 3 ? 600 : 400, color: daysColor(r.daysLevel) }}>{r.days}</span>
                  {r.daysLevel >= 3 && <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={colors.red} strokeWidth={2}><path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" /><path d="M12 9v4M12 17h.01" /></svg>}
                </div>
                <div style={{ flex: 0.6, textAlign: 'center' }}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={r.evHas ? colors.textFaint : colors.borderStrong} strokeWidth={1.8} style={{ display: 'inline-block' }}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /></svg>
                  <div style={{ fontSize: 10, color: r.evHas ? colors.textFaint : colors.borderStrong, marginTop: 2 }}>{r.evidence}</div>
                </div>
                <div style={{ flex: 1 }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, borderRadius: 999, padding: '2px 8px', fontSize: 11, fontWeight: 600, background: st.bg, border: `1px solid ${st.bd}`, color: st.color }}>
                    <svg width={11} height={11} viewBox="0 0 24 24" fill="none" stroke={st.iconColor} strokeWidth={2}><path d={st.icon} /></svg>{st.label}
                  </span>
                </div>
                <div style={{ flex: 0.8, display: 'flex', gap: 6, justifyContent: 'flex-end', alignItems: 'center' }}>
                  <span style={{ fontSize: 11, fontWeight: 500, color: st.actionColor, cursor: 'pointer' }}>{st.actionLabel}</span>
                  <span onClick={(e) => e.stopPropagation()} style={{ width: 28, height: 28, borderRadius: '50%', border: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', background: '#fff' }}><svg width={14} height={14} viewBox="0 0 24 24" fill={colors.textFaint}><circle cx="5" cy="12" r="1.6" /><circle cx="12" cy="12" r="1.6" /><circle cx="19" cy="12" r="1.6" /></svg></span>
                </div>
              </div>
            )
          })}
        </div>

        {/* Summary */}
        <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px', margin: '0 22px 16px' }}>
          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12 }}>Dispute summary</div>
          <div style={{ display: 'flex' }}>
            {summary.map(([value, color, label], i) => (
              <div key={label} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '8px 0', borderRight: i < summary.length - 1 ? `1px solid ${colors.surfaceMuted}` : 'none' }}>
                <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 3, color }}>{value}</div>
                <div style={{ fontSize: 10, color: colors.textFaint }}>{label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Pagination */}
        <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '14px 22px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: colors.textSoft }}>Showing 1–10 of 15 disputes</span>
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <span style={{ height: 30, minWidth: 30, borderRadius: 6, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', background: colors.ink, color: '#fff' }}>1</span>
            <span style={{ height: 30, minWidth: 30, borderRadius: 6, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', border: `1px solid ${colors.border}`, color: colors.textMuted, background: '#fff' }}>2</span>
            <span style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>Next →</span>
          </div>
        </div>
      </div>
    </>
  )
}
