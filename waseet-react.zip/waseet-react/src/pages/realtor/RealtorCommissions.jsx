import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const badgeStyle = (kind) => {
  const map = {
    Pending: { background: '#FEF9EC', border: '1px solid #F3E2B8', color: '#92400E' },
    Processing: { background: '#EEF3FF', border: '1px solid #BFDBFE', color: '#1B4FD8' },
    Paid: { background: '#F0FDF4', border: '1px solid #BBF7D0', color: '#15803D' },
  }
  return { borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 600, ...map[kind] }
}

const trackLabels = ['Deal closed', 'Dev pays', 'Verified', 'You receive']
const makeTrack = (filled) =>
  trackLabels.map((label, i) => ({
    label,
    fill: i < filled ? colors.green : colors.borderStrong,
    hasLine: i < 3,
    lineColor: i < filled - 1 ? colors.green : colors.borderStrong,
  }))

const allCards = [
  { deal: 'Deal #WS-2026-042', unit: 'Palm Residence · Unit 4B · 2BR', developer: 'Al Faisal Development', gross: 'SAR 27,000', fee: 'SAR 4,050', net: 'SAR 22,950', closed: 'June 24, 2026', group: 'Pending', statusText: 'Pending Payment', netColor: colors.ink, track: makeTrack(1), msg: 'Waiting for developer payment', msgColor: colors.textFaint },
  { deal: 'Deal #WS-2026-041', unit: 'Al Noor Tower · Unit 2A · 1BR', developer: 'Noor Group', gross: 'SAR 19,500', fee: 'SAR 2,925', net: 'SAR 16,575', closed: 'June 25, 2026', group: 'Processing', statusText: 'Processing', netColor: colors.ink, track: makeTrack(3), msg: 'Expected: June 30 – July 2', msgColor: colors.textSoft },
  { deal: 'Deal #WS-2026-039', unit: 'Marina Heights · Office · Unit 8', developer: 'Marina Corp', gross: 'SAR 24,500', fee: 'SAR 3,675', net: 'SAR 20,825', closed: 'June 20, 2026', group: 'Paid', statusText: 'Paid ✓', netColor: colors.green, track: makeTrack(4), msg: 'Paid: June 22, 2026', msgColor: colors.green },
  { deal: 'Deal #WS-2026-036', unit: 'Green Valley · Villa · Unit 3', developer: 'Emerald Builders', gross: 'SAR 31,500', fee: 'SAR 4,725', net: 'SAR 26,775', closed: 'June 8, 2026', group: 'Paid', statusText: 'Paid ✓', netColor: colors.green, track: makeTrack(4), msg: 'Paid: June 10, 2026', msgColor: colors.green },
]

const tabDefs = [['All', 11], ['Pending', 3], ['Processing', 2], ['Paid', 6]]

const flow = [
  'Deal closes', 'Developer pays (7 days)', 'Waseet verifies (1–2 days)', 'You receive (3–5 days)',
]

const emptyMap = {
  Pending: { title: 'No pending commissions', sub: 'All your commissions have been processed.', subColor: colors.green },
  Processing: { title: 'Nothing processing', sub: 'Commissions being paid out will show here.', subColor: colors.textSoft },
  Paid: { title: 'No paid commissions yet', sub: 'Commission payments will appear here after deals close.', subColor: colors.textSoft },
  All: { title: 'No commissions yet', sub: 'Submit leads and close deals to start earning commissions.', subColor: colors.textSoft },
}

export default function RealtorCommissions() {
  const navigate = useNavigate()
  const [tab, setTab] = useState('All')
  const [tipOpen, setTipOpen] = useState(false)

  const visible = tab === 'All' ? allCards : allCards.filter((c) => c.group === tab)
  const em = emptyMap[tab]

  return (
    <>
      <Topbar
        left={<span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>My Commissions</span>}
        right={
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
            <span style={{ fontSize: 10, color: colors.textFaint }}>Total earned</span>
            <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>SAR 139,050</span>
          </div>
        }
      />

      {/* Tabs */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '0 22px', display: 'flex' }}>
        {tabDefs.map(([label, count]) => {
          const on = tab === label
          return (
            <div key={label} onClick={() => setTab(label)} style={{ padding: '11px 16px', fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', borderBottom: `2px solid ${on ? colors.ink : 'transparent'}`, color: on ? colors.ink : colors.textSoft, fontWeight: on ? 600 : 400 }}>
              {label}
              <span style={{ borderRadius: 999, padding: '1px 6px', fontSize: 10, fontWeight: 600, marginLeft: 5, background: on ? colors.ink : colors.surfaceMuted, color: on ? '#fff' : colors.textSoft }}>{count}</span>
            </div>
          )
        })}
      </div>

      {/* Timeline banner */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '10px 22px', display: 'flex', gap: 10, alignItems: 'center' }}>
        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.textSoft} strokeWidth={1.8} style={{ flexShrink: 0 }}><circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" /></svg>
        <span style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted }}>Commission timeline:</span>
        <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap' }}>
          {flow.map((f, i) => (
            <span key={f} style={{ display: 'flex', alignItems: 'center' }}>
              <span style={{ fontSize: 11, color: colors.textSoft }}>{f}</span>
              {i < flow.length - 1 && <span style={{ fontSize: 10, color: colors.borderStrong, margin: '0 6px' }}>→</span>}
            </span>
          ))}
        </div>
        <div style={{ position: 'relative', marginLeft: 'auto' }} onMouseEnter={() => setTipOpen(true)} onMouseLeave={() => setTipOpen(false)}>
          <span style={{ width: 28, height: 28, border: `1px solid ${colors.border}`, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: colors.textFaint, cursor: 'pointer' }}>?</span>
          {tipOpen && (
            <div style={{ position: 'absolute', right: 0, top: 34, zIndex: 30, background: colors.ink, borderRadius: 10, padding: '12px 14px', width: 260, boxShadow: '0 8px 24px rgba(0,0,0,0.2)' }}>
              <div style={{ fontSize: 12, color: '#fff', lineHeight: 1.6 }}>Total expected time: 7–14 days after the deal is marked closed.</div>
              <div style={{ fontSize: 12, color: '#60A5FA', marginTop: 8, cursor: 'pointer' }}>Questions? Contact support →</div>
            </div>
          )}
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '16px 22px' }}>
        {/* Failed alert */}
        <div style={{ background: '#fff', border: `1px solid ${colors.redTintBorder}`, borderLeft: `3px solid ${colors.red}`, borderRadius: 8, padding: '12px 14px', marginBottom: 14, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.red} strokeWidth={1.8} style={{ flexShrink: 0, marginTop: 1 }}><circle cx="12" cy="12" r="10" /><path d="M12 8v4M12 16h.01" /></svg>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#991B1B', marginBottom: 4 }}>Commission payment could not be processed</div>
            <div style={{ fontSize: 12, color: colors.red, lineHeight: 1.6, marginBottom: 8 }}>We tried 3 times to transfer SAR 22,950 to your bank but failed. Our team will contact you within 24 hours.</div>
            <div style={{ display: 'flex', gap: 8 }}>
              <span style={{ fontSize: 11, color: colors.red, border: `1px solid ${colors.redTintBorder}`, borderRadius: 6, padding: '5px 10px', cursor: 'pointer' }}>Update Bank Details</span>
              <span style={{ fontSize: 11, color: colors.textMuted, border: `1px solid ${colors.border}`, borderRadius: 6, padding: '5px 10px', cursor: 'pointer' }}>Contact Support</span>
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {visible.map((c, i) => (
            <div key={i} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', cursor: 'pointer' }}>
              <div style={{ padding: '14px 16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 4 }}>{c.deal}</div>
                    <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>{c.unit}</div>
                    <div style={{ fontSize: 12, color: colors.textSoft }}>Developer: {c.developer}</div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 5 }}>
                    <span style={badgeStyle(c.group)}>{c.statusText}</span>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>Closed: {c.closed}</span>
                  </div>
                </div>
                <div style={{ height: 1, background: colors.surfaceMuted, margin: '12px 0' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
                  <div style={{ display: 'flex', gap: 20, alignItems: 'flex-end' }}>
                    <div><div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 2 }}>Gross</div><div style={{ fontSize: 13, fontWeight: 600 }}>{c.gross}</div></div>
                    <div><div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 2 }}>Platform (15%)</div><div style={{ fontSize: 13, fontWeight: 600, color: colors.textFaint }}>− {c.fee}</div></div>
                    <div><div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 2 }}>You receive</div><div style={{ fontSize: 15, fontWeight: 700 }}>{c.net}</div></div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', color: c.netColor }}>{c.net}</div>
                  </div>
                </div>
              </div>
              <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '10px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    {c.track.map((d, j) => (
                      <div key={j} style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, width: 56 }}>
                          <span style={{ width: 8, height: 8, borderRadius: '50%', background: d.fill }} />
                          <span style={{ fontSize: 9, color: colors.textFaint, whiteSpace: 'nowrap' }}>{d.label}</span>
                        </div>
                        {d.hasLine && <span style={{ width: 20, height: 2, background: d.lineColor, marginBottom: 12 }} />}
                      </div>
                    ))}
                  </div>
                  <div style={{ fontSize: 11, color: c.msgColor, marginTop: 5 }}>{c.msg}</div>
                </div>
                <span onClick={() => navigate('/realtor/commissions/' + c.deal.replace(/[^0-9-]/g, '').replace(/^-/, ''))} style={{ fontSize: 12, color: colors.greenDark, cursor: 'pointer' }}>View Details →</span>
              </div>
            </div>
          ))}

          {visible.length === 0 && (
            <div style={{ textAlign: 'center', padding: '56px 20px' }}>
              <svg width={36} height={36} viewBox="0 0 24 24" fill="none" stroke={colors.borderStrong} strokeWidth={1.6} style={{ marginBottom: 12 }}><circle cx="12" cy="12" r="9" /><path d="M12 7v10M9.5 9.5c0-1 1.1-1.5 2.5-1.5s2.5.5 2.5 1.5-1.1 1.5-2.5 1.5-2.5.5-2.5 1.5 1.1 1.5 2.5 1.5 2.5-.5 2.5-1.5" /></svg>
              <div style={{ fontSize: 14, fontWeight: 600 }}>{em.title}</div>
              <div style={{ fontSize: 13, color: em.subColor, marginTop: 6, lineHeight: 1.6 }}>{em.sub}</div>
            </div>
          )}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 16 }}>
          <span style={{ fontSize: 12, color: colors.textSoft }}>Showing 1–{visible.length} of {tab === 'All' ? 11 : visible.length} commissions</span>
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <span style={{ height: 30, padding: '0 10px', display: 'flex', alignItems: 'center', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textFaint, background: '#fff' }}>← Prev</span>
            <span style={{ width: 30, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 7, fontSize: 12, fontWeight: 600, background: colors.ink, color: '#fff' }}>1</span>
            <span style={{ width: 30, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, background: '#fff', cursor: 'pointer' }}>2</span>
            <span style={{ height: 30, padding: '0 10px', display: 'flex', alignItems: 'center', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, background: '#fff', cursor: 'pointer' }}>Next →</span>
          </div>
        </div>
      </div>
    </>
  )
}
