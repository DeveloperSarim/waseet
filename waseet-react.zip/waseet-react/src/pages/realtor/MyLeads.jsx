import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors, radius } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { Topbar } from '../../components/layout/Topbar'
import { Avatar, Button } from '../../components/ui'

const statusTone = {
  New: { bg: '#EEF3FF', color: '#1B4FD8', bd: '#BFDBFE' },
  Contacted: { bg: '#F5F3FF', color: '#5B5BD6', bd: '#DDD6FE' },
  'Site Visit': { bg: '#EEF3FF', color: '#3730A3', bd: '#C7D2FE' },
  Negotiation: { bg: '#FFFBEB', color: '#92400E', bd: '#FDE68A' },
  Closed: { bg: '#F0FDF4', color: '#15803D', bd: '#BBF7D0' },
  Lost: { bg: '#FFF5F5', color: '#991B1B', bd: '#FECACA' },
}

const allLeads = [
  { id: 'l1', project: 'Palm Residence · 2BR', location: 'Al Rawdhah, Jeddah', client: 'Khalid M.', phone: '+966 ***** 4567', dateLabel: 'Submitted Jun 24', status: 'Negotiation', group: 'In Progress' },
  { id: 'l2', project: 'Marina Heights · Office', location: 'Dubai Marina, UAE', client: 'Sara A.', phone: '+971 ***** 2345', dateLabel: 'Submitted Jun 20', status: 'Closed', group: 'Closed', closed: true, commission: 'SAR 22,950' },
  { id: 'l3', project: 'Al Noor Tower · 1BR', location: 'Al Hamra, Riyadh', client: 'Omar K.', phone: '+966 ***** 8901', dateLabel: 'Submitted Jun 25', status: 'New', group: 'New' },
  { id: 'l4', project: 'Green Valley · Villa', location: 'Islamabad, PK', client: 'Hassan M.', phone: '+92 ***** 5678', dateLabel: 'Submitted Jun 23', status: 'Site Visit', group: 'In Progress' },
  { id: 'l5', project: 'Palm Residence · Studio', location: 'Al Rawdhah, Jeddah', client: 'Fatima K.', phone: '+966 ***** 3456', dateLabel: 'Lost · Jun 18', status: 'Lost', group: 'Lost', lost: true, resubmit: 'Resubmit after Sep 16' },
]

const tabDefs = [['All', 48], ['New', 3], ['In Progress', 12], ['Closed', 8], ['Lost', 5]]

function TabBar({ active, onChange }) {
  return (
    <div className="pd-tabs" style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '0 22px', display: 'flex', overflowX: 'auto' }}>
      {tabDefs.map(([label, count]) => {
        const on = active === label
        return (
          <div key={label} onClick={() => onChange(label)} style={{ padding: '11px 16px', fontSize: 13, cursor: 'pointer', whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', borderBottom: `2px solid ${on ? colors.ink : 'transparent'}`, color: on ? colors.ink : colors.textSoft, fontWeight: on ? 600 : 400 }}>
            {label}
            <span style={{ borderRadius: 999, padding: '1px 6px', fontSize: 10, fontWeight: 600, marginLeft: 5, background: on ? colors.ink : colors.surfaceMuted, color: on ? '#fff' : colors.textSoft }}>{count}</span>
          </div>
        )
      })}
    </div>
  )
}

export default function MyLeads() {
  const navigate = useNavigate()
  const [tab, setTab] = useState('All')
  const leads = tab === 'All' ? allLeads : allLeads.filter((l) => l.group === tab)

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>My Leads</span>
            <span style={{ fontSize: 13, color: colors.textFaint }}>48 total</span>
          </div>
        }
        actions={<Button variant="primary" onClick={() => navigate('/realtor/browse')}>Browse Projects →</Button>}
      />
      <TabBar active={tab} onChange={setTab} />

      {/* Search / filter */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '10px 22px', display: 'flex', gap: 8, alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1, maxWidth: 280 }}>
          <Icon name="search" size={14} color={colors.textFaint} strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }} />
          <input placeholder="Search by client name..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 12, fontFamily: 'inherit' }} />
        </div>
        <select style={{ height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 12, fontFamily: 'inherit', color: colors.textMuted, background: '#fff' }}><option>All Projects</option></select>
        <select style={{ height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 12, fontFamily: 'inherit', color: colors.textMuted, background: '#fff' }}><option>Date range</option></select>
      </div>

      {/* List */}
      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg }}>
        <div style={{ padding: '16px 22px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {leads.map((l) => {
            const t = statusTone[l.status]
            return (
              <div key={l.id} onClick={() => navigate('/realtor/leads/' + l.id)} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderLeft: l.closed ? `3px solid ${colors.green}` : `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px', cursor: 'pointer', opacity: l.lost ? 0.7 : 1, transition: 'all 150ms' }}>
                {l.closed && (
                  <div style={{ background: colors.greenTint, borderBottom: `1px solid ${colors.greenTintBorder}`, borderRadius: '12px 12px 0 0', padding: '8px 16px', margin: '-14px -16px 12px', display: 'flex', gap: 8, alignItems: 'center' }}>
                    <Icon name="checkCircle" size={14} color={colors.green} strokeWidth={2} />
                    <span style={{ fontSize: 12, fontWeight: 600, color: colors.greenDark }}>Deal Closed!</span>
                    <span style={{ fontSize: 12, color: colors.greenDark }}>Commission: {l.commission}</span>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>· processing</span>
                  </div>
                )}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 3 }}>{l.project}</div>
                    <div style={{ fontSize: 12, color: colors.textFaint, display: 'flex', gap: 4, alignItems: 'center' }}>
                      <Icon name="mapPin" size={11} color={colors.textFaint} strokeWidth={1.8} />{l.location}
                    </div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 5 }}>
                    <span style={{ borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 600, border: `1px solid ${t.bd}`, background: t.bg, color: t.color }}>{l.status}</span>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>{l.dateLabel}</span>
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12, paddingTop: 12, borderTop: `1px solid ${colors.surfaceMuted}` }}>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'baseline' }}>
                    <span style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted }}>{l.client}</span>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>{l.phone}</span>
                  </div>
                  {l.lost ? (
                    <span style={{ fontSize: 11, color: colors.textFaint }}>{l.resubmit}</span>
                  ) : (
                    <span style={{ fontSize: 12, color: colors.greenDark, cursor: 'pointer' }}>View details →</span>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Pagination */}
      <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '12px 22px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
        <span style={{ fontSize: 12, color: colors.textSoft }}>Showing 1–{leads.length} of {tab === 'All' ? 48 : leads.length} leads</span>
        <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
          <span style={{ height: 30, padding: '0 10px', display: 'flex', alignItems: 'center', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textFaint, background: '#fff' }}>← Prev</span>
          {['1', '2', '3'].map((n, i) => (
            <span key={n} style={{ width: 30, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 7, fontSize: 12, fontWeight: i === 0 ? 600 : 400, border: i === 0 ? 'none' : `1px solid ${colors.border}`, background: i === 0 ? colors.ink : '#fff', color: i === 0 ? '#fff' : colors.textMuted, cursor: 'pointer' }}>{n}</span>
          ))}
          <span style={{ height: 30, padding: '0 10px', display: 'flex', alignItems: 'center', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, background: '#fff', cursor: 'pointer' }}>Next →</span>
        </div>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: colors.textSoft }}>Per page</span>
          <select style={{ height: 32, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 8px', fontSize: 12, fontFamily: 'inherit', background: '#fff' }}><option>10</option><option>25</option><option>50</option></select>
        </div>
      </div>
    </>
  )
}
