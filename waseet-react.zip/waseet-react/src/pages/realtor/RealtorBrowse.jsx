import React, { useState } from 'react'
import { colors } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { useHover } from '../../hooks/useHover'
import { Topbar } from '../../components/layout/Topbar'
import { Avatar } from '../../components/ui'
import { ProjectCard } from '../../components/ProjectCard'
import { projects } from '../../data/mock'

const cityTabs = ['All', 'Riyadh', 'Jeddah', 'Dammam', 'Mecca', 'Medina', 'Khobar']
const catTabs = ['All', 'Apartments', 'Villas', 'Townhouses', 'Offices', 'Land']
const filters = [{ label: 'Property type' }, { label: 'Commission %', accent: true }, { label: 'Price range' }, { label: 'Status' }]

function FilterButton({ label, accent }) {
  const [h, hp] = useHover()
  return (
    <div {...hp} style={{ height: 34, border: `1px solid ${accent ? colors.green : colors.border}`, borderRadius: 7, padding: '0 12px', fontSize: 12, color: accent ? colors.greenDark : colors.textMuted, fontWeight: accent ? 600 : 400, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: h && !accent ? colors.surfaceAlt : '#fff' }}>
      {label}
      <Icon name="chevronDown" size={11} color={accent ? colors.green : colors.textFaint} strokeWidth={2} />
    </div>
  )
}

function Tab({ label, active, onClick }) {
  const [h, hp] = useHover()
  return (
    <div {...hp} onClick={onClick} style={{ padding: '11px 14px', fontSize: 13, whiteSpace: 'nowrap', cursor: 'pointer', color: active ? colors.ink : h ? colors.textMuted : colors.textSoft, fontWeight: active ? 600 : 400, borderBottom: `2px solid ${active ? colors.ink : 'transparent'}`, marginBottom: -1 }}>
      {label}
    </div>
  )
}

export default function RealtorBrowse() {
  const [search, setSearch] = useState('')
  const [city, setCity] = useState('All')
  const [cat, setCat] = useState('All')

  const filtered = projects.filter(
    (p) => (city === 'All' || p.city === city) && (!search || p.name.toLowerCase().includes(search.toLowerCase()) || p.developer.toLowerCase().includes(search.toLowerCase())),
  )

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>Browse Projects</span>
            <span style={{ fontSize: 13, color: colors.textFaint }}>{projects.length} live</span>
          </div>
        }
        notifications={3}
        avatar={<Avatar initials="AR" size={30} />}
      />

      {/* Filter bar */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '10px 22px', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, maxWidth: 300, minWidth: 180 }}>
          <Icon name="search" size={14} color={colors.textFaint} strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search projects, developers..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 12, fontFamily: 'inherit', color: colors.ink }} />
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {filters.map((f) => <FilterButton key={f.label} label={f.label} accent={f.accent} />)}
        </div>
        <span style={{ fontSize: 12, color: colors.textSoft, marginLeft: 'auto' }}>{filtered.length} projects</span>
      </div>

      {/* City + category tabs */}
      <div className="pd-tabs" style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '0 22px', display: 'flex', overflowX: 'auto' }}>
        {cityTabs.map((t) => <Tab key={t} label={t} active={city === t} onClick={() => setCity(t)} />)}
      </div>
      <div className="pd-tabs" style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '0 22px', display: 'flex', overflowX: 'auto' }}>
        {catTabs.map((t) => <Tab key={t} label={t} active={cat === t} onClick={() => setCat(t)} />)}
      </div>

      {/* Grid */}
      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '64px 20px', color: colors.textSoft }}>
            <Icon name="search" size={28} color={colors.textFaint} style={{ margin: '0 auto 12px' }} />
            <div style={{ fontSize: 14, fontWeight: 600, color: colors.text }}>No projects found</div>
            <div style={{ fontSize: 13, marginTop: 4 }}>Try adjusting your filters or search.</div>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
            {filtered.map((p) => <ProjectCard key={p.id} project={p} />)}
          </div>
        )}
      </div>
    </>
  )
}
