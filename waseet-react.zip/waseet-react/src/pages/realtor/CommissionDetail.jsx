import React, { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const hatch = 'repeating-linear-gradient(45deg, #ECECEE 0, #ECECEE 1px, transparent 1px, transparent 8px)'

const card = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12 }
const sectionLabel = { fontSize: 9, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em' }
const rLabel = { fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.06em' }

function renderIcon(name, color, size) {
  const sz = size || 16
  const common = { width: sz, height: sz, viewBox: '0 0 24 24', fill: 'none', stroke: color, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' }
  if (name === 'clock')
    return (
      <svg {...common}>
        <circle cx="12" cy="12" r="10" />
        <polyline points="12 6 12 12 16 14" />
      </svg>
    )
  if (name === 'check')
    return (
      <svg {...common}>
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
        <polyline points="22 4 12 14.01 9 11.01" />
      </svg>
    )
  if (name === 'refresh')
    return (
      <svg {...common} style={{ animation: 'wsk-spin 1.4s linear infinite' }}>
        <polyline points="23 4 23 10 17 10" />
        <polyline points="1 20 1 14 7 14" />
        <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
      </svg>
    )
  if (name === 'checkmini')
    return (
      <svg width={11} height={11} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
        <polyline points="20 6 9 17 4 12" />
      </svg>
    )
  return null
}

const dealDetails = [
  { label: 'Project', value: 'Palm Residence' },
  { label: 'Unit', value: 'Unit 4B · 2BR · Floor 4' },
  { label: 'Client', value: 'Khalid Al-Ansari' },
  { label: 'Client phone', value: '+966 50 123 4567' },
  { label: 'Sale price', value: 'SAR 900,000' },
  { label: 'Deal closed', value: 'June 24, 2026' },
  { label: 'Lead submitted', value: 'June 10, 2026' },
]

function buildBanner(st) {
  const base = { padding: '10px 22px', display: 'flex', gap: 10, alignItems: 'center' }
  if (st === 'pending')
    return {
      style: { ...base, borderBottom: '1px solid #FDE68A', background: '#FFFBEB' },
      icon: renderIcon('clock', '#D97706'),
      text: 'Waiting for developer to pay commission',
      sub: 'Due: July 1, 2026',
      textColor: '#92400E',
      subColor: '#D97706',
    }
  if (st === 'processing')
    return {
      style: { ...base, borderBottom: '1px solid #BFDBFE', background: '#EEF3FF' },
      icon: renderIcon('refresh', '#1B4FD8'),
      text: 'Commission payment received — processing',
      sub: 'Expected in your account: June 30 – July 2',
      textColor: '#1B4FD8',
      subColor: '#1B4FD8',
    }
  return {
    style: { ...base, borderBottom: '1px solid #BBF7D0', background: '#F0FDF4' },
    icon: renderIcon('check', '#16A34A'),
    text: 'Commission paid to your bank account',
    sub: 'Received: June 29, 2026',
    textColor: '#15803D',
    subColor: '#15803D',
  }
}

function buildStatusBox(st) {
  const base = { borderRadius: 8, padding: 12, textAlign: 'center' }
  if (st === 'pending')
    return {
      style: { ...base, border: '1px solid #F3E2B8', background: '#FEF9EC' },
      icon: renderIcon('clock', '#D97706'),
      big: 'Awaiting payment',
      bigSize: 13,
      bigColor: '#92400E',
      sub: 'Due: July 1, 2026',
      subColor: '#9CA3AF',
      third: null,
    }
  if (st === 'processing')
    return {
      style: { ...base, border: '1px solid #BFDBFE', background: '#EEF3FF' },
      icon: renderIcon('refresh', '#1B4FD8'),
      big: 'Processing',
      bigSize: 13,
      bigColor: '#1B4FD8',
      sub: 'Expected: June 30–July 2',
      subColor: '#9CA3AF',
      third: null,
    }
  return {
    style: { ...base, border: '1px solid #BBF7D0', background: '#F0FDF4' },
    icon: renderIcon('check', '#16A34A', 20),
    big: 'SAR 22,950',
    bigSize: 18,
    bigColor: '#0A0A0A',
    sub: 'Paid · June 29, 2026',
    subColor: '#15803D',
    third: 'Al Rajhi Bank',
  }
}

function buildTimeline(st) {
  const base = [
    { label: 'Deal closed', sub: 'Lead marked closed by developer', date: 'June 24, 2026' },
    { label: 'Developer paid Waseet', sub: 'SAR 27,000 received', date: 'June 27, 2026' },
  ]
  let defs
  if (st === 'pending') {
    defs = [
      { ...base[0], kind: 'done' },
      { label: 'Awaiting developer payment', sub: 'Developer has 7 days from deal close', date: 'Due: July 1, 2026', kind: 'current', amber: true },
      { label: 'Disbursement initiated', sub: 'Funds transferred', date: '—', kind: 'upcoming' },
      { label: 'In your bank account', sub: 'Al Rajhi Bank', date: '—', kind: 'upcoming' },
    ]
  } else if (st === 'processing') {
    defs = [
      { ...base[0], kind: 'done' },
      { ...base[1], kind: 'done' },
      { label: 'Payment processing', sub: 'Waseet verifying payment', date: 'Expected: June 29–30', kind: 'current', amber: true },
      { label: 'Disbursement initiated', sub: 'Funds transferred', date: '—', kind: 'upcoming' },
      { label: 'In your bank account', sub: 'Al Rajhi Bank', date: '—', kind: 'upcoming' },
    ]
  } else {
    defs = [
      { ...base[0], kind: 'done' },
      { ...base[1], kind: 'done' },
      { label: 'Payment processed', sub: 'Waseet verified payment', date: 'June 28, 2026', kind: 'done' },
      { label: 'Disbursement initiated', sub: 'Funds transferred to bank', date: 'June 29, 2026', kind: 'done' },
      { label: 'Received in your account', sub: 'Al Rajhi Bank · IBAN ·· 1234', date: 'June 29, 2026 · SAR 22,950', kind: 'done' },
    ]
  }
  return defs.map((t, i) => {
    let circleStyle = { width: 20, height: 20, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }
    let circleInner = null
    let labelColor = '#9CA3AF'
    let labelWeight = 500
    let dateColor = '#9CA3AF'
    if (t.kind === 'done') {
      circleStyle = { ...circleStyle, background: '#16A34A', border: '1px solid #16A34A' }
      circleInner = renderIcon('checkmini')
      labelColor = '#0A0A0A'
      dateColor = '#16A34A'
    } else if (t.kind === 'current') {
      const c = t.amber ? '#D97706' : '#0A0A0A'
      circleStyle = { ...circleStyle, background: c, border: `1px solid ${c}` }
      circleInner = <span style={{ width: 6, height: 6, borderRadius: 999, background: '#fff' }} />
      labelColor = '#0A0A0A'
      labelWeight = 600
      dateColor = t.amber ? '#D97706' : '#0A0A0A'
    } else {
      circleStyle = { ...circleStyle, background: '#fff', border: '1.5px solid #E5E7EB' }
    }
    return {
      label: t.label,
      sub: t.sub,
      date: t.date,
      circleStyle,
      circleInner,
      labelStyle: { fontSize: 13, fontWeight: labelWeight, color: labelColor },
      dateColor,
      showLine: i < defs.length - 1,
      lineColor: t.kind === 'done' ? '#16A34A' : '#E5E7EB',
    }
  })
}

const statusTabDefs = [
  { key: 'pending', label: 'Pending' },
  { key: 'processing', label: 'Processing' },
  { key: 'paid', label: 'Paid' },
]

export default function CommissionDetail() {
  const navigate = useNavigate()
  const [status, setStatus] = useState('processing')
  const [dispute, setDispute] = useState(false)
  const [download, setDownload] = useState('idle') // idle | loading | done
  const [showToast, setShowToast] = useState(false)
  const [toastMsg, setToastMsg] = useState('')
  const dt = useRef(null)
  const tt = useRef(null)

  useEffect(() => () => { clearTimeout(dt.current); clearTimeout(tt.current) }, [])

  const doDownload = () => {
    if (download === 'loading') return
    setDownload('loading')
    clearTimeout(dt.current)
    dt.current = setTimeout(() => {
      setDownload('done')
      setToastMsg('commission_WS-2026-042.pdf downloaded')
      setShowToast(true)
      clearTimeout(tt.current)
      tt.current = setTimeout(() => { setDownload('idle'); setShowToast(false) }, 3000)
    }, 1400)
  }

  const banner = buildBanner(status)
  const statusBox = buildStatusBox(status)
  const timeline = buildTimeline(status)

  const tabStyle = (on) => ({
    fontSize: 11,
    fontWeight: 500,
    padding: '5px 12px',
    borderRadius: 6,
    cursor: 'pointer',
    border: `1px solid ${on ? '#16A34A' : colors.border}`,
    background: on ? '#16A34A' : '#fff',
    color: on ? '#fff' : colors.textFaint,
  })

  let downloadBtnStyle = { height: 34, padding: '0 14px', borderRadius: 8, fontSize: 12, fontWeight: 500, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }
  let downloadContent
  if (download === 'done') {
    downloadBtnStyle = { ...downloadBtnStyle, background: '#F0FDF4', border: '1px solid #BBF7D0', color: '#15803D' }
    downloadContent = 'Downloaded ✓'
  } else if (download === 'loading') {
    downloadBtnStyle = { ...downloadBtnStyle, background: '#fff', border: `1px solid ${colors.border}`, color: colors.textFaint }
    downloadContent = (
      <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ width: 12, height: 12, border: `2px solid ${colors.border}`, borderTopColor: colors.textFaint, borderRadius: 999, display: 'inline-block', animation: 'wsk-spin 0.7s linear infinite' }} />
        Generating...
      </span>
    )
  } else {
    downloadBtnStyle = { ...downloadBtnStyle, background: '#fff', border: `1px solid ${colors.border}`, color: colors.textMuted }
    downloadContent = '↓ Download PDF'
  }

  return (
    <>
      <style>{`@keyframes wsk-spin { to { transform: rotate(360deg); } } @keyframes wsk-toast { from { transform: translateY(16px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }`}</style>

      <Topbar
        left={
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span onClick={() => navigate('/realtor/commissions')} style={{ fontSize: 13, color: colors.textFaint, cursor: 'pointer' }}>Commissions</span>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.borderStrong} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6" /></svg>
            <span style={{ fontSize: 13, color: colors.ink, fontWeight: 500 }}>Deal #WS-2026-042</span>
          </div>
        }
        actions={
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: 6 }}>
              {statusTabDefs.map((t) => (
                <button key={t.key} onClick={() => setStatus(t.key)} style={{ ...tabStyle(status === t.key), fontFamily: 'inherit' }}>{t.label}</button>
              ))}
            </div>
            <button onClick={doDownload} style={{ ...downloadBtnStyle }}><span>{downloadContent}</span></button>
            <button onClick={() => navigate('/realtor/commissions')} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 12, fontWeight: 500, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6" /></svg>Back
            </button>
          </div>
        }
      />

      {/* status banner */}
      <div style={banner.style}>
        <span style={{ display: 'flex' }}>{banner.icon}</span>
        <span style={{ fontSize: 13, color: banner.textColor }}>{banner.text}</span>
        <span style={{ fontSize: 12, color: banner.subColor, marginLeft: 'auto' }}>{banner.sub}</span>
      </div>

      {/* content */}
      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>

          {/* LEFT COLUMN */}
          <div style={{ flex: 2, minWidth: 0 }}>

            {/* STATEMENT CARD */}
            <div style={{ ...card, padding: '18px 20px', marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20, paddingBottom: 16, borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.ink} strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg>
                    <span style={{ fontSize: 18, fontWeight: 700, color: colors.ink }}>waseet</span>
                    <span style={{ fontSize: 12, color: colors.textFaint }}>وسيط</span>
                  </div>
                  <span style={{ fontSize: 12, color: colors.textFaint, display: 'block', marginTop: 4 }}>Commission Statement</span>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: colors.ink, marginBottom: 3 }}>Statement #WS-2026-042</div>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 2 }}>Deal closed: June 24, 2026</div>
                  <div style={{ fontSize: 11, color: colors.textFaint }}>Generated: June 29, 2026</div>
                </div>
              </div>

              {/* parties */}
              <div style={{ display: 'flex', gap: 16, marginBottom: 20 }}>
                <div style={{ flex: 1, background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '12px 14px' }}>
                  <div style={{ ...sectionLabel, marginBottom: 8 }}>Your Details</div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: colors.ink, marginBottom: 2 }}>Ahmed Al-Rashid</div>
                  <div style={{ fontSize: 11, color: colors.greenDark, marginBottom: 2 }}>🥇 Gold Realtor</div>
                  <div style={{ fontSize: 11, color: colors.textFaint }}>ahmed@gmail.com</div>
                  <div style={{ fontSize: 11, color: colors.textFaint }}>+966 50 123 4567</div>
                </div>
                <div style={{ flex: 1, background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '12px 14px' }}>
                  <div style={{ ...sectionLabel, marginBottom: 8 }}>Developer</div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: colors.ink, marginBottom: 2 }}>Al Faisal Development</div>
                  <div style={{ fontSize: 11, color: colors.green, marginBottom: 2 }}>Verified Developer ✓</div>
                  <div style={{ fontSize: 11, color: colors.textFaint }}>Jeddah, Saudi Arabia</div>
                </div>
              </div>

              {/* deal details */}
              <div style={{ marginBottom: 20 }}>
                <div style={{ ...sectionLabel, marginBottom: 12 }}>Deal Details</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 14px' }}>
                  {dealDetails.map((d) => (
                    <div key={d.label}>
                      <div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 2 }}>{d.label}</div>
                      <div style={{ fontSize: 13, color: colors.textMuted }}>{d.value}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* breakdown table */}
              <div>
                <div style={{ ...sectionLabel, marginBottom: 12 }}>Commission Breakdown</div>
                <div style={{ border: `1px solid ${colors.border}`, borderRadius: 8, overflow: 'hidden' }}>
                  <div style={{ background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '8px 14px', display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Description</span>
                    <span style={{ fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Amount</span>
                  </div>
                  <div style={{ padding: '10px 14px', borderBottom: `1px solid ${colors.surfaceMuted}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 13, color: colors.textMuted }}>Sale Price (Unit 4B · 2BR)</span>
                    <span style={{ fontSize: 13, color: colors.textMuted }}>SAR 900,000</span>
                  </div>
                  <div style={{ padding: '10px 14px', borderBottom: `1px solid ${colors.surfaceMuted}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 13, color: colors.textMuted }}>Developer Commission Rate</span>
                    <span style={{ fontSize: 13, color: colors.textMuted }}>3%</span>
                  </div>
                  <div style={{ padding: '10px 14px', borderBottom: `1px solid ${colors.surfaceMuted}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 13, color: colors.textMuted }}>Gross Commission <span style={{ fontSize: 11, color: colors.textFaint, marginLeft: 4 }}>3% × SAR 900,000</span></span>
                    <span style={{ fontSize: 13, fontWeight: 600, color: colors.ink }}>SAR 27,000</span>
                  </div>
                  <div style={{ padding: '10px 14px', borderBottom: `1px solid ${colors.surfaceMuted}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 13, color: colors.textMuted }}>Waseet Platform Fee <span style={{ fontSize: 11, color: colors.textFaint, marginLeft: 4 }}>15% of SAR 27,000</span></span>
                    <span style={{ fontSize: 12, color: colors.textFaint }}>− SAR 4,050</span>
                  </div>
                  <div style={{ background: colors.bg, padding: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 14, fontWeight: 600, color: colors.ink }}>Your commission (net)</span>
                    <span style={{ fontSize: 20, fontWeight: 700, color: colors.ink, letterSpacing: '-0.02em' }}>SAR 22,950</span>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 6, marginTop: 8, alignItems: 'flex-start' }}>
                  <svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: 1 }}><circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" /></svg>
                  <span style={{ fontSize: 11, color: colors.textFaint, lineHeight: 1.5 }}>Platform fee is deducted before disbursement. You receive SAR 22,950.</span>
                </div>
              </div>
            </div>

            {/* TIMELINE CARD */}
            <div style={{ ...card, padding: '16px 18px', marginBottom: 12 }}>
              <div style={{ ...sectionLabel, marginBottom: 16 }}>Payment Timeline</div>
              <div>
                {timeline.map((t, i) => (
                  <div key={i} style={{ display: 'flex', gap: 14 }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 20, flexShrink: 0 }}>
                      <div style={t.circleStyle}><span style={{ display: 'flex' }}>{t.circleInner}</span></div>
                      {t.showLine && <div style={{ width: 1.5, height: 34, margin: '3px 0', background: t.lineColor }} />}
                    </div>
                    <div style={{ paddingBottom: 20, flex: 1 }}>
                      <div style={t.labelStyle}>{t.label}</div>
                      <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>{t.sub}</div>
                      <div style={{ fontSize: 11, marginTop: 2, color: t.dateColor }}>{t.date}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* BANK CARD */}
            <div style={{ ...card, padding: '14px 18px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <span style={sectionLabel}>Payment Destination</span>
                <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><title>Bank details are encrypted</title><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
              </div>
              <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
                <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}><path d="M3 21h18M3 10h18M5 6l7-3 7 3M4 10v11M20 10v11M9 14v3M15 14v3" /></svg>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: colors.ink, marginBottom: 2 }}>Al Rajhi Bank</div>
                  <div style={{ fontSize: 12, color: colors.textMuted, marginBottom: 2 }}>Ahmed Mohammed Al-Rashid</div>
                  <div style={{ fontSize: 12, color: colors.textFaint }}>IBAN: SA** **** **** **** **** 1234</div>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>Saudi Arabia 🇸🇦</div>
                </div>
              </div>
              <div onClick={() => navigate('/realtor/settings')} style={{ fontSize: 12, color: colors.greenDark, marginTop: 10, cursor: 'pointer', display: 'inline-block' }}>Update bank details →</div>
            </div>

          </div>

          {/* RIGHT COLUMN */}
          <div style={{ flex: 1, minWidth: 0, position: 'sticky', top: 0 }}>

            {/* AMOUNT CARD */}
            <div style={{ ...card, padding: 16, marginBottom: 12 }}>
              <div style={{ ...rLabel, marginBottom: 12 }}>Your Commission</div>
              <div style={{ textAlign: 'center', marginBottom: 14 }}>
                <div style={{ fontSize: 28, fontWeight: 700, color: colors.ink, letterSpacing: '-0.03em' }}>SAR 22,950</div>
                <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 4 }}>(net after platform fee)</div>
              </div>
              <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '10px 12px', marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}><span style={{ fontSize: 11, color: colors.textFaint }}>Sale price:</span><span style={{ fontSize: 12, color: colors.textMuted }}>SAR 900,000</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}><span style={{ fontSize: 11, color: colors.textFaint }}>Gross (3%):</span><span style={{ fontSize: 12, color: colors.textMuted }}>SAR 27,000</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 11, color: colors.textFaint }}>Fee (15%):</span><span style={{ fontSize: 12, color: colors.textMuted }}>− SAR 4,050</span></div>
                <div style={{ height: 1, background: colors.border, margin: '8px 0' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontSize: 12, fontWeight: 600, color: colors.ink }}>Net to you:</span><span style={{ fontSize: 13, fontWeight: 700, color: colors.ink }}>SAR 22,950</span></div>
              </div>
              {/* payment status box */}
              <div style={statusBox.style}>
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 5 }}>{statusBox.icon}</div>
                <div style={{ fontSize: statusBox.bigSize, fontWeight: 700, color: statusBox.bigColor }}>{statusBox.big}</div>
                <div style={{ fontSize: 12, color: statusBox.subColor, marginTop: 3 }}>{statusBox.sub}</div>
                {statusBox.third && <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>{statusBox.third}</div>}
              </div>
            </div>

            {/* PROJECT QUICK VIEW */}
            <div style={{ ...card, padding: '14px 16px', marginBottom: 12 }}>
              <div style={{ ...rLabel, marginBottom: 12 }}>Project</div>
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                <div style={{ width: 56, height: 42, borderRadius: 7, backgroundColor: colors.surfaceMuted, backgroundImage: hatch, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: colors.ink, marginBottom: 2 }}>Palm Residence</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 3 }}>
                    <svg width={11} height={11} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>Al Rawdhah, Jeddah</span>
                  </div>
                  <div style={{ fontSize: 11, color: colors.textMuted }}>Unit 4B · 2BR</div>
                </div>
              </div>
              <div onClick={() => navigate('/project/palm-residence')} style={{ fontSize: 12, color: colors.greenDark, marginTop: 10, cursor: 'pointer', display: 'inline-block' }}>View project →</div>
            </div>

            {/* LEAD QUICK VIEW */}
            <div style={{ ...card, padding: '14px 16px', marginBottom: 12 }}>
              <div style={{ ...rLabel, marginBottom: 12 }}>Lead</div>
              <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <div style={{ width: 36, height: 36, borderRadius: 999, background: colors.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#fff', flexShrink: 0 }}>KA</div>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: colors.ink, marginBottom: 2 }}>Khalid Al-Ansari</div>
                  <div style={{ fontSize: 11, color: colors.textMuted, marginBottom: 2 }}>+966 50 123 4567</div>
                  <div style={{ fontSize: 11, color: colors.textFaint }}>Submitted: June 10, 2026</div>
                </div>
              </div>
              <div style={{ marginTop: 10 }}><span style={{ fontSize: 11, fontWeight: 600, color: colors.greenDark, background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 999, padding: '3px 10px' }}>Closed ✓</span></div>
              <div onClick={() => navigate('/realtor/leads')} style={{ fontSize: 12, color: colors.greenDark, marginTop: 8, cursor: 'pointer', display: 'inline-block' }}>View lead details →</div>
            </div>

            {/* DISPUTE CARD */}
            <div style={{ ...card, padding: '14px 16px' }}>
              <div style={{ ...rLabel, marginBottom: 10 }}>Dispute</div>
              {!dispute ? (
                <div>
                  <div style={{ fontSize: 12, color: colors.textSoft, lineHeight: 1.6, marginBottom: 12 }}>If there's an issue with this commission, you can raise a dispute.</div>
                  <button onClick={() => setDispute(true)} style={{ width: '100%', height: 34, background: '#fff', border: `1px solid ${colors.redTintBorder}`, borderRadius: 7, fontSize: 12, fontWeight: 500, color: colors.red, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                    <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.red} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" /><line x1="4" y1="22" x2="4" y2="15" /></svg>Raise Dispute
                  </button>
                </div>
              ) : (
                <div style={{ background: colors.redTint, border: `1px solid ${colors.redTintBorder}`, borderRadius: 8, padding: 12, textAlign: 'center' }}>
                  <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 6 }}>
                    <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.red} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M14 13l-7.5 7.5a2.12 2.12 0 0 1-3-3L11 10M9 7l4-4 7 7-4 4M14 4l6 6" /></svg>
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#991B1B' }}>Dispute #D-0012 raised</div>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>Under review · Opened Jun 27</div>
                  <div onClick={() => navigate('/realtor/commissions')} style={{ fontSize: 12, color: colors.red, marginTop: 8, cursor: 'pointer' }}>View Dispute →</div>
                </div>
              )}
            </div>

          </div>
        </div>
      </div>

      {/* toast */}
      {showToast && (
        <div style={{ position: 'fixed', bottom: 22, right: 22, background: colors.ink, color: '#fff', borderRadius: 10, padding: '12px 16px', fontSize: 13, fontWeight: 500, boxShadow: '0 8px 24px rgba(0,0,0,0.2)', animation: 'wsk-toast 300ms ease-out', zIndex: 80 }}>{toastMsg}</div>
      )}
    </>
  )
}
