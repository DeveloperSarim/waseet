import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const markers = [
  { left: '0%', color: '#16A34A', label: 'Bronze ✓' },
  { left: '33%', color: '#16A34A', label: 'Silver ✓' },
  { left: '60%', color: '#16A34A', label: 'Gold ✓' },
  { left: '100%', color: '#D1D5DB', label: 'Platinum' },
]

const check = 'M20 6L9 17l-5-5'
const circle = 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z'
const lockI = 'M5 11V7a5 5 0 0 1 10 0v4M5 11h14v10H5z'

const reqDone = (label) => ({ label, color: '#16A34A', textColor: '#374151', icon: check, hasBar: false })
const unlockDone = (label) => ({ label, color: '#16A34A', textColor: '#374151', icon: check })
const unlockLocked = (label) => ({ label, color: '#9CA3AF', textColor: '#9CA3AF', icon: lockI })

const achievedStatus = { display: 'inline-flex', alignItems: 'center', gap: 5, background: '#F0FDF4', border: '1px solid #BBF7D0', borderRadius: 999, padding: '4px 10px', fontSize: 11, fontWeight: 600, color: '#15803D' }
const currentStatus = { display: 'inline-flex', alignItems: 'center', gap: 5, background: '#F0FDF4', border: '1px solid #BBF7D0', borderRadius: 999, padding: '4px 10px', fontSize: 11, fontWeight: 600, color: '#15803D' }
const lockedStatus = { display: 'inline-flex', alignItems: 'center', gap: 5, background: '#F3F4F6', border: '1px solid #E5E7EB', borderRadius: 999, padding: '4px 10px', fontSize: 11, fontWeight: 600, color: '#374151' }

const cardBase = { background: '#fff', border: '1px solid #E5E7EB', borderRadius: 12, overflow: 'hidden' }

const tiers = [
  {
    emoji: '🥉', name: 'Bronze Realtor', tagline: 'Starting badge',
    cardStyle: { ...cardBase, borderLeft: '3px solid #E5E7EB' },
    statusStyle: achievedStatus, statusText: '✓ Achieved', statusDot: false,
    reqs: [reqDone('New approved realtor account'), reqDone('License verified by Waseet')],
    unlocks: [unlockDone('Access to all marketplace projects'), unlockDone('Submit unlimited client leads'), unlockDone('Real-time lead status tracking')],
    hasNote: false,
  },
  {
    emoji: '🥈', name: 'Silver Realtor', tagline: '5+ leads or 1 closed deal',
    cardStyle: { ...cardBase, borderLeft: '3px solid #E5E7EB' },
    statusStyle: achievedStatus, statusText: '✓ Achieved', statusDot: false,
    reqs: [reqDone('5 leads submitted, or 1 deal closed'), reqDone('You achieved: 8 deals')],
    unlocks: [unlockDone('Priority new project notifications'), unlockDone('Lead submission limit increased'), unlockDone('Access to project analytics summary')],
    hasNote: false,
  },
  {
    emoji: '🥇', name: 'Gold Realtor', tagline: '3+ closed deals',
    cardStyle: { ...cardBase, borderLeft: '3px solid #16A34A' },
    statusStyle: currentStatus, statusText: 'Your current badge', statusDot: true,
    reqs: [reqDone('3 deals closed (you have 8)'), reqDone('All previous requirements met')],
    unlocks: [unlockDone('Full project analytics access'), unlockDone('Higher priority in developer search'), unlockDone('Dedicated support channel'), unlockDone('Gold badge displayed on all leads')],
    hasNote: true, note: 'Achieved March 2026 · 8 deals closed total', noteColor: '#15803D',
  },
  {
    emoji: '💎', name: 'Platinum Realtor', tagline: '10 closed deals',
    cardStyle: { ...cardBase, borderLeft: '3px solid #E5E7EB', opacity: 0.88 },
    statusStyle: lockedStatus, statusText: '🔒 2 deals to unlock', statusDot: false,
    reqs: [
      { label: '10 deals closed', color: '#D97706', textColor: '#374151', icon: circle, hasBar: true, barLabel: '8 / 10' },
      reqDone('All previous requirements met'),
    ],
    unlocks: [unlockLocked('Direct developer contact (WhatsApp)'), unlockLocked('Fastest commission disbursement'), unlockLocked('Platinum badge — premium positioning'), unlockLocked('Priority customer support'), unlockLocked('Exclusive platform invitations')],
    hasNote: true, note: '🎯 Close 2 more deals to unlock Platinum and all its exclusive benefits.', noteColor: '#374151',
  },
]

const perfStats = [
  { icon: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z', value: '48', label: 'Leads · All time' },
  { icon: 'M8 11l3 3 5-6M20 6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2z', value: '8', label: 'Deals · All time' },
  { icon: 'M19 5L5 19M6.5 8a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM17.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z', value: '16.7%', label: 'Conversion' },
  { icon: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 7v10', value: 'SAR 139k', label: 'Total earned' },
]

const milestones = [
  { title: 'Reached Gold Realtor badge', date: 'March 2026', emoji: '🥇' },
  { title: 'Closed deal #5 — Silver unlocked', date: 'February 2026', emoji: '🥈' },
  { title: 'First closed deal!', date: 'January 2026', emoji: '🎉' },
  { title: 'First lead submitted', date: 'January 2026', emoji: '⭐' },
]

const perks = ['Full project analytics access', 'Higher priority in developer search', 'Dedicated support channel']

// confetti particles
const confettiColors = ['#16A34A', '#ffffff', '#D1D5DB', '#BBF7D0']
const confetti = []
for (let i = 0; i < 40; i++) {
  const c = confettiColors[i % confettiColors.length]
  const left = Math.round((i * 2.5) % 100)
  const dur = (2.5 + (i % 5) * 0.6).toFixed(1)
  const delay = ((i % 7) * 0.35).toFixed(2)
  confetti.push({ left: `${left}%`, background: c, animationDuration: `${dur}s`, animationDelay: `${delay}s` })
}

const bpKeyframes = `
@keyframes bp-pulse-dot { 0%,100% { opacity: 1; } 50% { opacity: 0.35; } }
@keyframes bp-badge-pop { 0% { transform: scale(0); } 60% { transform: scale(1.2); } 100% { transform: scale(1); } }
@keyframes bp-confetti-fall { 0% { transform: translateY(-20vh) rotate(0); opacity: 1; } 100% { transform: translateY(100vh) rotate(540deg); opacity: 0; } }
.bp-confetti { position: absolute; width: 9px; height: 9px; border-radius: 2px; animation-name: bp-confetti-fall; animation-timing-function: linear; animation-iteration-count: infinite; }
`

export default function BadgeProgress() {
  const navigate = useNavigate()
  const [celebrating, setCelebrating] = useState(false)

  return (
    <>
      <style>{bpKeyframes}</style>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span onClick={() => navigate('/realtor/profile')} style={{ fontSize: 13, color: colors.textFaint, cursor: 'pointer' }}>My Profile</span>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" strokeWidth={2}><path d="M9 6l6 6-6 6" /></svg>
            <span style={{ fontSize: 13, color: colors.ink, fontWeight: 500 }}>Badge Progress</span>
          </div>
        }
        right={
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 11, color: colors.textFaint, display: 'flex', alignItems: 'center', gap: 4 }}>
              <svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8}><path d="M23 4v6h-6M1 20v-6h6M3.5 9a9 9 0 0 1 14.8-3.4L23 10M1 14l4.7 4.4A9 9 0 0 0 20.5 15" /></svg>
              Updated in real time
            </span>
            <button onClick={() => setCelebrating(true)} style={{ height: 30, padding: '0 12px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>▶ Preview celebration</button>
          </div>
        }
      />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div style={{ maxWidth: 860, margin: '0 auto' }}>

          {/* HERO */}
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '22px 24px', marginBottom: 16, display: 'flex', gap: 24, alignItems: 'center' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '0 20px', borderRight: `1px solid ${colors.surfaceMuted}` }}>
              <div style={{ fontSize: 56, marginBottom: 8, lineHeight: 1 }}>🥇</div>
              <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 4 }}>Gold Realtor</div>
              <div style={{ fontSize: 12, color: colors.textFaint }}>Since March 2026</div>
              <div style={{ display: 'flex', gap: 20, marginTop: 16, paddingTop: 16, borderTop: `1px solid ${colors.surfaceMuted}` }}>
                {[['8', 'Deals'], ['48', 'Leads'], ['16.7%', 'Conversion']].map(([v, l]) => (
                  <div key={l} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <span style={{ fontSize: 18, fontWeight: 700 }}>{v}</span>
                    <span style={{ fontSize: 10, color: colors.textFaint, marginTop: 2 }}>{l}</span>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16 }}>Progress to Platinum 💎</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 12, color: colors.textMuted }}>8 of 10 deals</span>
                <span style={{ fontSize: 12, color: colors.green, fontWeight: 500 }}>2 more deals</span>
              </div>
              <div style={{ position: 'relative', marginBottom: 28 }}>
                <div style={{ background: colors.surfaceMuted, height: 8, borderRadius: 999, overflow: 'hidden' }}><div style={{ background: colors.green, height: '100%', width: '80%', transition: 'width 600ms ease' }} /></div>
                {markers.map((m) => (
                  <div key={m.label} style={{ position: 'absolute', top: -2, left: m.left, transform: 'translateX(-50%)', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#fff', border: `2px solid ${m.color}` }} />
                    <span style={{ fontSize: 9, color: colors.textFaint, marginTop: 4, whiteSpace: 'nowrap' }}>{m.label}</span>
                  </div>
                ))}
              </div>
              <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '12px 14px', display: 'flex', gap: 12, alignItems: 'center' }}>
                <span style={{ fontSize: 24 }}>💎</span>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 3 }}>Platinum Realtor</div>
                  <div style={{ fontSize: 12, color: colors.textSoft }}>2 more closed deals required</div>
                </div>
              </div>
            </div>
          </div>

          {/* TIER CARDS */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 16 }}>
            {tiers.map((t) => (
              <div key={t.name} style={t.cardStyle}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 18px', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                    <span style={{ fontSize: 28 }}>{t.emoji}</span>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 600 }}>{t.name}</div>
                      <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 2 }}>{t.tagline}</div>
                    </div>
                  </div>
                  <span style={t.statusStyle}>
                    {t.statusDot && <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#16A34A', animation: 'bp-pulse-dot 1.6s infinite' }} />}
                    {t.statusText}
                  </span>
                </div>
                <div style={{ padding: '14px 18px', display: 'flex', gap: 20 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 10 }}>Requirements</div>
                    {t.reqs.map((r, i) => (
                      <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginBottom: 6 }}>
                        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={r.color} strokeWidth={2} style={{ flexShrink: 0 }}><path d={r.icon} /></svg>
                        <div style={{ flex: 1 }}>
                          <span style={{ fontSize: 12, color: r.textColor }}>{r.label}</span>
                          {r.hasBar && (
                            <div style={{ marginTop: 5 }}>
                              <div style={{ fontSize: 11, color: '#D97706', marginBottom: 3 }}>{r.barLabel}</div>
                              <div style={{ background: colors.surfaceMuted, height: 3, borderRadius: 999, overflow: 'hidden', maxWidth: 120 }}><div style={{ background: colors.green, height: '100%', width: '80%' }} /></div>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 10 }}>What you unlock</div>
                    {t.unlocks.map((u, i) => (
                      <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
                        <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={u.color} strokeWidth={2} style={{ flexShrink: 0 }}><path d={u.icon} /></svg>
                        <span style={{ fontSize: 12, color: u.textColor }}>{u.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
                {t.hasNote && (
                  <div style={{ margin: '0 18px 14px' }}>
                    <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '10px 12px', fontSize: 12, color: t.noteColor, lineHeight: 1.5 }}>{t.note}</div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* PERFORMANCE */}
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 18px', marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>My Performance</span>
              <span style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
                Last 30 days <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={2}><path d="M6 9l6 6 6-6" /></svg>
              </span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
              {perfStats.map((p) => (
                <div key={p.label} style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 10, padding: '12px 14px' }}>
                  <div style={{ width: 28, height: 28, borderRadius: 7, background: colors.greenTint, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}>
                    <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.8}><path d={p.icon} /></svg>
                  </div>
                  <div style={{ fontSize: 18, fontWeight: 700 }}>{p.value}</div>
                  <div style={{ fontSize: 10, color: colors.textFaint, marginTop: 2 }}>{p.label}</div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${colors.surfaceMuted}` }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: colors.textMuted, marginBottom: 10 }}>Recent milestones</div>
              {milestones.map((m, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'center', padding: '8px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                  <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth={1.8} style={{ flexShrink: 0 }}><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM5 9H3a2 2 0 0 1-2-2V5h4M19 9h2a2 2 0 0 0 2-2V5h-4" /></svg>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, fontWeight: 500 }}>{m.title}</div>
                    <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>{m.date}</div>
                  </div>
                  <span style={{ fontSize: 14 }}>{m.emoji}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* CELEBRATION OVERLAY */}
      {celebrating && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)', zIndex: 90, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', overflow: 'hidden' }}>
          {confetti.map((c, i) => (
            <span key={i} className="bp-confetti" style={{ left: c.left, background: c.background, animationDuration: c.animationDuration, animationDelay: c.animationDelay }} />
          ))}
          <div style={{ fontSize: 80, lineHeight: 1, animation: 'bp-badge-pop 600ms ease' }}>🥇</div>
          <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: '-0.02em', color: '#fff', marginTop: 16, marginBottom: 4 }}>Congratulations!</div>
          <div style={{ fontSize: 16, color: 'rgba(255,255,255,0.7)', marginBottom: 24 }}>You've reached Gold Realtor!</div>
          <div style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', borderRadius: 12, padding: '18px 24px', marginBottom: 24, minWidth: 320 }}>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.6)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>You've unlocked:</div>
            {perks.map((p) => (
              <div key={p} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth={2} style={{ flexShrink: 0 }}><path d="M20 6L9 17l-5-5" /></svg>
                <span style={{ fontSize: 13, color: '#fff' }}>{p}</span>
              </div>
            ))}
          </div>
          <button onClick={() => setCelebrating(false)} style={{ height: 48, padding: '0 28px', background: colors.green, border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Continue to Dashboard</button>
          <div onClick={() => setCelebrating(false)} style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginTop: 12, cursor: 'pointer' }}>Dismiss</div>
        </div>
      )}
    </>
  )
}
