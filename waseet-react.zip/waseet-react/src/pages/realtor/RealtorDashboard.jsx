import React from 'react'
import { Link } from 'react-router-dom'
import { colors, radius } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'
import { PortalMain } from '../../components/layout/PortalLayout'
import { Avatar } from '../../components/ui'

const kpis = [
  { label: 'My Leads', value: '48', sub: '+3 new this week', subColor: colors.green, d: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8' },
  { label: 'Deals Closed', value: '8', sub: 'all time', subColor: colors.textSoft, d: 'M11 17a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M13 7a5 5 0 0 0-7 0L3 10a5 5 0 0 0 7 7l1-1' },
  { label: 'Total Earned', value: 'SAR 139k', sub: 'all time', subColor: colors.textSoft, d: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 7v10M9.5 9.5c0-1 1.1-1.5 2.5-1.5s2.5.5 2.5 1.5-1.1 1.5-2.5 1.5-2.5.5-2.5 1.5 1.1 1.5 2.5 1.5 2.5-.5 2.5-1.5' },
  { label: 'Pending', value: 'SAR 22.9k', sub: 'processing', subColor: colors.textSoft, d: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2' },
]

const activity = [
  { dot: colors.green, title: 'Marina Heights · Sara A.', sub: 'Deal Closed! Commission: SAR 22,950', time: 'Yesterday' },
  { dot: colors.textSoft, title: 'Palm Residence · Khalid M.', sub: 'Status: New → Contacted', time: '2 hrs ago' },
  { dot: '#1B4FD8', title: 'Al Noor Tower · Omar K.', sub: 'Status: Contacted → Site Visit', time: 'Jun 25' },
]

const newProjects = [
  { name: 'Corniche Suites', loc: 'Al Corniche, Jeddah', comm: '3%' },
  { name: 'Al Noor Tower', loc: 'Al Hamra, Riyadh', comm: '4%' },
  { name: 'Palm Residence', loc: 'Al Rawdhah, Jeddah', comm: '3%' },
]

const card = {
  background: '#fff',
  border: `1px solid ${colors.border}`,
  borderRadius: radius.xl,
  padding: '14px 16px',
  marginBottom: 14,
}

const sectionHeader = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }
const viewAll = { fontSize: 12, color: colors.greenDark, cursor: 'pointer' }

export default function RealtorDashboard() {
  return (
    <>
      <Topbar title="Dashboard" notifications={2} avatar={<Avatar initials="AR" size={32} />} />
      <div style={{ flex: 1, overflowY: 'auto', padding: '18px 22px' }}>
        {/* Bank alert */}
        <div
          style={{
            background: '#fff',
            border: `1px solid ${colors.border}`,
            borderLeft: `3px solid ${colors.amber}`,
            borderRadius: 8,
            padding: '10px 14px',
            marginBottom: 14,
            display: 'flex',
            gap: 10,
            alignItems: 'center',
          }}
        >
          <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8} style={{ flexShrink: 0 }}>
            <path d="M12 2L1 21h22z" />
            <path d="M12 9v5M12 17h.01" />
          </svg>
          <span style={{ fontSize: 13, color: colors.textMuted }}>Add your bank details to receive commission payments</span>
          <Link to="/realtor/settings" style={{ fontSize: 12, color: colors.greenDark, fontWeight: 500, marginLeft: 'auto', cursor: 'pointer', whiteSpace: 'nowrap' }}>
            Add bank details →
          </Link>
        </div>

        {/* Badge / tier progress */}
        <div style={{ ...card }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <span style={{ fontSize: 22 }}>🥇</span>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>Gold Realtor</div>
                <div style={{ fontSize: 11, color: colors.textFaint }}>Active since Jan 2026</div>
              </div>
            </div>
            <span style={{ fontSize: 12, color: colors.textSoft }}>2 more deals to Platinum 💎</span>
          </div>
          <div style={{ marginTop: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 9, color: colors.textFaint, marginBottom: 4 }}>
              <span>Bronze</span>
              <span>Silver</span>
              <span>Gold</span>
              <span>Platinum</span>
            </div>
            <div style={{ height: 4, background: colors.surfaceMuted, borderRadius: 999, overflow: 'hidden' }}>
              <div style={{ width: '80%', height: '100%', background: colors.green, borderRadius: 999 }} />
            </div>
          </div>
        </div>

        {/* KPIs */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: 12, marginBottom: 14 }}>
          {kpis.map((k) => (
            <div key={k.label} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: radius.xl, padding: '14px 16px' }}>
              <div style={{ width: 32, height: 32, background: colors.greenTint, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 10 }}>
                <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round">
                  <path d={k.d} />
                </svg>
              </div>
              <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 6 }}>{k.label}</div>
              <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em' }}>{k.value}</div>
              <div style={{ fontSize: 11, color: k.subColor, marginTop: 4 }}>{k.sub}</div>
            </div>
          ))}
        </div>

        {/* Recent activity */}
        <div style={{ ...card }}>
          <div style={sectionHeader}>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Recent activity</span>
            <span style={viewAll}>View all →</span>
          </div>
          {activity.map((a, i) => (
            <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', padding: '10px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: a.dot, flexShrink: 0, marginTop: 5 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{a.title}</div>
                <div style={{ fontSize: 12, color: colors.textSoft, marginTop: 2 }}>{a.sub}</div>
              </div>
              <span style={{ fontSize: 11, color: colors.textFaint, flexShrink: 0 }}>{a.time}</span>
            </div>
          ))}
        </div>

        {/* New this week */}
        <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: radius.xl, padding: '14px 16px' }}>
          <div style={{ ...sectionHeader, marginBottom: 4 }}>
            <span style={{ fontSize: 14, fontWeight: 600 }}>New this week</span>
            <Link to="/realtor/browse" style={viewAll}>View all →</Link>
          </div>
          {newProjects.map((p, i) => (
            <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'center', padding: '10px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
              <div
                style={{
                  width: 40,
                  height: 32,
                  minWidth: 40,
                  borderRadius: 5,
                  background: colors.surfaceMuted,
                  backgroundImage: 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 7px)',
                }}
              />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 600 }}>{p.name}</div>
                <div style={{ fontSize: 10, color: colors.textFaint }}>{p.loc}</div>
              </div>
              <span style={{ background: colors.ink, color: '#fff', borderRadius: 4, padding: '2px 7px', fontSize: 10, fontWeight: 700 }}>{p.comm}</span>
            </div>
          ))}
        </div>
      </div>
    </>
  )
}
