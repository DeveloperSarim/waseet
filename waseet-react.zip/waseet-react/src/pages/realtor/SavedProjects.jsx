import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const offPlan = { background: '#FEF9EC', borderRadius: 5, padding: '2px 8px', fontSize: 11, color: '#92763A', fontWeight: 500 }
const ready = { background: '#F0FDF4', borderRadius: 5, padding: '2px 8px', fontSize: 11, color: '#15803D', fontWeight: 500 }
const underC = { background: '#F3F4F6', borderRadius: 5, padding: '2px 8px', fontSize: 11, color: '#374151', fontWeight: 500 }

const data = [
  { name: 'Palm Residence', featured: true, isNew: false, location: 'Al Rawdhah, Jeddah', devInit: 'AF', developer: 'Al Faisal Dev', price: 'SAR 650k–1.2M', type: 'Apartments', statusPill: 'Off-plan', statusPillStyle: offPlan, commission: '3%', saved: 'Jun 24', hasLead: false, leadStatus: '', leadLabel: 'No lead yet', leadColor: '#9CA3AF' },
  { name: 'Marina Heights', featured: false, isNew: false, location: 'Dubai Marina, UAE', devInit: 'MC', developer: 'Marina Corp', price: 'AED 800k–2M', type: 'Offices', statusPill: 'Ready', statusPillStyle: ready, commission: '2.5%', saved: 'Jun 20', hasLead: true, leadStatus: 'Lead submitted · Negotiation', leadLabel: 'Lead: Negotiation', leadColor: '#15803D' },
  { name: 'Al Noor Tower', featured: false, isNew: true, location: 'Al Hamra, Riyadh', devInit: 'NG', developer: 'Noor Group', price: 'SAR 1.1M–3M', type: 'Villas', statusPill: 'Off-plan', statusPillStyle: offPlan, commission: '4%', saved: 'Jun 26', hasLead: false, leadStatus: '', leadLabel: 'No lead yet', leadColor: '#9CA3AF' },
  { name: 'Green Valley', featured: false, isNew: false, location: 'Islamabad, PK', devInit: 'EB', developer: 'Emerald Builders', price: 'PKR 45M–80M', type: 'Townhouses', statusPill: 'Under Const.', statusPillStyle: underC, commission: '3.5%', saved: 'Jun 18', hasLead: true, leadStatus: 'Lead submitted · Closed ✓', leadLabel: 'Lead: Closed', leadColor: '#15803D' },
  { name: 'Corniche Suites', featured: true, isNew: false, location: 'Al Corniche, Jeddah', devInit: 'CD', developer: 'Coast Dev', price: 'SAR 900k–1.8M', type: 'Apartments', statusPill: 'Ready', statusPillStyle: ready, commission: '3%', saved: 'Jun 22', hasLead: false, leadStatus: '', leadLabel: 'No lead yet', leadColor: '#9CA3AF' },
  { name: 'Business Bay Tower', featured: false, isNew: false, location: 'Dubai, UAE', devInit: 'BD', developer: 'Bay Developers', price: 'AED 1.2M–3.5M', type: 'Offices', statusPill: 'Off-plan', statusPillStyle: offPlan, commission: '2%', saved: 'Jun 15', hasLead: false, leadStatus: '', leadLabel: 'No lead yet', leadColor: '#9CA3AF' },
]
const cards = data.map((c) => ({ ...c, noLead: !c.hasLead }))

const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 9px)'

export default function SavedProjects() {
  const navigate = useNavigate()
  const [view, setView] = useState('grid')
  const isGrid = view === 'grid'

  const segActive = { display: 'flex', alignItems: 'center', justifyContent: 'center', width: 34, height: 34, cursor: 'pointer', background: '#0A0A0A', color: '#fff' }
  const segIdle = { display: 'flex', alignItems: 'center', justifyContent: 'center', width: 34, height: 34, cursor: 'pointer', background: '#fff', color: '#9CA3AF' }

  const filterChip = { height: 34, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff' }

  const bookmarkIcon = (
    <svg width={15} height={15} viewBox="0 0 24 24" fill="#16A34A" stroke="#16A34A" strokeWidth={1.5}>
      <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
    </svg>
  )
  const chevron = (
    <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={2}>
      <path d="M6 9l6 6 6-6" />
    </svg>
  )
  const checkCircle = (
    <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth={2}>
      <circle cx="12" cy="12" r="10" />
      <path d="M8 12l3 3 5-6" />
    </svg>
  )

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>Saved Projects</span>
            <span style={{ fontSize: 13, color: colors.textFaint }}>8 saved</span>
          </div>
        }
        actions={
          <button
            onClick={() => navigate('/realtor/browse')}
            style={{ height: 34, padding: '0 14px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}
          >
            Browse marketplace →
          </button>
        }
      />

      {/* FILTER BAR */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '10px 22px', display: 'flex', gap: 8, alignItems: 'center' }}>
        <div style={{ flex: 1, maxWidth: 260, position: 'relative' }}>
          <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}>
            <circle cx="11" cy="11" r="8" />
            <path d="M21 21l-4.3-4.3" />
          </svg>
          <input placeholder="Search saved projects..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 12, fontFamily: 'inherit' }} />
        </div>
        <span style={filterChip}>City {chevron}</span>
        <span style={filterChip}>Type {chevron}</span>
        <span style={{ ...filterChip, marginLeft: 'auto' }}>Recently saved {chevron}</span>
        <div style={{ display: 'flex', border: `1px solid ${colors.border}`, borderRadius: 7, overflow: 'hidden' }}>
          <span onClick={() => setView('grid')} style={isGrid ? segActive : segIdle}>
            <svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
              <rect x="3" y="3" width="7" height="7" rx="1" />
              <rect x="14" y="3" width="7" height="7" rx="1" />
              <rect x="3" y="14" width="7" height="7" rx="1" />
              <rect x="14" y="14" width="7" height="7" rx="1" />
            </svg>
          </span>
          <span onClick={() => setView('list')} style={!isGrid ? segActive : segIdle}>
            <svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8}>
              <path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
            </svg>
          </span>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        {/* GRID VIEW */}
        {isGrid && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16, gridAutoRows: '1fr' }}>
            {cards.map((c, i) => (
              <div key={i} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', cursor: 'pointer', transition: 'all 200ms', height: '100%', display: 'flex', flexDirection: 'column' }}>
                <div style={{ height: 180, background: '#F3F4F6', backgroundImage: hatch, position: 'relative' }}>
                  <div style={{ position: 'absolute', top: 10, left: 10, display: 'flex', gap: 5 }}>
                    {c.featured && <span style={{ background: '#F0FDF4', border: '1px solid #BBF7D0', color: '#15803D', borderRadius: 999, padding: '3px 8px', fontSize: 10, fontWeight: 600 }}>FEATURED</span>}
                    {c.isNew && <span style={{ background: '#FEF9EC', border: '1px solid #F3E2B8', color: '#92400E', borderRadius: 999, padding: '3px 8px', fontSize: 10, fontWeight: 600 }}>NEW</span>}
                  </div>
                  <div style={{ position: 'absolute', top: 10, right: 10, width: 30, height: 30, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
                    {bookmarkIcon}
                  </div>
                  <div style={{ position: 'absolute', bottom: 10, left: 10, background: 'rgba(0,0,0,0.5)', borderRadius: 999, padding: '3px 8px' }}>
                    <span style={{ fontSize: 9, color: '#fff' }}>Saved {c.saved}</span>
                  </div>
                  <div style={{ position: 'absolute', bottom: 10, right: 10, background: '#0A0A0A', borderRadius: 6, padding: '4px 10px' }}>
                    <span style={{ fontSize: 11, fontWeight: 700, color: '#fff' }}>{c.commission} Commission</span>
                  </div>
                </div>
                <div style={{ padding: '12px 14px', flex: 1, display: 'flex', flexDirection: 'column' }}>
                  <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 3 }}>{c.name}</div>
                  <div style={{ display: 'flex', gap: 4, alignItems: 'center', marginBottom: 4 }}>
                    <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8}>
                      <path d="M12 22s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11z" />
                      <circle cx="12" cy="11" r="2" />
                    </svg>
                    <span style={{ fontSize: 12, color: '#9CA3AF' }}>{c.location}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 5, alignItems: 'center', marginBottom: 8 }}>
                    <span style={{ width: 18, height: 18, borderRadius: '50%', background: '#F3F4F6', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 8, fontWeight: 600, color: '#374151' }}>{c.devInit}</span>
                    <span style={{ fontSize: 11, color: '#6B7280' }}>{c.developer}</span>
                    {checkCircle}
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>{c.price}</div>
                  <div style={{ display: 'flex', gap: 5, marginBottom: 10 }}>
                    <span style={{ background: '#F3F4F6', borderRadius: 5, padding: '2px 8px', fontSize: 11, color: '#374151', fontWeight: 500 }}>{c.type}</span>
                    <span style={c.statusPillStyle}>{c.statusPill}</span>
                  </div>
                  {c.hasLead && (
                    <>
                      <div style={{ background: '#F0FDF4', border: '1px solid #BBF7D0', borderRadius: 7, padding: '6px 10px', marginTop: 'auto', marginBottom: 10, display: 'flex', gap: 6, alignItems: 'center' }}>
                        <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth={2}>
                          <circle cx="12" cy="12" r="10" />
                          <path d="M8 12l3 3 5-6" />
                        </svg>
                        <span style={{ fontSize: 12, fontWeight: 500, color: '#15803D' }}>{c.leadStatus}</span>
                        <span onClick={() => navigate('/realtor/leads')} style={{ fontSize: 11, color: '#15803D', marginLeft: 'auto', cursor: 'pointer' }}>View →</span>
                      </div>
                      <button onClick={() => navigate('/realtor/leads')} style={{ width: '100%', height: 32, background: '#16A34A', border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>View Lead →</button>
                    </>
                  )}
                  {c.noLead && (
                    <div style={{ display: 'flex', gap: 8, marginTop: 'auto' }}>
                      <button onClick={() => navigate('/project/palm-residence')} style={{ flex: 1, height: 32, background: '#16A34A', border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Submit Lead</button>
                      <button onClick={() => navigate('/project/palm-residence')} style={{ flex: 1, height: 32, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: '#374151', fontFamily: 'inherit', cursor: 'pointer' }}>View Project</button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* LIST VIEW */}
        {!isGrid && (
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden' }}>
            {cards.map((c, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 16px', borderBottom: '1px solid #F3F4F6', minHeight: 60 }}>
                <div style={{ width: 52, height: 38, borderRadius: 6, background: '#F3F4F6', backgroundImage: 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 8px)', flexShrink: 0 }} />
                <div style={{ flex: 2 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>{c.name}</div>
                  <div style={{ fontSize: 11, color: '#9CA3AF' }}>{c.location}</div>
                </div>
                <div style={{ flex: 0.8, display: 'flex', gap: 5 }}>
                  <span style={{ background: '#F3F4F6', borderRadius: 5, padding: '2px 6px', fontSize: 10, color: '#374151' }}>{c.type}</span>
                </div>
                <div style={{ flex: 0.5, textAlign: 'center' }}>
                  <span style={{ background: '#F0FDF4', border: '1px solid #BBF7D0', color: '#15803D', borderRadius: 4, padding: '3px 8px', fontSize: 13, fontWeight: 700 }}>{c.commission}</span>
                </div>
                <div style={{ flex: 0.8, fontSize: 12, color: '#9CA3AF' }}>{c.saved}</div>
                <div style={{ flex: 1, fontSize: 11, color: c.leadColor }}>{c.leadLabel}</div>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center', justifyContent: 'flex-end' }}>
                  {c.noLead && <span onClick={() => navigate('/project/palm-residence')} style={{ height: 28, padding: '0 8px', background: '#16A34A', borderRadius: 6, fontSize: 11, fontWeight: 600, color: '#fff', display: 'flex', alignItems: 'center', cursor: 'pointer' }}>Submit Lead</span>}
                  {c.hasLead && <span onClick={() => navigate('/realtor/leads')} style={{ fontSize: 11, color: '#15803D', cursor: 'pointer' }}>View Lead →</span>}
                  <svg width={16} height={16} viewBox="0 0 24 24" fill="#16A34A" stroke="#16A34A" strokeWidth={1.5} style={{ cursor: 'pointer' }}>
                    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
                  </svg>
                </div>
              </div>
            ))}
          </div>
        )}

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 16, paddingTop: 16, borderTop: `1px solid ${colors.border}` }}>
          <span style={{ fontSize: 12, color: '#6B7280' }}>Showing 1–6 of 8 saved projects</span>
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <span style={{ height: 30, minWidth: 30, borderRadius: 6, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', background: '#0A0A0A', color: '#fff' }}>1</span>
            <span style={{ height: 30, minWidth: 30, borderRadius: 6, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', border: `1px solid ${colors.border}`, color: '#374151', background: '#fff' }}>2</span>
            <span style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: '#374151', display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>Next →</span>
          </div>
        </div>
      </div>
    </>
  )
}
