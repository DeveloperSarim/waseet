import React, { useState } from 'react'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const BLUE = '#1B4FD8'

const T = {
  lead: { iconBg: '#EEF3FF', iconColor: '#1B4FD8', icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M9 13h6 M9 17h4', pill: 'Lead update' },
  dealClosed: { iconBg: '#F0FDF4', iconColor: '#16A34A', icon: 'M8 11l3 3 5-6M20 6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2z', pill: 'Commission' },
  coinGreen: { iconBg: '#F0FDF4', iconColor: '#16A34A', icon: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 7v10', pill: 'Commission' },
  coinBlue: { iconBg: '#EEF3FF', iconColor: '#1B4FD8', icon: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 7v10', pill: 'Commission' },
  project: { iconBg: '#FFFBEB', iconColor: '#D97706', icon: 'M3 21h18M5 21V7l8-4v18M19 21V11l-6-4', pill: 'New project' },
  badge: { iconBg: '#F5F3FF', iconColor: '#5B5BD6', icon: 'M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM5 9H3a2 2 0 0 1-2-2V5h4M19 9h2a2 2 0 0 0 2-2V5h-4', pill: 'Achievement' },
  progress: { iconBg: '#F5F3FF', iconColor: '#5B5BD6', icon: 'M3 3v18h18M7 16l4-6 4 3 5-7', pill: 'Achievement' },
  platform: { iconBg: '#F3F4F6', iconColor: '#374151', icon: 'M3 11l18-5v12L3 14v-3zM11.6 16.8a3 3 0 1 1-5.8-1.6', pill: 'Platform' },
  security: { iconBg: '#FFF5F5', iconColor: '#DC2626', icon: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z', pill: 'Account' },
}

const initialList = [
  { id: 1, group: 'Today', type: 'dealClosed', cat: 'Commissions', title: 'Deal closed! 🎉', body: 'Marina Heights · Sara A. deal closed. Commission SAR 22,950 is processing.', time: '2 hours ago', unread: true },
  { id: 2, group: 'Today', type: 'lead', cat: 'Leads', title: 'Lead status updated', body: 'Palm Residence · Khalid M. status changed: Contacted → Site Visit', time: '4 hours ago', unread: true },
  { id: 3, group: 'Today', type: 'project', cat: 'Platform', title: 'New project in Jeddah', body: 'Palm Gardens · Apartments · 3.5% commission. Added this morning.', time: '6 hours ago', unread: true },
  { id: 4, group: 'Yesterday', type: 'progress', cat: 'Platform', title: '2 more deals to Platinum 💎', body: "You're 80% of the way. Close 2 more deals to unlock Platinum benefits.", time: 'Yesterday 3:15 PM', unread: true },
  { id: 5, group: 'Yesterday', type: 'coinBlue', cat: 'Commissions', title: 'Commission processing', body: 'SAR 19,500 for Al Noor Tower is being processed. Expected Jun 30.', time: 'Yesterday 11:22 AM', unread: true },
  { id: 6, group: 'Yesterday', type: 'lead', cat: 'Leads', title: 'Lead status updated', body: 'Al Noor Tower · Omar K. status changed: New → Contacted', time: 'Yesterday 9:45 AM', unread: false },
  { id: 7, group: 'Jun 26', type: 'coinGreen', cat: 'Commissions', title: 'Commission paid ✓', body: 'SAR 20,825 for Marina Heights has been transferred to your Al Rajhi account.', time: 'Jun 26 2:30 PM', unread: false },
  { id: 8, group: 'Jun 26', type: 'platform', cat: 'Platform', title: 'New feature: Project analytics', body: "You can now view performance stats for projects you've submitted leads to.", time: 'Jun 26 10:00 AM', unread: false },
  { id: 9, group: 'Jun 26', type: 'badge', cat: 'Platform', title: "You've reached Gold Realtor! 🥇", body: 'Congratulations! Full analytics and priority listing unlocked.', time: 'Jun 26 9:15 AM', unread: false },
  { id: 10, group: 'Jun 25', type: 'security', cat: 'Platform', title: 'New login detected', body: 'Your account was accessed from a new device in Jeddah.', time: 'Jun 25 7:30 PM', unread: false },
]

const tabDefs = ['All', 'Unread', 'Leads', 'Commissions', 'Platform']
const groupOrder = ['Today', 'Yesterday', 'Jun 26', 'Jun 25']

export default function Notifications() {
  const [tab, setTab] = useState('All')
  const [toast, setToast] = useState(false)
  const [list, setList] = useState(initialList)
  const [hoveredId, setHoveredId] = useState(null)
  const [markHover, setMarkHover] = useState(false)
  const [prefHover, setPrefHover] = useState(false)

  const markRead = (id) => setList((l) => l.map((n) => (n.id === id ? { ...n, unread: false } : n)))
  const markAll = () => {
    setList((l) => l.map((n) => ({ ...n, unread: false })))
    setToast(true)
    setTimeout(() => setToast(false), 2500)
  }

  const unreadCount = list.filter((n) => n.unread).length
  const hasUnread = unreadCount > 0
  const unreadText = unreadCount + ' unread'

  const counts = {
    All: list.length,
    Unread: unreadCount,
    Leads: list.filter((n) => n.cat === 'Leads').length,
    Commissions: list.filter((n) => n.cat === 'Commissions').length,
    Platform: list.filter((n) => n.cat === 'Platform').length,
  }

  let filtered = list
  if (tab === 'Unread') filtered = list.filter((n) => n.unread)
  else if (tab !== 'All') filtered = list.filter((n) => n.cat === tab)

  const groups = groupOrder
    .map((label) => ({ label, items: filtered.filter((n) => n.group === label) }))
    .filter((g) => g.items.length > 0)

  const isEmpty = filtered.length === 0

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>Notifications</span>
            {hasUnread && <span style={{ fontSize: 13, color: colors.textFaint }}>{unreadText}</span>}
          </div>
        }
        right={
          <div style={{ display: 'flex', gap: 8 }}>
            {hasUnread && (
              <button
                onClick={markAll}
                onMouseEnter={() => setMarkHover(true)}
                onMouseLeave={() => setMarkHover(false)}
                style={{ height: 34, padding: '0 14px', background: 'transparent', border: 'none', fontSize: 12, color: markHover ? colors.ink : colors.textSoft, fontFamily: 'inherit', cursor: 'pointer' }}
              >
                Mark all as read
              </button>
            )}
            <button
              onMouseEnter={() => setPrefHover(true)}
              onMouseLeave={() => setPrefHover(false)}
              style={{ height: 34, padding: '0 14px', background: prefHover ? colors.surfaceAlt : '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}
            >
              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textMuted} strokeWidth={1.8}>
                <circle cx="12" cy="12" r="3" />
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
              </svg>
              Preferences →
            </button>
          </div>
        }
      />

      {/* Tabs */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '0 22px', display: 'flex' }}>
        {tabDefs.map((id) => {
          const on = tab === id
          return (
            <div
              key={id}
              onClick={() => setTab(id)}
              style={{ padding: '11px 16px', fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', whiteSpace: 'nowrap', borderBottom: `2px solid ${on ? colors.ink : 'transparent'}`, color: on ? colors.ink : colors.textSoft, fontWeight: on ? 600 : 400 }}
            >
              {id}
              <span style={{ borderRadius: 999, padding: '1px 6px', fontSize: 10, fontWeight: 600, marginLeft: 5, ...(on ? { background: colors.ink, color: '#fff' } : { background: colors.surfaceMuted, color: colors.textSoft }) }}>{counts[id]}</span>
            </div>
          )
        })}
      </div>

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg }}>
        {groups.map((g) => (
          <div key={g.label}>
            <div style={{ fontSize: 11, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.06em', padding: '10px 22px 8px' }}>{g.label}</div>
            {g.items.map((n) => {
              const t = T[n.type]
              const hovered = hoveredId === n.id
              return (
                <div
                  key={n.id}
                  onClick={() => markRead(n.id)}
                  onMouseEnter={() => setHoveredId(n.id)}
                  onMouseLeave={() => setHoveredId(null)}
                  style={{ position: 'relative', background: hovered ? colors.bg : '#fff', borderBottom: `1px solid ${colors.surfaceMuted}`, padding: '14px 22px', cursor: 'pointer', display: 'flex', gap: 14, alignItems: 'flex-start', transition: 'background 150ms' }}
                >
                  {n.unread && <span style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3, background: BLUE }} />}
                  <div style={{ width: 36, height: 36, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, background: t.iconBg }}>
                    <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={t.iconColor} strokeWidth={1.8}>
                      <path d={t.icon} />
                    </svg>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, marginBottom: 2, color: n.unread ? colors.ink : colors.textMuted, fontWeight: n.unread ? 600 : 500 }}>{n.title}</div>
                    <div style={{ fontSize: 12, color: colors.textSoft, lineHeight: 1.5, marginBottom: 6 }}>{n.body}</div>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={{ background: colors.surfaceMuted, borderRadius: 4, padding: '1px 6px', fontSize: 10, fontWeight: 500, color: colors.textSoft }}>{t.pill}</span>
                      <span style={{ color: colors.borderStrong }}>·</span>
                      <span style={{ fontSize: 11, color: colors.textFaint }}>{n.time}</span>
                    </div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8, flexShrink: 0 }}>
                    {n.unread && <span style={{ width: 8, height: 8, borderRadius: '50%', background: BLUE }} />}
                    <span style={{ opacity: hovered ? 1 : 0, transition: 'opacity 150ms', width: 28, height: 28, borderRadius: '50%', border: `1px solid ${colors.border}`, background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={2}>
                        <path d="M5 12h14M13 6l6 6-6 6" />
                      </svg>
                    </span>
                  </div>
                </div>
              )
            })}
          </div>
        ))}

        {isEmpty && (
          <div style={{ textAlign: 'center', padding: '64px 20px' }}>
            <svg width={36} height={36} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.6} style={{ marginBottom: 12 }}>
              <circle cx="12" cy="12" r="10" />
              <path d="M8 12l3 3 5-6" />
            </svg>
            <div style={{ fontSize: 14, fontWeight: 600 }}>All caught up!</div>
            <div style={{ fontSize: 13, color: colors.textSoft, marginTop: 6 }}>No unread notifications.</div>
          </div>
        )}

        <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '14px 22px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: colors.textSoft }}>Showing 1–10 of 18 notifications</span>
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <span style={{ height: 30, minWidth: 30, borderRadius: 6, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', background: colors.ink, color: '#fff' }}>1</span>
            <span style={{ height: 30, minWidth: 30, borderRadius: 6, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', border: `1px solid ${colors.border}`, color: colors.textMuted, background: '#fff' }}>2</span>
            <span style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>Next →</span>
          </div>
        </div>
      </div>

      {toast && (
        <div style={{ position: 'fixed', right: 22, bottom: 22, zIndex: 60, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 10, padding: '12px 14px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', display: 'flex', gap: 10, alignItems: 'center' }}>
          <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2}>
            <circle cx="12" cy="12" r="10" />
            <path d="M8 12l3 3 5-6" />
          </svg>
          <span style={{ fontSize: 13, fontWeight: 500 }}>All notifications marked as read</span>
        </div>
      )}
    </>
  )
}
