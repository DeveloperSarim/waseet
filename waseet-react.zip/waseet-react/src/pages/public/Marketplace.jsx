import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors, radius } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { useHover } from '../../hooks/useHover'
import { ProjectCard } from '../../components/ProjectCard'
import { projects } from '../../data/mock'

function Segmented({ options, value, onChange, height = 36, fontSize = 13 }) {
  return (
    <div style={{ display: 'flex', border: `1px solid ${colors.border}`, borderRadius: 7, overflow: 'hidden', height }}>
      {options.map((o) => {
        const on = o === value
        return (
          <div
            key={o}
            onClick={() => onChange(o)}
            style={{
              display: 'flex',
              alignItems: 'center',
              padding: '0 14px',
              fontSize,
              cursor: 'pointer',
              background: on ? colors.ink : '#fff',
              color: on ? '#fff' : colors.textMuted,
              fontWeight: on ? 600 : 400,
            }}
          >
            {o}
          </div>
        )
      })}
    </div>
  )
}

function DropField({ label, flex = 1, accent, height = 36, fontSize = 13 }) {
  const [h, hp] = useHover()
  return (
    <div
      {...hp}
      style={{
        flex,
        height,
        border: `1px solid ${colors.border}`,
        borderRadius: 7,
        padding: '0 12px',
        fontSize,
        color: accent ? colors.greenDark : colors.textMuted,
        fontWeight: accent ? 500 : 400,
        background: h ? colors.surfaceAlt : '#fff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        cursor: 'pointer',
      }}
    >
      {label}
      <Icon name="chevronDown" size={13} color={colors.textFaint} strokeWidth={2} />
    </div>
  )
}

const searchTabs = ['Properties', 'For developers', 'For realtors']
const cityPills = ['All cities', 'Riyadh', 'Jeddah', 'Dammam', 'Mecca', 'Medina', 'Khobar']
const projCats = ['All projects', 'Apartments', 'Villas', 'Offices', 'Townhouses']

const stats = [
  { icon: (<><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></>), value: '200+', label: 'Verified realtors' },
  { icon: (<><path d="M3 21h18" /><path d="M6 21V7l6-4 6 4v14" /><path d="M9 11h2M13 11h2M9 15h2M13 15h2" /></>), value: '50+', label: 'Developer projects' },
  { icon: (<><circle cx="12" cy="12" r="9" /><path d="M8.5 15.5l7-7" /><circle cx="9" cy="9" r="1.3" /><circle cx="15" cy="15" r="1.3" /></>), value: 'SAR 2M+', label: 'Commission paid' },
  { icon: (<><path d="M12 21s7-6.5 7-12a7 7 0 1 0-14 0c0 5.5 7 12 7 12z" /><circle cx="12" cy="9" r="2.5" /></>), value: '13', label: 'Cities covered', last: true },
]

const browseTypes = [
  { icon: (<><path d="M3 21h18" /><rect x="6" y="3" width="7" height="18" /><path d="M13 9h5v12" /><path d="M9 7v.01M9 11v.01M9 15v.01" /></>), name: 'Apartments', count: '18,420 projects' },
  { icon: (<><path d="M3 11l9-8 9 8" /><path d="M5 10v10h14V10" /><path d="M10 20v-6h4v6" /></>), name: 'Villas', count: '9,210 projects' },
  { icon: (<><path d="M3 21h18" /><path d="M5 21V9l5-4v16" /><path d="M14 21V11l5-3v13" /><path d="M8 11v.01M8 15v.01" /></>), name: 'Townhouses', count: '4,860 projects' },
  { icon: (<><rect x="4" y="3" width="16" height="18" rx="1" /><path d="M8 7h.01M12 7h.01M16 7h.01M8 11h.01M12 11h.01M16 11h.01" /><path d="M10 21v-3h4v3" /></>), name: 'Offices', count: '3,140 projects' },
]

const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 8px)'

const exclusive = [
  { price: 'SAR 1.2M – 3.4M', title: 'Marsa Al Arous Residences', loc: 'Obhur, Jeddah', types: 'Apartments, Penthouses', area: '120 – 410 m²', comm: '3.5%' },
  { price: 'SAR 890K – 5.6M', title: 'Olaya Park Towers', loc: 'Al Olaya, Riyadh', types: 'Apartments, Offices', area: '95 – 520 m²', comm: '3%' },
  { price: 'SAR 3.1M – 8.2M', title: 'Hittin Garden Villas', loc: 'Hittin, Riyadh', types: 'Villas, Townhouses', area: '320 – 720 m²', comm: '4%' },
  { price: 'SAR 1.6M – 4M', title: 'Corniche Bay', loc: 'Al Shati, Jeddah', types: 'Apartments, Duplexes', area: '140 – 360 m²', comm: '2.5%' },
]

const cityCards = [
  { name: 'Jeddah', listings: '2,858 listings', landmark: 'Corniche skyline' },
  { name: 'Riyadh', listings: '1,214 listings', landmark: 'Kingdom Centre' },
  { name: 'Dammam', listings: '940 listings', landmark: 'Corniche towers' },
  { name: 'Mecca', listings: '612 listings', landmark: 'Clock Royal Tower' },
  { name: 'Medina', listings: '410 listings', landmark: 'Quba district' },
  { name: 'Khobar', listings: '388 listings', landmark: 'Corniche district' },
]

const handpicked = [
  { price: 'SAR 1.25M', dev: 'Al Faisal Dev', title: 'Sea-View 3BR, Corniche', specs: '3 bd · 3 ba · 185 m²', loc: 'Al Shati, Jeddah' },
  { price: 'SAR 4.8M', dev: 'Nesma', title: 'Luxury Villa, Private Pool', specs: '5 bd · 6 ba · 520 m²', loc: 'Obhur Al Shamaliyah, Jeddah' },
  { price: 'SAR 38K/yr', dev: 'Retal', title: 'Modern Furnished Studio', specs: 'Studio · 1 ba · 55 m²', loc: 'Al Hamra, Jeddah' },
  { price: 'SAR 720K', dev: 'Dar Al Arkan', title: 'Off-Plan 2BR, Al Rawdah', specs: '2 bd · 2 ba · 110 m²', loc: 'Al Rawdah, Jeddah' },
]

const exploreTools = [
  { title: 'Commission Calculator', sub: 'Estimate your earnings per deal', d: 'M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0-18 0M8.5 15.5l7-7' },
  { title: 'New Projects', sub: 'Latest off-plan launches', d: 'M3 21h18M6 21V8l6-4 6 4v13M9 11h2M13 11h2M9 15h2M13 15h2' },
  { title: 'My Leads', sub: 'Track every lead from submit to close', d: 'M14 9V5a2 2 0 0 0-2-2l-3 7v11h9.3a2 2 0 0 0 2-1.7l1.4-9a2 2 0 0 0-2-2.3zM7 21H4a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1h3' },
  { title: 'Developer Directory', sub: 'Browse all verified developers', d: 'M4 3h16v18H4zM8 7h.01M12 7h.01M16 7h.01M8 11h.01M12 11h.01M16 11h.01M10 21v-3h4v3' },
  { title: 'Payment Plans', sub: 'Compare off-plan payment plans', d: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M9 13h6M9 17h6M9 9h1' },
  { title: 'Area Guides', sub: 'Explore Saudi districts & prices', d: 'M9 18l-6 3V6l6-3 6 3 6-3v15l-6 3-6-3zM9 3v15M15 6v15' },
  { title: 'Price Trends', sub: 'Track real-estate prices over time', d: 'M3 17l6-6 4 4 8-8M17 7h4v4' },
  { title: 'Area Unit Converter', sub: 'm² · ft² · dunum instantly', d: 'M4 4h7v7H4zM13 13h7v7h-7zM7 16v3M5.5 17.5h3M16.5 6h3M18 4.5v3' },
]

const faqs = [
  { q: 'Who can join Waseet?', a: 'Verified property developers and licensed real estate agents across Saudi Arabia can apply. All applicants are reviewed by our admin team within 24 hours.' },
  { q: 'How is commission paid?', a: 'When a deal closes, the developer pays the commission to Waseet. After verification, Waseet disburses your share directly to your registered bank account within 5–7 business days.' },
  { q: 'How long does verification take?', a: 'Applications are reviewed within 24 hours. You will receive an email with your account credentials once approved.' },
  { q: 'Which cities does Waseet cover?', a: 'Waseet operates across Saudi Arabia — including Jeddah, Riyadh, Dammam, Mecca, Medina and Khobar — with new cities added regularly.' },
  { q: 'What is the commission structure?', a: 'Each project lists its commission rate per unit type upfront — typically 2–4%. Waseet charges a platform fee of 10–20% from the commission, and the remainder goes to the realtor.' },
]

function CityPill({ label, active, onClick }) {
  const [h, hp] = useHover()
  return (
    <span
      {...hp}
      onClick={onClick}
      style={{
        padding: '6px 14px',
        borderRadius: 999,
        fontSize: 12,
        cursor: 'pointer',
        border: `1px solid ${active ? colors.ink : colors.border}`,
        background: active ? colors.ink : h ? colors.surfaceAlt : '#fff',
        color: active ? '#fff' : colors.textMuted,
        fontWeight: active ? 600 : 400,
      }}
    >
      {label}
    </span>
  )
}

function CatPill({ label, active, onClick }) {
  const [h, hp] = useHover()
  return (
    <span
      {...hp}
      onClick={onClick}
      style={{
        padding: '6px 12px',
        borderRadius: 7,
        fontSize: 12,
        cursor: 'pointer',
        background: active ? colors.greenTint : h ? colors.surfaceMuted : '#fff',
        border: `1px solid ${active ? colors.greenTintBorder : colors.border}`,
        color: active ? colors.greenDark : colors.textMuted,
        fontWeight: active ? 600 : 400,
      }}
    >
      {label}
    </span>
  )
}

function TypeCard({ c, navigate }) {
  const [h, hp] = useHover()
  return (
    <div
      {...hp}
      onClick={() => navigate('/marketplace')}
      style={{
        background: h ? colors.greenTint : '#fff',
        border: `1px solid ${h ? colors.green : colors.border}`,
        borderRadius: 12,
        padding: 18,
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        cursor: 'pointer',
        transition: 'all 150ms ease',
        transform: h ? 'translateY(-2px)' : 'none',
      }}
    >
      <div style={{ width: 38, height: 38, borderRadius: 10, background: colors.greenTint, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <svg width={19} height={19} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">{c.icon}</svg>
      </div>
      <div>
        <div style={{ fontSize: 14, fontWeight: 600 }}>{c.name}</div>
        <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 2 }}>{c.count}</div>
      </div>
    </div>
  )
}

export default function Marketplace() {
  const navigate = useNavigate()
  const [tab, setTab] = useState('Properties')
  const [deal, setDeal] = useState('Buy')
  const [status, setStatus] = useState('All')
  const [city, setCity] = useState('All cities')
  const [cat, setCat] = useState('All projects')
  const [faqOpen, setFaqOpen] = useState(0)

  const filtered = projects.filter((p) => city === 'All cities' || p.city === city)

  return (
    <div>
      {/* HERO */}
      <div style={{ background: '#fff', padding: '48px 24px 40px', textAlign: 'center' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: colors.surfaceAlt, border: `1px solid ${colors.border}`, borderRadius: 999, padding: '4px 11px', marginBottom: 20 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: colors.green, animation: 'ps-pulse 1.8s ease-in-out infinite' }} />
          <span style={{ fontSize: 12, color: colors.textSoft }}>Live · <span style={{ fontWeight: 700, color: colors.ink }}>47,293</span> active listings</span>
        </div>
        <h1 className="wa-h1" style={{ fontSize: 36, fontWeight: 700, letterSpacing: '-0.03em', lineHeight: 1.1, maxWidth: 600, margin: '0 auto 12px' }}>
          Saudi Arabia's Premier<br />B2B Real Estate <span style={{ color: colors.green }}>Network.</span>
        </h1>
        <p style={{ fontSize: 14, color: colors.textSoft, lineHeight: 1.5, maxWidth: 460, margin: '0 auto 8px' }}>Connecting verified developers with licensed realtors.</p>
        <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 28 }}>Jeddah · Riyadh · Dammam · Mecca · Medina · Khobar</div>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
          {['Verified developers', 'Licensed realtors', 'Commission protected'].map((t) => (
            <span key={t} style={{ display: 'flex', gap: 6, alignItems: 'center', fontSize: 13, color: colors.textSoft }}>
              <Icon name="checkCircle" size={15} color={colors.green} strokeWidth={2} />
              {t}
            </span>
          ))}
        </div>
      </div>

      {/* SEARCH CARD */}
      <div style={{ background: '#fff', padding: '8px 24px 28px' }}>
        <div style={{ maxWidth: 860, margin: '0 auto' }}>
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.03)', overflow: 'hidden' }}>
            <div style={{ borderBottom: `1px solid ${colors.surfaceMuted}`, padding: '0 16px', display: 'flex' }}>
              {searchTabs.map((t) => {
                const on = t === tab
                return (
                  <div key={t} onClick={() => setTab(t)} style={{ padding: '13px 14px', fontSize: 13, fontWeight: on ? 600 : 500, color: on ? colors.ink : colors.textSoft, borderBottom: `2px solid ${on ? colors.green : 'transparent'}`, cursor: 'pointer', marginBottom: -1 }}>
                    {t}
                  </div>
                )
              })}
            </div>

            {tab === 'Properties' && (
              <div>
                <div style={{ padding: '12px 14px', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                  <Segmented options={['Buy', 'Rent']} value={deal} onChange={setDeal} />
                  <DropField label="Jeddah" flex={1} />
                  <DropField label="All areas" flex={1.5} />
                  <button
                    onClick={() => {}}
                    style={{ height: 36, padding: '0 18px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 13, fontWeight: 500, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap' }}
                  >
                    <Icon name="search" size={14} color="#fff" strokeWidth={2} />
                    Search
                  </button>
                </div>
                <div style={{ padding: '0 14px 12px', display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  <Segmented options={['All', 'Ready', 'Off-plan']} value={status} onChange={setStatus} height={34} fontSize={12} />
                  <DropField label="Property type" height={34} fontSize={12} />
                  <DropField label="Commission %" accent height={34} fontSize={12} />
                  <DropField label="Price range" height={34} fontSize={12} />
                </div>
                <div style={{ margin: '0 14px 12px', background: colors.greenTint, border: `1px solid ${colors.greenSoft}`, borderRadius: 8, padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                  <Icon name="layers" size={16} color={colors.green} strokeWidth={1.9} />
                  <span style={{ fontSize: 13 }}>
                    <span style={{ fontWeight: 600, color: colors.greenDark }}>View projects on map</span>
                    <span style={{ color: colors.textMuted }}> — Find projects near your preferred area</span>
                  </span>
                  <Icon name="arrowRight" size={14} color={colors.green} strokeWidth={2} style={{ marginLeft: 'auto' }} />
                </div>
              </div>
            )}

            {tab !== 'Properties' && (
              <div style={{ padding: '18px 16px', display: 'flex', alignItems: 'center', gap: 14 }}>
                <div style={{ width: 40, height: 40, minWidth: 40, borderRadius: 10, background: colors.greenTint, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name={tab === 'For developers' ? 'building' : 'users'} size={20} color={colors.green} strokeWidth={1.8} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 2 }}>
                    {tab === 'For developers' ? 'List your off-plan & ready projects' : 'Browse exclusive developer projects'}
                  </div>
                  <div style={{ fontSize: 12, color: colors.textSoft }}>
                    {tab === 'For developers'
                      ? 'Reach 200+ verified realtors and show commission rates upfront on every unit.'
                      : 'Submit client leads with commission shown upfront, and get paid on every closed deal.'}
                  </div>
                </div>
                <button
                  onClick={() => navigate(tab === 'For developers' ? '/register/developer' : '/register/realtor')}
                  style={{ height: 40, padding: '0 20px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', whiteSpace: 'nowrap' }}
                >
                  {tab === 'For developers' ? 'List your project' : 'Join as realtor'}
                </button>
              </div>
            )}
          </div>

          <div style={{ marginTop: 12, display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center' }}>
            {cityPills.map((c) => (
              <CityPill key={c} label={c} active={city === c} onClick={() => setCity(c)} />
            ))}
          </div>
        </div>
      </div>

      {/* STATS STRIP */}
      <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, borderBottom: `1px solid ${colors.border}`, display: 'flex', flexWrap: 'wrap' }}>
        {stats.map((s, i) => (
          <div key={i} style={{ flex: '1 1 180px', padding: '22px 0', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, borderRight: s.last ? 'none' : `1px solid ${colors.border}` }}>
            <div style={{ width: 38, height: 38, borderRadius: 10, background: colors.greenTint, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width={19} height={19} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">{s.icon}</svg>
            </div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1 }}>{s.value}</div>
              <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 3 }}>{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* FEATURED PROJECTS */}
      <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '40px 24px' }}>
        <div style={{ maxWidth: 1120, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
            <h2 style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em', margin: 0 }}>Featured projects</h2>
            <span style={{ fontSize: 13, color: colors.greenDark, fontWeight: 500, cursor: 'pointer' }}>View all →</span>
          </div>
          <div style={{ display: 'flex', gap: 6, marginBottom: 16, flexWrap: 'wrap' }}>
            {projCats.map((c) => (
              <CatPill key={c} label={c} active={cat === c} onClick={() => setCat(c)} />
            ))}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 16 }}>
            {filtered.map((p) => (
              <ProjectCard key={p.id} project={p} />
            ))}
          </div>
        </div>
      </div>

      {/* BROWSE BY TYPE */}
      <div style={{ background: '#fff', padding: '40px 24px' }}>
        <div style={{ maxWidth: 1120, margin: '0 auto' }}>
          <h2 style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em', margin: '0 0 18px' }}>Browse by type</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12 }}>
            {browseTypes.map((c, i) => (
              <TypeCard key={i} c={c} navigate={navigate} />
            ))}
          </div>
        </div>
      </div>

      {/* DARK BAND */}
      <div style={{ background: colors.ink, padding: '48px 24px', position: 'relative', overflow: 'hidden', backgroundImage: 'radial-gradient(ellipse at 70% 50%, rgba(22,163,74,0.12) 0%, transparent 60%), repeating-linear-gradient(45deg, rgba(255,255,255,0.018) 0, rgba(255,255,255,0.018) 1px, transparent 1px, transparent 11px)' }}>
        <div style={{ maxWidth: 1120, margin: '0 auto', position: 'relative', minHeight: 280 }}>
          <div style={{ maxWidth: 540 }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: 999, padding: '5px 12px', marginBottom: 18 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: colors.green, animation: 'ps-pulse 1.8s ease-in-out infinite' }} />
              <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>New developments live now</span>
            </div>
            <h2 style={{ fontSize: 32, fontWeight: 700, color: '#fff', letterSpacing: '-0.03em', lineHeight: 1.15, margin: '0 0 14px' }}>Exclusive access to Saudi Arabia's finest off-plan projects.</h2>
            <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.55)', lineHeight: 1.6, maxWidth: 460, margin: '0 0 24px' }}>Every verified project shows commission rates upfront — no chasing developers, no surprises.</p>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => navigate('/marketplace')} style={{ height: 40, padding: '0 20px', background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Explore projects</button>
              <button style={{ height: 40, padding: '0 20px', background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.2)', borderRadius: 8, fontSize: 13, fontWeight: 500, color: 'rgba(255,255,255,0.85)', fontFamily: 'inherit', cursor: 'pointer' }}>View on map</button>
            </div>
          </div>

          {/* fanned floating mock cards — rotate on wrapper, float on inner so both compose */}
          <div className="wa-deco" style={{ position: 'absolute', right: 0, top: '50%', transform: 'translateY(-50%)', width: 430, height: 260 }}>
            <div style={{ position: 'absolute', right: 215, top: 36, transform: 'rotate(-7deg)' }}>
              <div style={{ width: 210, background: 'rgba(22,22,22,0.85)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 12, overflow: 'hidden', boxShadow: '0 18px 40px rgba(0,0,0,0.5)', animation: 'wfloat 4.5s ease-in-out infinite', animationDelay: '1.2s' }}>
                <div style={{ height: 96, background: '#161616', backgroundImage: 'repeating-linear-gradient(45deg,#222 0,#222 1px,transparent 1px,transparent 10px)', position: 'relative' }}>
                  <span style={{ position: 'absolute', top: 9, left: 9, background: '#FEF9EC', border: '1px solid #F3E2B8', borderRadius: 999, padding: '2px 8px', fontSize: 9, fontWeight: 600, color: '#92763A' }}>NEW</span>
                  <span style={{ position: 'absolute', bottom: 9, right: 9, background: colors.green, borderRadius: 5, padding: '2px 8px', fontSize: 10, fontWeight: 700, color: '#fff' }}>4% Commission</span>
                </div>
                <div style={{ padding: '10px 12px' }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#fff', marginBottom: 3 }}>Olaya Park Towers</div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)', marginBottom: 6 }}>Al Olaya, Riyadh</div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#fff' }}>SAR 890K – 5.6M</div>
                </div>
              </div>
            </div>
            <div style={{ position: 'absolute', right: 4, top: 8, transform: 'rotate(3deg)' }}>
              <div style={{ width: 232, background: 'rgba(24,24,24,0.95)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 12, overflow: 'hidden', boxShadow: '0 26px 60px rgba(0,0,0,0.6)', animation: 'wfloat 4.5s ease-in-out infinite' }}>
                <div style={{ height: 120, background: '#1A1A1A', backgroundImage: 'repeating-linear-gradient(45deg,#242424 0,#242424 1px,transparent 1px,transparent 10px)', position: 'relative' }}>
                  <span style={{ position: 'absolute', top: 10, left: 10, background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 999, padding: '3px 9px', fontSize: 10, fontWeight: 600, color: colors.greenDark, letterSpacing: '0.03em' }}>FEATURED</span>
                  <span style={{ position: 'absolute', bottom: 10, right: 10, background: colors.green, borderRadius: 6, padding: '4px 10px', fontSize: 11, fontWeight: 700, color: '#fff' }}>3% Commission</span>
                  <span style={{ position: 'absolute', top: 10, right: 12, fontFamily: 'monospace', fontSize: 9, color: 'rgba(255,255,255,0.4)' }}>project render</span>
                </div>
                <div style={{ padding: '12px 14px' }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: '#fff', marginBottom: 4 }}>Marsa Heights</div>
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.45)', marginBottom: 8 }}>Al Shati, Jeddah</div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#fff' }}>SAR 980,000 – 1.6M</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* WASEET EXCLUSIVE */}
      <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '40px 24px' }}>
        <div style={{ maxWidth: 1120, margin: '0 auto' }}>
          <div style={{ background: colors.greenTint, border: `1px solid ${colors.greenSoft}`, borderRadius: 16, padding: '22px 22px 24px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <h2 style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em', margin: 0 }}>Waseet Exclusive</h2>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: colors.green, color: '#fff', borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 600 }}>
                  <Icon name="check" size={12} color="#fff" strokeWidth={2.2} />Listed by us
                </span>
              </div>
              <span style={{ fontSize: 13, color: colors.greenDark, fontWeight: 500, cursor: 'pointer' }}>View all →</span>
            </div>
            <div className="pd-tabs" style={{ display: 'flex', gap: 14, overflowX: 'auto', paddingBottom: 6 }}>
              {exclusive.map((e) => (
                <div key={e.title} style={{ flex: 'none', width: 270, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', cursor: 'pointer' }}>
                  <div style={{ height: 150, background: '#1A1A1A', backgroundImage: 'repeating-linear-gradient(45deg,#262626 0,#262626 1px,transparent 1px,transparent 10px)', position: 'relative' }}>
                    <span style={{ position: 'absolute', top: 10, left: 10, background: colors.ink, color: '#fff', borderRadius: 5, padding: '3px 9px', fontSize: 10, fontWeight: 700, letterSpacing: '0.04em' }}>EXCLUSIVE</span>
                    <span style={{ position: 'absolute', bottom: 10, right: 10, background: colors.green, borderRadius: 6, padding: '4px 10px', fontSize: 11, fontWeight: 700, color: '#fff' }}>{e.comm} Commission</span>
                    <span style={{ position: 'absolute', bottom: 10, left: 11, fontFamily: 'monospace', fontSize: 9, color: 'rgba(255,255,255,0.45)' }}>project render</span>
                  </div>
                  <div style={{ padding: '13px 14px' }}>
                    <div style={{ fontSize: 15, fontWeight: 700, letterSpacing: '-0.01em', marginBottom: 3 }}>{e.price}</div>
                    <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 3 }}>{e.title}</div>
                    <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 10 }}>{e.loc}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: colors.textSoft, marginBottom: 5 }}>
                      <Icon name="building" size={13} color={colors.textFaint} strokeWidth={1.8} />{e.types}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: colors.textSoft }}>
                      <Icon name="grid" size={13} color={colors.textFaint} strokeWidth={1.8} />{e.area}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* BROWSE BY CITY */}
      <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, padding: '40px 24px' }}>
        <div style={{ maxWidth: 1120, margin: '0 auto' }}>
          <h2 style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em', margin: '0 0 18px' }}>Browse by city</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 12 }}>
            {cityCards.map((c) => (
              <div key={c.name} onClick={() => setCity(c.name)} style={{ borderRadius: 12, overflow: 'hidden', cursor: 'pointer', position: 'relative', height: 130, background: '#1A1A1A', backgroundImage: 'repeating-linear-gradient(45deg,#262626 0,#262626 1px,transparent 1px,transparent 10px)' }}>
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.05) 35%, rgba(0,0,0,0.78) 100%)' }} />
                <span style={{ position: 'absolute', top: 9, right: 10, fontFamily: 'monospace', fontSize: 9, color: 'rgba(255,255,255,0.4)' }}>{c.landmark}</span>
                <div style={{ position: 'absolute', bottom: 11, left: 12 }}>
                  <div style={{ fontSize: 16, fontWeight: 700, color: '#fff', letterSpacing: '-0.01em' }}>{c.name}</div>
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.6)', marginTop: 1 }}>{c.listings}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* HANDPICKED IN JEDDAH */}
      <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '40px 24px' }}>
        <div style={{ maxWidth: 1120, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 18 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 600, color: colors.textFaint, letterSpacing: '0.08em', marginBottom: 4 }}>FEATURED</div>
              <h2 style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em', margin: 0 }}>Handpicked in Jeddah</h2>
            </div>
            <span style={{ fontSize: 13, color: colors.greenDark, fontWeight: 500, cursor: 'pointer' }}>View all →</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 14 }}>
            {handpicked.map((h) => (
              <div key={h.title} onClick={() => navigate('/project/palm-residence')} style={{ border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', cursor: 'pointer', background: '#fff' }}>
                <div style={{ height: 150, background: colors.surfaceMuted, backgroundImage: hatch, position: 'relative' }}>
                  <span style={{ position: 'absolute', top: 9, left: 9, display: 'inline-flex', alignItems: 'center', gap: 4, background: 'rgba(255,255,255,0.95)', border: `1px solid ${colors.border}`, borderRadius: 999, padding: '3px 9px', fontSize: 11, fontWeight: 600, color: colors.greenDark }}>
                    <Icon name="check" size={12} color={colors.green} strokeWidth={2.2} />Verified
                  </span>
                  <div style={{ position: 'absolute', top: 9, right: 9, width: 28, height: 28, borderRadius: 7, background: 'rgba(255,255,255,0.92)', border: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name="bookmark" size={14} color={colors.textSoft} strokeWidth={1.8} />
                  </div>
                </div>
                <div style={{ padding: '12px 13px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
                    <span style={{ fontSize: 15, fontWeight: 700, letterSpacing: '-0.01em' }}>{h.price}</span>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>{h.dev}</span>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: colors.greenDark, marginBottom: 6, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{h.title}</div>
                  <div style={{ fontSize: 12, color: colors.textSoft, marginBottom: 4 }}>{h.specs}</div>
                  <div style={{ fontSize: 12, color: colors.textFaint }}>{h.loc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* EXPLORE MORE */}
      <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, padding: '48px 24px' }}>
        <div style={{ maxWidth: 1120, margin: '0 auto' }}>
          <h2 style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em', margin: '0 0 28px' }}>Explore more on Waseet</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))', gap: '14px 28px' }}>
            {exploreTools.map((t) => (
              <div key={t.title} style={{ display: 'flex', gap: 14, alignItems: 'flex-start', cursor: 'pointer' }}>
                <div style={{ width: 44, height: 44, minWidth: 44, borderRadius: 11, background: colors.greenTint, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d={t.d} /></svg>
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, lineHeight: 1.3 }}>{t.title}</div>
                  <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 4, lineHeight: 1.45 }}>{t.sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* APP DOWNLOAD */}
      <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '40px 24px' }}>
        <div style={{ maxWidth: 1120, margin: '0 auto' }}>
          <div style={{ background: colors.greenTint, border: `1px solid ${colors.greenSoft}`, borderRadius: 16, padding: 32, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 32, flexWrap: 'wrap' }}>
            <div style={{ flex: 1, minWidth: 280 }}>
              <h2 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', margin: '0 0 8px', color: colors.ink }}>Take Waseet anywhere</h2>
              <p style={{ fontSize: 14, color: colors.greenDark, lineHeight: 1.55, margin: '0 0 20px', maxWidth: 440 }}>Submit leads, track your commissions, and get notified the moment a new verified project goes live — right from your phone.</p>
              <div style={{ display: 'flex', gap: 10 }}>
                {[['Download on the', 'App Store'], ['Get it on', 'Google Play']].map(([top, bot]) => (
                  <div key={bot} style={{ display: 'flex', alignItems: 'center', gap: 9, background: colors.ink, borderRadius: 9, padding: '8px 16px', cursor: 'pointer' }}>
                    <svg width={18} height={18} viewBox="0 0 24 24" fill="#fff">{bot === 'App Store' ? <path d="M17.6 12.7c0-2.1 1.7-3.1 1.8-3.2-1-1.4-2.5-1.6-3-1.7-1.3-.1-2.5.8-3.1.8-.7 0-1.6-.7-2.7-.7-1.4 0-2.6.8-3.3 2-1.4 2.5-.4 6.1 1 8.1.7 1 1.4 2.1 2.5 2.1 1 0 1.4-.7 2.6-.7s1.6.7 2.7.6c1.1 0 1.8-1 2.5-2 .8-1.2 1.1-2.3 1.1-2.4-.1 0-2.1-.8-2.1-3.2zM15.5 6.3c.6-.7 1-1.7.9-2.7-.9 0-1.9.6-2.5 1.3-.5.6-1 1.6-.9 2.6 1 .1 1.9-.5 2.5-1.2z" /> : <path d="M3.6 2.4c-.3.3-.5.7-.5 1.3v16.6c0 .6.2 1 .5 1.3l9-9.3-9-9.9zM16.5 8.9 5.9 2.7l8.2 8.5 2.4-2.3zm-2.4 3.9-8.2 8.5 10.6-6.2-2.4-2.3zm5.5-2.3L16.5 8.9l-2.4 2.3 2.4 2.3 3.1-1.6c.9-.5.9-1.9 0-2.4z" />}</svg>
                    <div style={{ lineHeight: 1.15 }}>
                      <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.7)' }}>{top}</div>
                      <div style={{ fontSize: 15, fontWeight: 600, color: '#fff' }}>{bot}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ width: 120, height: 120, borderRadius: 14, background: '#fff', border: `1px solid ${colors.greenTintBorder}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ position: 'relative', width: 96, height: 96, background: '#fff', borderRadius: 6 }}>
                <div style={{ position: 'absolute', inset: 10, background: 'repeating-conic-gradient(#0A0A0A 0% 25%, #fff 0% 50%) 0 0 / 8px 8px', borderRadius: 2 }} />
                {[{ top: 8, left: 8 }, { top: 8, right: 8 }, { bottom: 8, left: 8 }].map((pos, i) => (
                  <div key={i} style={{ position: 'absolute', ...pos, width: 24, height: 24, background: '#fff', border: '5px solid #0A0A0A', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <div style={{ width: 7, height: 7, background: '#0A0A0A', borderRadius: 2 }} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* FAQ */}
      <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, padding: '48px 24px' }}>
        <div style={{ maxWidth: 760, margin: '0 auto' }}>
          <h2 style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em', textAlign: 'center', margin: '0 0 28px' }}>Frequently asked questions</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {faqs.map((f, i) => {
              const open = faqOpen === i
              return (
                <div key={i} style={{ background: '#fff', border: `1px solid ${open ? colors.borderStrong : colors.border}`, borderRadius: 10, overflow: 'hidden' }}>
                  <div onClick={() => setFaqOpen(open ? -1 : i)} style={{ padding: '16px 18px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }}>
                    <span style={{ fontSize: 14, fontWeight: 500, color: colors.ink }}>{f.q}</span>
                    <span style={{ transform: open ? 'rotate(45deg)' : 'none', transition: 'transform 200ms ease', display: 'flex' }}>
                      <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={2} strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
                    </span>
                  </div>
                  {open && <div style={{ padding: '0 18px 16px', fontSize: 13, color: colors.textSoft, lineHeight: 1.6 }}>{f.a}</div>}
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
