import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { useHover } from '../../hooks/useHover'

const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 8px)'
const cities = ['All cities', 'Jeddah', 'Riyadh', 'Dubai', 'Abu Dhabi', 'Karachi', 'Lahore']
const cats = ['All projects', 'Apartments', 'Villas', 'Offices', 'Townhouses', 'Land']
const sortOpts = ['Newest first', 'Commission: High to Low', 'Price: Low to High', 'Price: High to Low', 'Featured first']
const filters = [{ label: 'All cities' }, { label: 'Property type' }, { label: 'Commission %', accent: true }, { label: 'Price range' }, { label: 'Status' }]

const statusTone = {
  off: { bg: '#FEF9EC', color: '#92763A' },
  ready: { bg: colors.greenTint, color: colors.greenDark },
  uc: { bg: colors.surfaceMuted, color: colors.textMuted },
}

const allCards = [
  { id: 1, name: 'Palm Residence', loc: 'Al Rawdhah, Jeddah', city: 'Jeddah', cat: 'Apartments', dev: 'Al Faisal Development', devInit: 'AF', price: 'SAR 650,000 – 1,200,000', type: 'Apartments', status: 'Off-plan', sk: 'off', comm: '3%', featured: true, isNew: false },
  { id: 2, name: 'Marina Heights', loc: 'Dubai Marina, UAE', city: 'Dubai', cat: 'Offices', dev: 'Marina Corp', devInit: 'MC', price: 'AED 800,000 – 2,000,000', type: 'Offices', status: 'Ready', sk: 'ready', comm: '2.5%', featured: false, isNew: true },
  { id: 3, name: 'Al Noor Tower', loc: 'Al Hamra, Riyadh', city: 'Riyadh', cat: 'Villas', dev: 'Noor Group', devInit: 'NG', price: 'SAR 1,100,000 – 3,000,000', type: 'Villas', status: 'Off-plan', sk: 'off', comm: '4%', featured: true, isNew: true },
  { id: 4, name: 'Green Valley', loc: 'Islamabad, Pakistan', city: 'Lahore', cat: 'Townhouses', dev: 'Emerald Builders', devInit: 'EB', price: 'PKR 45M – 80M', type: 'Townhouses', status: 'Under Const.', sk: 'uc', comm: '3.5%', featured: false, isNew: false },
  { id: 5, name: 'Corniche Suites', loc: 'Al Corniche, Jeddah', city: 'Jeddah', cat: 'Apartments', dev: 'Coast Dev', devInit: 'CD', price: 'SAR 900,000 – 1,800,000', type: 'Apartments', status: 'Ready', sk: 'ready', comm: '3%', featured: false, isNew: false },
  { id: 6, name: 'Business Bay Tower', loc: 'Business Bay, Dubai', city: 'Dubai', cat: 'Offices', dev: 'Bay Developers', devInit: 'BD', price: 'AED 1,200,000 – 3,500,000', type: 'Offices', status: 'Off-plan', sk: 'off', comm: '2%', featured: false, isNew: false },
]

function TopNavLink({ label, active, onClick }) {
  const [h, hp] = useHover()
  return (
    <span {...hp} onClick={onClick} style={{ fontSize: 13, fontWeight: active ? 600 : 400, color: active || h ? colors.ink : colors.textSoft, cursor: 'pointer', position: 'relative' }}>
      {label}
      {active && <span style={{ position: 'absolute', bottom: -19, left: '50%', transform: 'translateX(-50%)', width: 4, height: 4, borderRadius: '50%', background: colors.green }} />}
    </span>
  )
}

function FilterButton({ label, accent }) {
  const [h, hp] = useHover()
  return (
    <div {...hp} style={{ height: 34, border: `1px solid ${accent ? colors.green : colors.border}`, borderRadius: 7, padding: '0 12px', fontSize: 12, color: accent ? colors.greenDark : colors.textMuted, fontWeight: accent ? 600 : 400, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: h && !accent ? colors.surfaceAlt : '#fff' }}>
      {label}
      <Icon name="chevronDown" size={11} color={accent ? colors.green : colors.textFaint} strokeWidth={2} />
    </div>
  )
}

function Tab({ label, active, onClick }) {
  const [h, hp] = useHover()
  return (
    <div {...hp} onClick={onClick} style={{ padding: '10px 16px 12px', fontSize: 12, whiteSpace: 'nowrap', cursor: 'pointer', color: active ? colors.ink : h ? colors.textMuted : colors.textSoft, fontWeight: active ? 600 : 400, borderBottom: `2px solid ${active ? colors.ink : 'transparent'}`, marginBottom: -1 }}>
      {label}
    </div>
  )
}

function ListingCard({ p, navigate }) {
  const [hovered, hoverProps] = useHover()
  const st = statusTone[p.sk]
  return (
    <div
      {...hoverProps}
      onClick={() => navigate('/project/' + (p.id === 1 ? 'palm-residence' : p.id))}
      style={{ background: '#fff', border: `1px solid ${hovered ? colors.borderStrong : colors.border}`, borderRadius: 12, overflow: 'hidden', cursor: 'pointer', boxShadow: hovered ? '0 4px 16px rgba(0,0,0,0.06)' : 'none', transform: hovered ? 'translateY(-2px)' : 'none', transition: 'all 200ms ease' }}
    >
      <div style={{ height: 180, background: colors.surfaceMuted, backgroundImage: hatch, position: 'relative' }}>
        <div style={{ position: 'absolute', top: 10, left: 10, display: 'flex', gap: 5 }}>
          {p.featured && <span style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, color: colors.greenDark, borderRadius: 999, padding: '3px 8px', fontSize: 10, fontWeight: 600 }}>FEATURED</span>}
          {p.isNew && <span style={{ background: '#FEF9EC', border: '1px solid #F3E2B8', color: '#92763A', borderRadius: 999, padding: '3px 8px', fontSize: 10, fontWeight: 600 }}>NEW</span>}
        </div>
        <div style={{ position: 'absolute', top: 10, right: 10, width: 30, height: 30, background: 'rgba(255,255,255,0.92)', border: `1px solid ${colors.border}`, borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: hovered ? 1 : 0, transition: 'opacity 150ms' }}>
          <Icon name="bookmark" size={15} color={colors.textSoft} strokeWidth={1.8} />
        </div>
        <span style={{ position: 'absolute', bottom: 10, right: 10, background: colors.ink, borderRadius: 6, padding: '4px 10px', fontSize: 11, fontWeight: 700, color: '#fff' }}>{p.comm} Commission</span>
      </div>
      <div style={{ padding: '12px 14px' }}>
        <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: '-0.01em', marginBottom: 4 }}>{p.name}</div>
        <div style={{ display: 'flex', gap: 4, alignItems: 'center', marginBottom: 4 }}>
          <Icon name="mapPin" size={12} color={colors.textFaint} strokeWidth={2} />
          <span style={{ fontSize: 12, color: colors.textFaint }}>{p.loc}</span>
        </div>
        <div style={{ display: 'flex', gap: 5, alignItems: 'center', marginBottom: 8 }}>
          <span style={{ width: 18, height: 18, borderRadius: '50%', background: colors.surfaceMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 8, fontWeight: 700, color: colors.textSoft }}>{p.devInit}</span>
          <span style={{ fontSize: 11, color: colors.textSoft }}>{p.dev}</span>
          <Icon name="checkCircle" size={12} color={colors.green} strokeWidth={2} />
        </div>
        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>{p.price}</div>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <span style={{ background: colors.surfaceMuted, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 500, color: colors.textMuted }}>{p.type}</span>
          <span style={{ background: st.bg, color: st.color, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 500 }}>{p.status}</span>
        </div>
        <div style={{ maxHeight: hovered ? 48 : 0, opacity: hovered ? 1 : 0, overflow: 'hidden', transition: 'all 200ms ease' }}>
          <div style={{ marginTop: 10, width: '100%', height: 32, background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 500, color: colors.greenDark }}>View project →</div>
        </div>
      </div>
    </div>
  )
}

export default function MarketplaceListing() {
  const navigate = useNavigate()
  const [search, setSearch] = useState('')
  const [city, setCity] = useState('All cities')
  const [cat, setCat] = useState('All projects')
  const [sort, setSort] = useState('Newest first')
  const [sortOpen, setSortOpen] = useState(false)
  const [view, setView] = useState('grid')
  const [menuOpen, setMenuOpen] = useState(false)

  const filtered = allCards.filter(
    (p) => (city === 'All cities' || p.city === city) && (cat === 'All projects' || p.cat === cat) && (!search || p.name.toLowerCase().includes(search.toLowerCase()) || p.dev.toLowerCase().includes(search.toLowerCase())),
  )

  const gridBtn = (active) => ({ width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: active ? '#fff' : colors.textFaint, background: active ? colors.ink : '#fff' })

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', color: colors.ink, background: colors.bg, minHeight: '100vh' }}>
      {/* Navbar */}
      <div style={{ height: 56, minHeight: 56, borderBottom: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px', background: '#fff', position: 'sticky', top: 0, zIndex: 40 }}>
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.ink} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11z" /><circle cx="12" cy="11" r="2.4" /></svg>
          <span style={{ fontSize: 15, fontWeight: 700, letterSpacing: '-0.02em' }}>waseet</span>
          <span style={{ fontSize: 11, color: colors.textFaint, marginLeft: 2 }}>وسيط</span>
        </Link>
        <div style={{ display: 'flex', alignItems: 'center', gap: 24 }} className="wa-hide-sm">
          <TopNavLink label="Marketplace" active />
          <TopNavLink label="My Leads" onClick={() => navigate('/realtor/leads')} />
          <TopNavLink label="Commissions" onClick={() => navigate('/realtor/commissions')} />
          <TopNavLink label="Saved" onClick={() => navigate('/realtor/saved')} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ position: 'relative', cursor: 'pointer' }}>
            <Icon name="bell" size={20} color={colors.textSoft} strokeWidth={1.7} />
            <span style={{ position: 'absolute', top: -4, right: -5, background: colors.red, color: '#fff', fontSize: 9, fontWeight: 700, borderRadius: 999, minWidth: 16, height: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 3px' }}>3</span>
          </div>
          <div style={{ position: 'relative' }}>
            <div onClick={() => setMenuOpen(!menuOpen)} style={{ width: 32, height: 32, borderRadius: '50%', background: colors.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: '#fff', cursor: 'pointer' }}>AR</div>
            {menuOpen && (
              <div style={{ position: 'absolute', top: 40, right: 0, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 10, boxShadow: '0 8px 24px rgba(0,0,0,0.12)', minWidth: 200, zIndex: 50, overflow: 'hidden' }}>
                <div style={{ padding: '12px 14px', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>Ahmed Al-Rashid</div>
                  <div style={{ fontSize: 11, color: colors.textFaint }}>ahmed@gmail.com</div>
                  <div style={{ fontSize: 11, color: colors.greenDark, marginTop: 3 }}>🥇 Gold Realtor</div>
                </div>
                <div style={{ padding: 4 }}>
                  {[['My Profile', '/realtor/profile'], ['Notifications', '/realtor/notifications'], ['Settings', '/realtor/settings']].map(([l, to]) => (
                    <div key={l} onClick={() => navigate(to)} style={{ height: 34, display: 'flex', alignItems: 'center', padding: '0 10px', borderRadius: 6, cursor: 'pointer', fontSize: 13, color: colors.textMuted }}>{l}</div>
                  ))}
                </div>
                <div style={{ borderTop: `1px solid ${colors.surfaceMuted}`, padding: 4 }}>
                  <div onClick={() => navigate('/login')} style={{ height: 34, display: 'flex', alignItems: 'center', padding: '0 10px', borderRadius: 6, cursor: 'pointer', fontSize: 13, color: colors.red }}>Sign Out</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Filter bar */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '10px 24px', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, maxWidth: 300, minWidth: 180 }}>
          <Icon name="search" size={14} color={colors.textFaint} strokeWidth={2} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search projects, developers..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 12, fontFamily: 'inherit', color: colors.ink }} />
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {filters.map((f) => <FilterButton key={f.label} label={f.label} accent={f.accent} />)}
        </div>
        <div style={{ width: 1, height: 20, background: colors.border, margin: '0 2px' }} />
        <div style={{ position: 'relative' }}>
          <div onClick={() => setSortOpen(!sortOpen)} style={{ height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 12px', fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
            {sort}<Icon name="chevronDown" size={11} color={colors.textFaint} strokeWidth={2} />
          </div>
          {sortOpen && (
            <div style={{ position: 'absolute', top: 38, right: 0, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, boxShadow: '0 8px 24px rgba(0,0,0,0.1)', width: 210, zIndex: 30, padding: 4 }}>
              {sortOpts.map((o) => (
                <div key={o} onClick={() => { setSort(o); setSortOpen(false) }} style={{ height: 34, display: 'flex', alignItems: 'center', gap: 8, padding: '0 12px', borderRadius: 6, fontSize: 13, color: colors.textMuted, cursor: 'pointer' }}>
                  <span style={{ width: 6, height: 6, borderRadius: '50%', background: o === sort ? colors.green : 'transparent' }} />{o}
                </div>
              ))}
            </div>
          )}
        </div>
        <div style={{ display: 'flex', border: `1px solid ${colors.border}`, borderRadius: 7, overflow: 'hidden' }}>
          <div onClick={() => setView('grid')} style={gridBtn(view === 'grid')}><Icon name="grid" size={15} color="currentColor" strokeWidth={2} /></div>
          <div onClick={() => setView('list')} style={gridBtn(view === 'list')}><Icon name="list" size={15} color="currentColor" strokeWidth={2} /></div>
        </div>
        <span style={{ fontSize: 12, color: colors.textSoft, marginLeft: 'auto' }}>{filtered.length} projects</span>
      </div>

      {/* City tabs */}
      <div className="pd-tabs" style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '0 24px', display: 'flex', overflowX: 'auto' }}>
        {cities.map((t) => <Tab key={t} label={t} active={city === t} onClick={() => setCity(t)} />)}
      </div>
      {/* Category tabs */}
      <div className="pd-tabs" style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '0 24px', display: 'flex', overflowX: 'auto' }}>
        {cats.map((t) => <Tab key={t} label={t} active={cat === t} onClick={() => setCat(t)} />)}
      </div>

      {/* Cards */}
      <div style={{ background: colors.bg, padding: '20px 24px' }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '64px 20px', color: colors.textSoft }}>
            <Icon name="search" size={28} color={colors.textFaint} style={{ margin: '0 auto 12px' }} />
            <div style={{ fontSize: 14, fontWeight: 600, color: colors.text }}>No projects found</div>
            <div style={{ fontSize: 13, marginTop: 4 }}>Try adjusting your filters or search.</div>
          </div>
        ) : view === 'grid' ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
            {filtered.map((p) => <ListingCard key={p.id} p={p} navigate={navigate} />)}
          </div>
        ) : (
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden' }}>
            {filtered.map((p) => {
              const st = statusTone[p.sk]
              return (
                <div key={p.id} onClick={() => navigate('/project/' + (p.id === 1 ? 'palm-residence' : p.id))} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', borderBottom: `1px solid ${colors.surfaceMuted}`, cursor: 'pointer' }}>
                  <div style={{ width: 48, height: 40, minWidth: 48, borderRadius: 6, background: colors.surfaceMuted, backgroundImage: hatch }} />
                  <span style={{ flex: 2, minWidth: 0, fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</span>
                  <span style={{ flex: 1, fontSize: 12, color: colors.textFaint, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.loc}</span>
                  <span style={{ background: colors.surfaceMuted, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 500, color: colors.textMuted }}>{p.type}</span>
                  <span style={{ background: st.bg, color: st.color, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 500 }}>{p.status}</span>
                  <span style={{ flex: 1, fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', textAlign: 'right' }}>{p.price}</span>
                  <span style={{ background: colors.ink, color: '#fff', borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>{p.comm}</span>
                </div>
              )
            })}
          </div>
        )}

        {/* Pagination */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 20, flexWrap: 'wrap', gap: 12 }}>
          <span style={{ fontSize: 12, color: colors.textSoft }}>Showing 1–18 of 48 projects</span>
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <span style={{ width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${colors.border}`, borderRadius: 7, cursor: 'pointer', background: '#fff', color: colors.textMuted }}>‹</span>
            {['1', '2', '3'].map((n, i) => (
              <span key={n} style={{ width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 7, fontSize: 13, fontWeight: i === 0 ? 600 : 400, border: i === 0 ? 'none' : `1px solid ${colors.border}`, background: i === 0 ? colors.ink : '#fff', color: i === 0 ? '#fff' : colors.textMuted, cursor: 'pointer' }}>{n}</span>
            ))}
            <span style={{ color: colors.textFaint, padding: '0 4px' }}>…</span>
            <span style={{ width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 13, color: colors.textMuted, background: '#fff', cursor: 'pointer' }}>8</span>
            <span style={{ width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${colors.border}`, borderRadius: 7, cursor: 'pointer', background: '#fff', color: colors.textMuted }}>›</span>
          </div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span style={{ fontSize: 12, color: colors.textSoft }}>Show:</span>
            <select style={{ height: 32, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 8px', fontSize: 12, fontFamily: 'inherit', background: '#fff' }}><option>18</option><option>36</option><option>54</option></select>
          </div>
        </div>
      </div>
    </div>
  )
}
