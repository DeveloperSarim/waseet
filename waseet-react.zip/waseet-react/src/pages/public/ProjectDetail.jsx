import React, { useState } from 'react'
import { useNavigate, useParams, Link } from 'react-router-dom'
import { colors, radius } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { useHover } from '../../hooks/useHover'
import { getProject } from '../../data/mock'

const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 8px)'
const card = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: 20 }
const cardTitle = { fontSize: 14, fontWeight: 600, marginBottom: 14 }

const unitData = [
  { type: 'Studio', size: '45–55 m²', price: 'SAR 420k–480k', units: '8 available', comm: '3%', sold: false },
  { type: '1BR', size: '75–90 m²', price: 'SAR 600k–700k', units: '12 available', comm: '3%', sold: false },
  { type: '2BR', size: '110–130 m²', price: 'SAR 850k–1M', units: '8 available', comm: '3%', sold: false },
  { type: '3BR', size: '150–170 m²', price: 'SAR 1.1M–1.3M', units: 'Sold Out', comm: '2.5%', sold: true },
]
const amenities = [
  { name: 'Swimming Pool', d: 'M2 16c2 0 2 1.2 4 1.2s2-1.2 4-1.2 2 1.2 4 1.2 2-1.2 4-1.2M2 20c2 0 2 1.2 4 1.2s2-1.2 4-1.2 2 1.2 4 1.2 2-1.2 4-1.2M7 14V5a2 2 0 0 1 4 0M7 9h4' },
  { name: 'Gymnasium', d: 'M4 9v6M8 7v10M16 7v10M20 9v6M8 12h8' },
  { name: '24/7 Security', d: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z' },
  { name: 'Underground Parking', d: 'M7 21V4h6a4 4 0 0 1 0 8H7' },
  { name: 'Landscaped Garden', d: 'M5 21c0-9 6-13 14-13 0 8-4 14-13 14M5 21c2-4 5-6 9-7' },
  { name: 'High-speed Elevators', d: 'M6 3h12v18H6zM10 8l2-2 2 2M10 16l2 2 2-2' },
  { name: 'Retail Ground Floor', d: 'M3 9l1-5h16l1 5M4 9h16v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z' },
  { name: 'Kids Play Area', d: 'M12 4a1.5 1.5 0 1 0 0 0.01M5 21l3-7h8l3 7M9 14v-3a3 3 0 0 1 6 0v3' },
  { name: 'Steam & Sauna', d: 'M4 20h16M6 20v-6M18 20v-6M5 14h14' },
  { name: 'Accessible Design', d: 'M12 5a1.5 1.5 0 1 0 0 0.01M9 9l3 1h3M12 10v4l3 5M12 14a4 4 0 1 0 3 6.4' },
  { name: 'Smart Home System', d: 'M5 12a10 10 0 0 1 14 0M8.5 15.5a5 5 0 0 1 7 0M12 19h0.01' },
  { name: 'Sea View Units', d: 'M2 9c2 0 2 1.2 4 1.2S10 9 12 9s2 1.2 4 1.2S20 9 22 9M2 14c2 0 2 1.2 4 1.2S10 14 12 14s2 1.2 4 1.2S20 14 22 14' },
]
const nearby = [
  { name: 'Al-Noor International School', dist: '0.5 km', d: 'M3 10l9-5 9 5-9 5zM7 12v5c0 1 5 3 5 3s5-2 5-3v-5' },
  { name: 'Al-Hamra Medical Center', dist: '1.2 km', d: 'M5 21V8l7-5 7 5v13M9 12h6M12 9v6' },
  { name: 'Red Sea Mall', dist: '2.0 km', d: 'M6 8V6a6 6 0 0 1 12 0v2M4 8h16l-1 12H5z' },
  { name: 'Al-Rawdhah Mosque', dist: '0.3 km', d: 'M12 3c-3 3-5 5-5 8h10c0-3-2-5-5-8zM5 21v-8M19 21v-8M8 21v-6h8v6' },
  { name: 'Jeddah Corniche', dist: '3.5 km', d: 'M3 20h18M12 12V4M12 12c-3 0-5-2-5-5 3 0 5 2 5 5' },
]
const documents = [
  { name: 'Project Brochure', size: '4.2 MB' },
  { name: 'Payment Plan', size: '1.8 MB' },
  { name: 'Master Plan', size: '6.1 MB' },
  { name: 'NOC Document', size: '2.3 MB' },
]
const quickFacts = [
  { value: 'Under Construction', label: 'Status', d: 'M2 20h20M4 20V10l5-3 5 3v10M9 13h0.01M9 16h0.01' },
  { value: 'Q4 2027', label: 'Handover', d: 'M3 4h18v18H3zM16 2v4M8 2v4M3 10h18' },
  { value: '12', label: 'Floors', d: 'M6 3h12v18H6zM10 7h4M10 11h4M10 15h4' },
  { value: '96', label: 'Total units', d: 'M3 21h18M5 21V7l7-4 7 4v14M10 21v-5h4v5' },
  { value: '45 – 170 m²', label: 'Unit sizes', d: 'M3 3h18v18H3zM3 9h18M9 21V9' },
  { value: 'SAR 420k', label: 'Starting from', d: 'M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6' },
]
const fpTabs = ['Studio', '1BR', '2BR', '3BR']

function SectionCard({ title, right, children, style }) {
  return (
    <div style={{ ...card, ...style }}>
      {title && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <span style={cardTitle}>{title}</span>
          {right}
        </div>
      )}
      {children}
    </div>
  )
}

export default function ProjectDetail() {
  const navigate = useNavigate()
  const { id } = useParams()
  const project = getProject(id)
  const name = project?.name || 'Palm Residence'
  const location = project?.location || 'Al Rawdhah, Jeddah'
  const developer = project?.developer || 'Al Faisal Development'

  const [img, setImg] = useState(1)
  const [saved, setSaved] = useState(false)
  const [aboutOpen, setAboutOpen] = useState(false)
  const [fpTab, setFpTab] = useState('1BR')
  const [lead, setLead] = useState({ name: '', phone: '', unit: '', budget: '', notes: '' })
  const [leadSubmitted, setLeadSubmitted] = useState(false)

  const canSubmit = lead.name.trim() && lead.phone.trim() && lead.unit
  const onSubmit = () => {
    if (!canSubmit) return
    setLeadSubmitted(true)
  }

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', color: colors.ink, background: colors.bg, minHeight: '100vh' }}>
      {/* Navbar */}
      <div style={{ height: 56, minHeight: 56, borderBottom: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 32px', background: '#fff', position: 'sticky', top: 0, zIndex: 40 }}>
        <Link to="/marketplace" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke={colors.ink} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11z" /><circle cx="12" cy="11" r="2.4" /></svg>
          <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>waseet</span>
          <span style={{ fontSize: 12, color: colors.textFaint, marginLeft: 2 }}>وسيط</span>
        </Link>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ position: 'relative', cursor: 'pointer' }}>
            <Icon name="bell" size={20} color={colors.textMuted} strokeWidth={1.7} />
            <span style={{ position: 'absolute', top: -4, right: -5, background: colors.green, color: '#fff', fontSize: 9, fontWeight: 700, borderRadius: 999, minWidth: 15, height: 15, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 3px' }}>3</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer' }} onClick={() => navigate('/realtor')}>
            <div style={{ width: 30, height: 30, borderRadius: '50%', background: colors.surfaceMuted, border: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600, color: colors.textMuted }}>RM</div>
            <Icon name="chevronDown" size={13} color={colors.textFaint} strokeWidth={2} />
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <div style={{ height: 44, background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '0 32px', display: 'flex', alignItems: 'center', gap: 6 }}>
        <Link to="/marketplace" style={{ fontSize: 12, color: colors.textSoft }}>Marketplace</Link>
        <span style={{ fontSize: 12, color: colors.borderStrong }}>/</span>
        <span style={{ fontSize: 12, color: colors.textSoft }}>{project?.city || 'Jeddah'}</span>
        <span style={{ fontSize: 12, color: colors.borderStrong }}>/</span>
        <span style={{ fontSize: 12, color: colors.ink }}>{name}</span>
      </div>

      {/* Gallery */}
      <div style={{ background: '#fff', maxWidth: 1280, margin: '0 auto', borderLeft: `1px solid ${colors.border}`, borderRight: `1px solid ${colors.border}` }}>
        <div style={{ aspectRatio: '16 / 9', background: colors.surfaceMuted, backgroundImage: hatch, position: 'relative', cursor: 'zoom-in' }}>
          <span style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', fontFamily: 'monospace', fontSize: 12, color: '#B6BAC0' }}>project image {img} / 12</span>
          <div style={{ position: 'absolute', top: 14, left: 14, display: 'flex', gap: 6 }}>
            <span style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 999, padding: '3px 8px', fontSize: 10, fontWeight: 600, color: colors.greenDark }}>FEATURED</span>
            <span style={{ background: '#FEF9EC', border: '1px solid #F3E2B8', borderRadius: 999, padding: '3px 8px', fontSize: 10, fontWeight: 600, color: '#92763A' }}>NEW</span>
          </div>
          <div style={{ position: 'absolute', top: 14, right: 14, display: 'flex', gap: 6 }}>
            <div style={{ width: 32, height: 32, background: 'rgba(255,255,255,0.9)', border: `1px solid ${colors.border}`, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
              <Icon name="send" size={16} color={colors.textSoft} strokeWidth={1.8} />
            </div>
            <div onClick={() => setSaved(!saved)} style={{ width: 32, height: 32, background: 'rgba(255,255,255,0.9)', border: `1px solid ${colors.border}`, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
              <svg width={16} height={16} viewBox="0 0 24 24" fill={saved ? colors.green : 'none'} stroke={saved ? colors.green : colors.textSoft} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" /></svg>
            </div>
          </div>
          <div onClick={() => setImg((i) => (i > 1 ? i - 1 : 12))} style={{ position: 'absolute', left: 16, top: '50%', transform: 'translateY(-50%)', width: 36, height: 36, background: 'rgba(255,255,255,0.9)', border: `1px solid ${colors.border}`, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <Icon name="chevronLeft" size={18} color={colors.textMuted} strokeWidth={2} />
          </div>
          <div onClick={() => setImg((i) => (i < 12 ? i + 1 : 1))} style={{ position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%)', width: 36, height: 36, background: 'rgba(255,255,255,0.9)', border: `1px solid ${colors.border}`, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <Icon name="chevronRight" size={18} color={colors.textMuted} strokeWidth={2} />
          </div>
          <div style={{ position: 'absolute', bottom: 16, right: 16, background: 'rgba(0,0,0,0.5)', borderRadius: 999, padding: '4px 10px', fontSize: 11, fontWeight: 500, color: '#fff' }}>{img} / 12</div>
        </div>
        <div style={{ padding: '10px 32px', borderBottom: `1px solid ${colors.border}`, display: 'flex', gap: 8, overflowX: 'auto' }}>
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} onClick={() => setImg(i + 1)} style={{ width: 64, height: 44, minWidth: 64, borderRadius: 6, background: colors.surfaceMuted, backgroundImage: hatch, border: `2px solid ${img === i + 1 ? colors.green : 'transparent'}`, cursor: 'pointer' }} />
          ))}
        </div>
      </div>

      {/* Two column */}
      <div className="pd-cols" style={{ display: 'flex', gap: 24, padding: '24px 32px', maxWidth: 1280, margin: '0 auto', alignItems: 'flex-start' }}>
        {/* LEFT */}
        <div style={{ flex: 2.5, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Header */}
          <div style={card}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12, flexWrap: 'wrap' }}>
              <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', margin: 0 }}>{name}</h1>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{ background: '#FEF9EC', border: '1px solid #F3E2B8', borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 600, color: '#92763A' }}>Under Construction</span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: colors.textFaint }}>
                  <Icon name="eye" size={12} color="currentColor" strokeWidth={2} />124 views
                </span>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 16, marginTop: 10, flexWrap: 'wrap' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: colors.textMuted }}><Icon name="mapPin" size={14} color={colors.green} strokeWidth={1.9} />{location}, Saudi Arabia</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: colors.textMuted }}><Icon name="building" size={14} color={colors.textFaint} strokeWidth={1.8} />{developer} <Icon name="checkCircle" size={13} color={colors.green} strokeWidth={2} /></span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: colors.textMuted }}><Icon name="calendar" size={14} color={colors.textFaint} strokeWidth={1.8} />Handover: Q4 2027</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: colors.textMuted }}><Icon name="layers" size={14} color={colors.textFaint} strokeWidth={1.8} />12 Floors · 96 Units</span>
            </div>
            <div style={{ marginTop: 14 }}>
              <div style={{ fontSize: 11, color: colors.textFaint }}>Launch price from:</div>
              <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.01em', marginTop: 1 }}>SAR 420,000 <span style={{ fontSize: 12, fontWeight: 400, color: colors.textFaint }}>per unit</span></div>
            </div>
          </div>

          {/* Unit types */}
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ padding: '12px 16px', background: colors.bg, borderBottom: `1px solid ${colors.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 13, fontWeight: 600 }}>Unit Types</span>
              <span style={{ fontSize: 11, color: colors.textFaint }}>All prices include VAT</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1.4fr 1.1fr 0.9fr', background: colors.bg, borderBottom: `1px solid ${colors.border}`, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              <span style={{ padding: '9px 16px' }}>Type</span><span style={{ padding: '9px 8px' }}>Size</span><span style={{ padding: '9px 8px' }}>Price</span><span style={{ padding: '9px 8px' }}>Units Avail.</span><span style={{ padding: '9px 8px' }}>Commission</span>
            </div>
            {unitData.map((u) => (
              <div key={u.type} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1.4fr 1.1fr 0.9fr', height: 44, borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                <span style={{ padding: '0 16px', display: 'flex', alignItems: 'center', fontSize: 13, fontWeight: 600, color: u.sold ? colors.textFaint : colors.ink, textDecoration: u.sold ? 'line-through' : 'none', fontStyle: u.sold ? 'italic' : 'normal' }}>{u.type}</span>
                <span style={{ padding: '0 8px', display: 'flex', alignItems: 'center', fontSize: 13, color: u.sold ? colors.textFaint : colors.textMuted }}>{u.size}</span>
                <span style={{ padding: '0 8px', display: 'flex', alignItems: 'center', fontSize: 13, fontWeight: 600, color: u.sold ? colors.textFaint : colors.ink }}>{u.price}</span>
                <span style={{ padding: '0 8px', display: 'flex', alignItems: 'center', fontSize: 13, color: u.sold ? colors.textFaint : colors.textMuted }}>{u.units}</span>
                <span style={{ padding: '0 8px', display: 'flex', alignItems: 'center' }}><span style={{ background: colors.greenTint, color: colors.greenDark, fontSize: 13, fontWeight: 700, padding: '3px 8px', borderRadius: 4 }}>{u.comm}</span></span>
              </div>
            ))}
          </div>

          {/* About */}
          <div style={card}>
            <div style={cardTitle}>About the project</div>
            <div
              style={
                aboutOpen
                  ? undefined
                  : { maxHeight: 96, overflow: 'hidden', WebkitMaskImage: 'linear-gradient(#000 60%, transparent)', maskImage: 'linear-gradient(#000 60%, transparent)' }
              }
            >
              <p style={{ fontSize: 13, color: colors.textMuted, lineHeight: 1.7, margin: '0 0 12px' }}>
                {name} is a premium residential development located in the prestigious {location} district. The project features 96 fully finished units across 12 floors, offering studio, 1BR, 2BR, and 3BR apartments with panoramic views of the Red Sea.
              </p>
              <p style={{ fontSize: 13, color: colors.textMuted, lineHeight: 1.7, margin: 0 }}>
                Built to international standards with high-end German kitchen fittings, Italian marble flooring, and smart home automation throughout every unit.
              </p>
            </div>
            <span onClick={() => setAboutOpen(!aboutOpen)} style={{ display: 'inline-block', marginTop: 10, fontSize: 13, color: colors.green, cursor: 'pointer', fontWeight: 500 }}>{aboutOpen ? 'Show less ↑' : 'Show more ↓'}</span>
          </div>

          {/* Status timeline */}
          <SectionCard title="Project status" right={<span style={{ fontSize: 12, fontWeight: 600, color: colors.ink }}>68% Complete</span>}>
            <div style={{ display: 'flex', position: 'relative', marginTop: 6 }}>
              <div style={{ position: 'absolute', top: 7, left: '12%', right: '12%', height: 2, background: 'linear-gradient(90deg, #16A34A 0%, #16A34A 55%, #E5E7EB 55%, #E5E7EB 100%)' }} />
              {[
                { label: 'Planning', date: 'Q1 2024', state: 'done' },
                { label: 'Foundation', date: 'Q3 2024', state: 'done' },
                { label: 'Construction', date: 'In Progress', state: 'active' },
                { label: 'Handover', date: 'Q4 2027', state: 'todo' },
              ].map((s) => (
                <div key={s.label} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', position: 'relative' }}>
                  <span style={{ width: 16, height: 16, borderRadius: '50%', background: s.state === 'done' ? colors.green : '#fff', border: s.state === 'todo' ? `2px solid ${colors.border}` : `2px solid ${colors.green}`, boxShadow: s.state === 'done' ? `0 0 0 1px ${colors.green}` : 'none', animation: s.state === 'active' ? 'ps-pulse 1.8s ease-in-out infinite' : 'none' }} />
                  <span style={{ fontSize: 11, fontWeight: 600, color: s.state === 'todo' ? colors.textFaint : colors.green, marginTop: 8 }}>{s.label}</span>
                  <span style={{ fontSize: 10, color: s.state === 'todo' ? colors.textFaint : colors.green }}>{s.date}</span>
                </div>
              ))}
            </div>
          </SectionCard>

          {/* Payment plan */}
          <div style={card}>
            <div style={{ ...cardTitle, marginBottom: 16 }}>Payment plan</div>
            <div style={{ height: 40, borderRadius: 8, overflow: 'hidden', display: 'flex' }}>
              <div style={{ width: '20%', background: colors.greenTint, borderRight: '1px solid #fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600, color: colors.greenDark }}>20%</div>
              <div style={{ width: '60%', background: colors.greenSoft, borderRight: '1px solid #fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600, color: colors.greenDark }}>60%</div>
              <div style={{ width: '20%', background: colors.greenTintBorder, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600, color: colors.greenDark }}>20%</div>
            </div>
            <div style={{ display: 'flex', gap: 24, marginTop: 14, flexWrap: 'wrap' }}>
              {[
                { pct: '20%', title: 'Down payment', sub: 'On signing' },
                { pct: '60%', title: 'During construction', sub: 'Quarterly instalments' },
                { pct: '20%', title: 'On handover', sub: 'Q4 2027' },
              ].map((p) => (
                <div key={p.title}>
                  <div style={{ fontSize: 16, fontWeight: 700 }}>{p.pct}</div>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>{p.title}</div>
                  <div style={{ fontSize: 12, color: colors.textMuted, marginTop: 1 }}>{p.sub}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Amenities */}
          <div style={card}>
            <div style={{ ...cardTitle, marginBottom: 16 }}>Features &amp; Amenities</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 12 }}>
              {amenities.map((a) => (
                <div key={a.name} style={{ display: 'flex', gap: 10, alignItems: 'center', padding: '10px 12px', background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8 }}>
                  <span style={{ width: 32, height: 32, minWidth: 32, background: colors.greenTint, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round"><path d={a.d} /></svg>
                  </span>
                  <span style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted }}>{a.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Floor plans */}
          <div style={card}>
            <div style={{ ...cardTitle, marginBottom: 14 }}>Floor plans</div>
            <div style={{ display: 'flex', borderBottom: `1px solid ${colors.border}`, marginBottom: 16 }}>
              {fpTabs.map((t) => (
                <div key={t} onClick={() => setFpTab(t)} style={{ padding: '8px 14px 10px', fontSize: 12, cursor: 'pointer', color: fpTab === t ? colors.ink : colors.textSoft, fontWeight: fpTab === t ? 600 : 400, borderBottom: `2px solid ${fpTab === t ? colors.ink : 'transparent'}` }}>{t}</div>
              ))}
            </div>
            <div style={{ position: 'relative', width: '100%', height: 240, background: colors.surfaceMuted, backgroundImage: hatch, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ fontFamily: 'monospace', fontSize: 12, color: colors.textFaint }}>Floor plan — {fpTab}</span>
              <div style={{ position: 'absolute', bottom: 10, right: 10, background: 'rgba(0,0,0,0.5)', color: '#fff', fontSize: 11, fontWeight: 500, padding: '5px 10px', borderRadius: 6, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
                <Icon name="externalLink" size={13} color="currentColor" strokeWidth={2} />Expand
              </div>
            </div>
            <div style={{ marginTop: 12 }}>
              <button style={{ height: 32, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, background: '#fff', fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
                <Icon name="download" size={13} color="currentColor" strokeWidth={1.8} />Download {fpTab} Floor Plan
              </button>
            </div>
          </div>

          {/* Location */}
          <div style={card}>
            <div style={{ ...cardTitle, marginBottom: 14 }}>Location</div>
            <div style={{ position: 'relative', width: '100%', height: 280, background: '#EAEEF0', backgroundImage: 'linear-gradient(#dfe4e7 1px, transparent 1px), linear-gradient(90deg, #dfe4e7 1px, transparent 1px)', backgroundSize: '28px 28px', borderRadius: 10, overflow: 'hidden' }}>
              <div style={{ position: 'absolute', top: '45%', left: '48%', transform: 'translate(-50%,-100%)' }}>
                <svg width={30} height={30} viewBox="0 0 24 24" fill={colors.green} stroke="#fff" strokeWidth={1.5}><path d="M12 22s7-6.5 7-12a7 7 0 1 0-14 0c0 5.5 7 12 7 12z" /><circle cx="12" cy="9" r="2.5" fill="#fff" stroke="none" /></svg>
              </div>
              <span style={{ position: 'absolute', bottom: 10, left: 12, fontFamily: 'monospace', fontSize: 10, color: colors.textFaint }}>map · {location}</span>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginTop: 12 }}>
              <Icon name="mapPin" size={14} color={colors.green} strokeWidth={1.9} style={{ flexShrink: 0, marginTop: 2 }} />
              <span style={{ fontSize: 13, color: colors.textMuted, lineHeight: 1.5 }}>{location} District, 23832, Saudi Arabia</span>
            </div>
            <div style={{ marginTop: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 10 }}>Nearby</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {nearby.map((n) => (
                  <div key={n.name} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 12px', background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8 }}>
                    <span style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round"><path d={n.d} /></svg>
                      <span style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted }}>{n.name}</span>
                    </span>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>{n.dist}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Developer */}
          <div style={card}>
            <div style={{ ...cardTitle, marginBottom: 14 }}>Developer</div>
            <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
              <div style={{ width: 48, height: 48, minWidth: 48, background: colors.surfaceMuted, border: `1px solid ${colors.border}`, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: colors.textMuted }}>AF</div>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <span style={{ fontSize: 14, fontWeight: 700 }}>{developer}</span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 11, fontWeight: 600, color: colors.green }}><Icon name="checkCircle" size={13} color={colors.green} strokeWidth={2} />Verified</span>
                </div>
                <div style={{ fontSize: 12, color: colors.textSoft, marginTop: 2 }}>Est. 2015 · Real Estate Developer</div>
                <div style={{ fontSize: 12, color: colors.green, marginTop: 2 }}>12 projects on Waseet</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 16, marginTop: 14, borderTop: `1px solid ${colors.surfaceMuted}`, paddingTop: 14 }}>
              {[{ v: '12', l: 'Projects' }, { v: '48', l: 'Avg. leads/project' }, { v: 'SAR 850k', l: 'Avg. price' }].map((s, i) => (
                <div key={s.l} style={{ flex: 1, textAlign: 'center', borderLeft: i ? `1px solid ${colors.surfaceMuted}` : 'none' }}>
                  <div style={{ fontSize: 16, fontWeight: 700 }}>{s.v}</div>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>{s.l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Documents */}
          <div style={card}>
            <div style={{ ...cardTitle, marginBottom: 14 }}>Documents</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {documents.map((d) => (
                <div key={d.name} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '11px 14px', background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, cursor: 'pointer' }}>
                  <span style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <Icon name="fileText" size={18} color={colors.textFaint} strokeWidth={1.7} />
                    <span style={{ fontSize: 13, fontWeight: 500, color: colors.textMuted }}>{d.name}</span>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>{d.size}</span>
                  </span>
                  <Icon name="download" size={16} color={colors.textFaint} strokeWidth={1.8} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT sticky */}
        <div className="pd-right" style={{ flex: 1, minWidth: 300, position: 'sticky', top: 72, alignSelf: 'flex-start', display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* Commission rates */}
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: 18 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 12 }}>Commission rates</div>
            {[['Studio', '3%'], ['1BR', '3%'], ['2BR', '3%'], ['3BR', '2.5%']].map(([t, c], i) => (
              <div key={t} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 0', borderBottom: i < 3 ? `1px solid ${colors.surfaceMuted}` : 'none' }}>
                <span style={{ fontSize: 13, color: i === 3 ? colors.textFaint : colors.textMuted }}>{t}</span>
                <span style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, color: colors.greenDark, fontSize: 13, fontWeight: 700, borderRadius: 6, padding: '3px 10px' }}>{c}</span>
              </div>
            ))}
            <div style={{ marginTop: 12, background: colors.bg, borderRadius: 8, padding: '10px 12px' }}>
              <div style={{ fontSize: 11, color: colors.textFaint }}>On a SAR 900k unit</div>
              <div style={{ fontSize: 13, fontWeight: 700, marginTop: 1 }}>Your commission: SAR 27,000</div>
              <div style={{ fontSize: 10, color: colors.textFaint, marginTop: 1 }}>(before platform fee)</div>
            </div>
          </div>

          {/* Lead form */}
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: 18 }} className="wa-form">
            {!leadSubmitted ? (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                  <span style={{ fontSize: 14, fontWeight: 600 }}>Submit a lead</span>
                  <span style={{ fontSize: 11, color: colors.textFaint }}>48 leads submitted</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Client full name</div>
                    <input value={lead.name} onChange={(e) => setLead({ ...lead, name: e.target.value })} placeholder="Khalid Al-Mansour" style={inputSt} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Client phone</div>
                    <div style={{ display: 'flex', border: `1px solid ${colors.border}`, borderRadius: 7, overflow: 'hidden' }}>
                      <span style={{ width: 84, background: colors.bg, borderRight: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', padding: '0 8px', fontSize: 12, color: colors.textMuted }}>🇸🇦 +966</span>
                      <input value={lead.phone} onChange={(e) => setLead({ ...lead, phone: e.target.value })} placeholder="5X XXX XXXX" style={{ flex: 1, height: 34, border: 'none', padding: '0 10px', fontSize: 13, fontFamily: 'inherit', minWidth: 0 }} />
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Unit type</div>
                    <select value={lead.unit} onChange={(e) => setLead({ ...lead, unit: e.target.value })} style={{ ...inputSt, color: lead.unit ? colors.ink : colors.textFaint }}>
                      <option value="">Select unit type</option>
                      <option value="Studio">Studio (3%)</option>
                      <option value="1BR">1BR (3%)</option>
                      <option value="2BR">2BR (3%)</option>
                      <option value="3BR">3BR (2.5%)</option>
                    </select>
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Client budget (optional)</div>
                    <input value={lead.budget} onChange={(e) => setLead({ ...lead, budget: e.target.value })} placeholder="SAR 800,000" style={inputSt} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Notes (optional)</div>
                    <textarea value={lead.notes} onChange={(e) => setLead({ ...lead, notes: e.target.value })} placeholder="Any relevant details about the client..." style={{ width: '100%', height: 72, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, fontFamily: 'inherit', color: colors.textMuted, resize: 'none' }} />
                  </div>
                  <button onClick={onSubmit} disabled={!canSubmit} style={{ width: '100%', height: 38, border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 600, color: '#fff', fontFamily: 'inherit', background: canSubmit ? colors.green : colors.textFaint, cursor: canSubmit ? 'pointer' : 'not-allowed' }}>Submit Lead</button>
                  <div style={{ fontSize: 11, color: colors.textFaint, textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5 }}>
                    <Icon name="eye" size={12} color="currentColor" strokeWidth={2} />124 realtors have viewed this project
                  </div>
                </div>
              </>
            ) : (
              <div style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 10, padding: 18, textAlign: 'center' }}>
                <Icon name="checkCircle" size={32} color={colors.green} strokeWidth={2} style={{ margin: '0 auto 12px' }} />
                <div style={{ fontSize: 14, fontWeight: 600 }}>Lead submitted!</div>
                <div style={{ fontSize: 12, color: colors.textMuted, marginTop: 4 }}>Client: {lead.name || 'Khalid Al-Mansour'} · {lead.unit || '2BR'}</div>
                <div style={{ fontSize: 12, color: colors.textSoft, marginTop: 6 }}>The developer has been notified.</div>
                <button onClick={() => navigate('/realtor/leads')} style={{ width: '100%', height: 32, marginTop: 12, background: '#fff', border: `1px solid ${colors.greenTintBorder}`, borderRadius: 7, fontSize: 13, fontWeight: 500, color: colors.greenDark, fontFamily: 'inherit', cursor: 'pointer' }}>View in My Leads →</button>
                <span onClick={() => { setLeadSubmitted(false); setLead({ name: '', phone: '', unit: '', budget: '', notes: '' }) }} style={{ display: 'inline-block', marginTop: 8, fontSize: 12, color: colors.greenDark, cursor: 'pointer' }}>Submit another lead</span>
              </div>
            )}
          </div>

          {/* Quick info */}
          <div style={{ background: colors.bg, border: `1px solid ${colors.border}`, borderRadius: 12, padding: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              {quickFacts.map((q) => (
                <div key={q.label}>
                  <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom: 4 }}><path d={q.d} /></svg>
                  <div style={{ fontSize: 12, fontWeight: 600 }}>{q.value}</div>
                  <div style={{ fontSize: 10, color: colors.textFaint }}>{q.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Similar projects */}
      <SimilarProjects navigate={navigate} city={project?.city || 'Jeddah'} />
    </div>
  )
}

const similarProjects = [
  { name: 'Marsa Heights', loc: 'Al Shati, Jeddah', price: 'SAR 980k – 1.6M', comm: '3.5%', badge: 'FEATURED', g: 'linear-gradient(150deg,#0F3D2E,#1E7A52)' },
  { name: 'Obhur Bay Villas', loc: 'Obhur, Jeddah', price: 'SAR 2.1M – 4.0M', comm: '4%', badge: 'NEW', g: 'linear-gradient(150deg,#0E4F4A,#2A9D8F)' },
  { name: 'Corniche Towers', loc: 'Al Hamra, Jeddah', price: 'SAR 750k – 1.3M', comm: '3%', badge: 'FEATURED', g: 'linear-gradient(150deg,#1F2937,#4B5563)' },
  { name: 'Al Salam Residences', loc: 'Al Salamah, Jeddah', price: 'SAR 620k – 1.1M', comm: '3%', badge: 'FEATURED', g: 'linear-gradient(150deg,#15803D,#34D058)' },
]

function SimilarCard({ p, navigate }) {
  const [hovered, hoverProps] = useHover()
  const isNew = p.badge === 'NEW'
  return (
    <div
      {...hoverProps}
      onClick={() => navigate('/marketplace')}
      style={{
        background: '#fff',
        border: `1px solid ${hovered ? colors.borderStrong : colors.border}`,
        borderRadius: 12,
        overflow: 'hidden',
        cursor: 'pointer',
        boxShadow: hovered ? '0 4px 16px rgba(0,0,0,0.06)' : 'none',
        transform: hovered ? 'translateY(-2px)' : 'none',
        transition: 'all 180ms ease',
      }}
    >
      <div style={{ height: 150, background: p.g, position: 'relative' }}>
        <div style={{ position: 'absolute', inset: 0, backgroundImage: 'repeating-linear-gradient(45deg, rgba(255,255,255,0.06) 0, rgba(255,255,255,0.06) 1px, transparent 1px, transparent 9px)' }} />
        <span style={{ position: 'absolute', top: 9, left: 9, background: isNew ? '#FEF9EC' : colors.greenTint, border: `1px solid ${isNew ? '#F3E2B8' : colors.greenTintBorder}`, borderRadius: 999, padding: '2px 8px', fontSize: 9, fontWeight: 600, color: isNew ? '#92763A' : colors.greenDark, letterSpacing: '0.03em' }}>{p.badge}</span>
        <span style={{ position: 'absolute', bottom: 9, right: 9, background: '#fff', borderRadius: 6, padding: '3px 9px', fontSize: 11, fontWeight: 700, color: colors.ink }}>{p.comm}</span>
      </div>
      <div style={{ padding: '12px 14px' }}>
        <div style={{ fontSize: 14, fontWeight: 600 }}>{p.name}</div>
        <div style={{ display: 'flex', gap: 4, alignItems: 'center', margin: '3px 0 7px' }}>
          <Icon name="mapPin" size={12} color={colors.textFaint} strokeWidth={2} />
          <span style={{ fontSize: 12, color: colors.textFaint }}>{p.loc}</span>
        </div>
        <div style={{ fontSize: 13, fontWeight: 600 }}>{p.price}</div>
      </div>
    </div>
  )
}

function SimilarProjects({ navigate, city }) {
  return (
    <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '32px 32px 44px' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, letterSpacing: '-0.02em', margin: 0 }}>Similar projects in {city}</h2>
          <span onClick={() => navigate('/marketplace')} style={{ fontSize: 13, color: colors.greenDark, fontWeight: 500, cursor: 'pointer' }}>View all →</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: 16 }}>
          {similarProjects.map((p) => (
            <SimilarCard key={p.name} p={p} navigate={navigate} />
          ))}
        </div>
      </div>
    </div>
  )
}

const inputSt = {
  width: '100%',
  height: 34,
  border: `1px solid ${colors.border}`,
  borderRadius: 7,
  padding: '0 10px',
  fontSize: 13,
  fontFamily: 'inherit',
  color: colors.ink,
  background: '#fff',
}
