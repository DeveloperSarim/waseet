import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { Topbar } from '../../components/layout/Topbar'

const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 7px)'
const stepLabels = ['Basic Info', 'Unit Types', 'Content', 'Media', 'Review']
const inputStyle = { width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 13, fontFamily: 'inherit', color: colors.ink, background: '#fff' }
const selStyle = { ...inputStyle, color: colors.textMuted }
const card = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '16px 20px', marginBottom: 12 }
const cardLabel = { fontSize: 9, fontWeight: 700, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 14 }
const fieldLabel = { fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }

const amenityDefs = [
  ['🏊', 'Swimming Pool'], ['🏋️', 'Gymnasium'], ['🛡️', '24/7 Security'], ['🅿️', 'Parking'],
  ['🌳', 'Garden'], ['🛗', 'Elevators'], ['🏬', 'Retail'], ['🧒', 'Kids Area'],
  ['🧖', 'Sauna'], ['♿', 'Accessible'], ['🏠', 'Smart Home'], ['🌊', 'Sea View'],
]
const rteTools = ['B', 'I', 'U', '•', '1.']
const landmarks = [
  { cat: 'School', name: 'Al-Noor International School', dist: '0.5 km' },
  { cat: 'Hospital', name: 'Al-Hamra Medical Center', dist: '1.2 km' },
  { cat: 'Mall', name: 'Red Sea Mall', dist: '2.0 km' },
]
const docsList = [
  { name: 'Project Brochure', meta: 'PDF · 4.2 MB', done: true },
  { name: 'Payment Plan', meta: 'PDF · 1.8 MB', done: true },
  { name: 'NOC Document', meta: 'Required', done: false },
  { name: 'Floor Plans', meta: 'Required', done: false },
]
const timeline = [
  { title: 'Submitted for review', sub: 'Just now', done: true },
  { title: 'Admin content review', sub: 'Within 24 hours', done: false },
  { title: 'Project goes live', sub: 'After approval', done: false },
  { title: 'Realtors start submitting leads', sub: 'Once live', done: false },
]

function Field({ label, children }) {
  return (
    <div>
      <div style={fieldLabel}>{label}</div>
      {children}
    </div>
  )
}

function Stepper({ step, goTo }) {
  return (
    <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '14px 24px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', maxWidth: 640, margin: '0 auto' }}>
        {stepLabels.map((label, i) => {
          const n = i + 1
          const done = n < step
          const active = n === step
          const node = done
            ? { background: colors.green, color: '#fff', border: 'none' }
            : active
            ? { background: colors.ink, color: '#fff', border: 'none' }
            : { background: '#fff', border: `1px solid ${colors.border}`, color: colors.textFaint }
          return (
            <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                <div style={{ height: 1, flex: 1, background: i === 0 ? 'transparent' : n <= step ? colors.green : colors.border }} />
                <div onClick={() => goTo(n)} style={{ width: 28, height: 28, minWidth: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, cursor: 'pointer', ...node }}>
                  {done ? '✓' : n}
                </div>
                <div style={{ height: 1, flex: 1, background: i === stepLabels.length - 1 ? 'transparent' : n < step ? colors.green : colors.border }} />
              </div>
              <span style={{ fontSize: 10, marginTop: 6, whiteSpace: 'nowrap', color: done ? colors.green : active ? colors.ink : colors.textFaint }}>{label}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default function AddProject() {
  const navigate = useNavigate()
  const [step, setStep] = useState(1)
  const [submitted, setSubmitted] = useState(false)
  const [amenities, setAmenities] = useState([true, true, true, true, false, false, false, false, false, false, false, false])
  const [units, setUnits] = useState([
    { type: '2BR', count: '8', sizeMin: '110', sizeMax: '130', priceMin: '850,000', priceMax: '1,000,000', comm: '3' },
    { type: '1BR', count: '12', sizeMin: '75', sizeMax: '90', priceMin: '600,000', priceMax: '700,000', comm: '3' },
  ])
  const setUnit = (i, k, v) => setUnits(units.map((u, j) => (j === i ? { ...u, [k]: v } : u)))

  const next = () => (step < 5 ? setStep(step + 1) : setSubmitted(true))

  if (submitted) {
    return (
      <>
        <Topbar left={<span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>Add New Project</span>} />
        <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, display: 'flex', alignItems: 'flex-start', justifyContent: 'center' }}>
          <div style={{ maxWidth: 480, padding: '48px 24px', textAlign: 'center' }}>
            <svg width={52} height={52} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom: 16 }}><circle cx="12" cy="12" r="10" /><path d="M8 12l2.5 2.5L16 9" /></svg>
            <div style={{ fontSize: 22, fontWeight: 700, marginBottom: 8 }}>Project submitted! 🎉</div>
            <div style={{ fontSize: 13, color: colors.textSoft, lineHeight: 1.7, marginBottom: 24 }}>Palm Residence is under review. Our team approves within 24 hours.</div>
            <div style={{ textAlign: 'left', maxWidth: 320, margin: '0 auto' }}>
              {timeline.map((t, i) => (
                <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', paddingBottom: 16, position: 'relative' }}>
                  {i !== timeline.length - 1 && <div style={{ position: 'absolute', left: 9, top: 20, width: 1, height: '100%', background: colors.border }} />}
                  <div style={{ width: 20, height: 20, minWidth: 20, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1, background: t.done ? colors.green : '#fff', border: t.done ? 'none' : `1px solid ${colors.border}` }}>
                    {t.done && <svg width={11} height={11} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3}><path d="M5 12l4 4L19 7" /></svg>}
                  </div>
                  <div><div style={{ fontSize: 13, fontWeight: 600 }}>{t.title}</div><div style={{ fontSize: 12, color: colors.textFaint, marginTop: 2 }}>{t.sub}</div></div>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}>
              <button onClick={() => navigate('/developer/projects')} style={{ height: 36, background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>View My Projects</button>
              <button onClick={() => { setSubmitted(false); setStep(1) }} style={{ height: 36, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Add Another Project</button>
            </div>
          </div>
        </div>
      </>
    )
  }

  return (
    <>
      <Topbar
        left={<span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>Add New Project</span>}
        actions={<span style={{ fontSize: 13, color: colors.textFaint }}>Step {step} of 5</span>}
      />
      <Stepper step={step} goTo={setStep} />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg }} className="wa-form">
        <div style={{ maxWidth: 640, margin: '0 auto', padding: '20px 24px' }}>
          {/* STEP 1 */}
          {step === 1 && (
            <>
              <div style={card}>
                <div style={cardLabel}>Basic Information</div>
                <div style={{ marginBottom: 12 }}><Field label="Project Name *"><input placeholder="Palm Residence" style={inputStyle} /></Field></div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
                  <Field label="Project Type *"><select defaultValue="Apartments" style={selStyle}><option>Apartments</option><option>Villas</option><option>Offices</option><option>Townhouses</option><option>Mixed</option></select></Field>
                  <Field label="Development Status *"><select defaultValue="Under Construction" style={selStyle}><option>Under Construction</option><option>Ready</option><option>Off-plan</option></select></Field>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
                  <Field label="Expected Handover *"><input placeholder="Q4 2027" style={inputStyle} /></Field>
                  <Field label="Completion %"><input placeholder="68" style={inputStyle} /></Field>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                  <Field label="Total Floors"><input placeholder="12" style={inputStyle} /></Field>
                  <Field label="Total Units"><input placeholder="96" style={inputStyle} /></Field>
                </div>
              </div>
              <div style={{ ...card, marginBottom: 0 }}>
                <div style={cardLabel}>Location</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
                  <Field label="City *"><select defaultValue="Jeddah" style={selStyle}><option>Jeddah</option><option>Riyadh</option><option>Dammam</option><option>Mecca</option><option>Dubai</option><option>Abu Dhabi</option></select></Field>
                  <Field label="Area / Neighborhood *"><input placeholder="Al Rawdhah" style={inputStyle} /></Field>
                </div>
                <div style={{ marginBottom: 12 }}><Field label="Full Address *"><input placeholder="Street name, district, postal code" style={inputStyle} /></Field></div>
                <div style={{ border: `1px solid ${colors.border}`, borderRadius: 10, overflow: 'hidden' }}>
                  <div style={{ height: 240, background: '#EDF0F2', backgroundImage: 'linear-gradient(rgba(0,0,0,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.04) 1px, transparent 1px)', backgroundSize: '28px 28px', position: 'relative' }}>
                    <div style={{ position: 'absolute', top: 12, left: 12, right: 12, height: 34, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, display: 'flex', alignItems: 'center', padding: '0 10px', gap: 8 }}>
                      <Icon name="search" size={14} color={colors.textFaint} strokeWidth={1.8} /><span style={{ fontSize: 12, color: colors.textFaint }}>Search for address...</span>
                    </div>
                    <div style={{ position: 'absolute', left: '50%', top: '52%', transform: 'translate(-50%,-50%)' }}>
                      <svg width={30} height={30} viewBox="0 0 24 24" fill={colors.red} stroke="#fff" strokeWidth={1.5}><path d="M12 22s7-6 7-12a7 7 0 1 0-14 0c0 6 7 12 7 12z" /><circle cx="12" cy="10" r="2.5" fill="#fff" /></svg>
                    </div>
                  </div>
                  <div style={{ borderTop: `1px solid ${colors.border}`, background: '#fff', padding: '10px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <Icon name="mapPin" size={14} color={colors.green} strokeWidth={1.8} />
                      <div><div style={{ fontSize: 13, color: colors.ink }}>Al Rawdhah, Jeddah 23832</div><div style={{ fontSize: 11, color: colors.textFaint }}>21.5433°N 39.1728°E</div></div>
                    </div>
                    <button style={{ height: 30, padding: '0 12px', background: colors.green, border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 500, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Confirm Location ✓</button>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* STEP 2 */}
          {step === 2 && (
            <div>
              {units.map((u, i) => (
                <div key={i} style={card}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                    <span style={{ fontSize: 13, fontWeight: 600 }}>Unit Type</span>
                    <span onClick={() => setUnits(units.filter((_, j) => j !== i))} style={{ fontSize: 12, color: colors.red, cursor: 'pointer', padding: '2px 6px', borderRadius: 4 }}>× Remove</span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
                    <Field label="Type *"><select value={u.type} onChange={(e) => setUnit(i, 'type', e.target.value)} style={selStyle}><option>Studio</option><option>1BR</option><option>2BR</option><option>3BR</option></select></Field>
                    <Field label="Available Units *"><input value={u.count} onChange={(e) => setUnit(i, 'count', e.target.value)} style={inputStyle} /></Field>
                    <Field label="Size (m²)">
                      <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                        <input value={u.sizeMin} onChange={(e) => setUnit(i, 'sizeMin', e.target.value)} style={inputStyle} /><span style={{ fontSize: 12, color: colors.textFaint }}>to</span><input value={u.sizeMax} onChange={(e) => setUnit(i, 'sizeMax', e.target.value)} style={inputStyle} />
                      </div>
                    </Field>
                    <Field label="Price (SAR)">
                      <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                        <input value={u.priceMin} onChange={(e) => setUnit(i, 'priceMin', e.target.value)} style={inputStyle} /><span style={{ fontSize: 12, color: colors.textFaint }}>to</span><input value={u.priceMax} onChange={(e) => setUnit(i, 'priceMax', e.target.value)} style={inputStyle} />
                      </div>
                    </Field>
                  </div>
                  <div style={{ display: 'flex', gap: 14, alignItems: 'center', paddingTop: 12, borderTop: `1px solid ${colors.surfaceMuted}`, flexWrap: 'wrap' }}>
                    <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <span style={{ width: 16, height: 16, borderRadius: '50%', background: colors.ink, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><span style={{ width: 6, height: 6, borderRadius: '50%', background: '#fff' }} /></span>
                      <span style={{ fontSize: 13, color: colors.textMuted }}>Percentage</span>
                    </span>
                    <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <span style={{ width: 16, height: 16, borderRadius: '50%', background: '#fff', border: `1.5px solid ${colors.borderStrong}` }} />
                      <span style={{ fontSize: 13, color: colors.textMuted }}>Fixed Amount</span>
                    </span>
                    <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <input value={u.comm} onChange={(e) => setUnit(i, 'comm', e.target.value)} style={{ ...inputStyle, width: 64, textAlign: 'right' }} /><span style={{ fontSize: 13, color: colors.textMuted }}>%</span>
                    </span>
                    <span style={{ marginLeft: 'auto', fontSize: 11, color: colors.textFaint }}>Realtor earns ~SAR {(parseInt((u.priceMin || '0').replace(/,/g, '')) * (parseFloat(u.comm) || 0) / 100).toLocaleString()}</span>
                  </div>
                </div>
              ))}
              <div onClick={() => setUnits([...units, { type: 'Studio', count: '', sizeMin: '', sizeMax: '', priceMin: '', priceMax: '', comm: '3' }])} style={{ border: `2px dashed ${colors.borderStrong}`, borderRadius: 10, padding: 12, textAlign: 'center', cursor: 'pointer' }}>
                <span style={{ fontSize: 13, color: colors.textFaint }}>+ Add unit type</span>
              </div>
            </div>
          )}

          {/* STEP 3 */}
          {step === 3 && (
            <div>
              <div style={card}>
                <div style={cardLabel}>Project Description</div>
                <div style={{ border: `1px solid ${colors.border}`, borderRadius: 8, overflow: 'hidden' }}>
                  <div style={{ borderBottom: `1px solid ${colors.surfaceMuted}`, padding: '7px 10px', display: 'flex', gap: 2 }}>
                    {rteTools.map((t) => <span key={t} style={{ width: 28, height: 28, borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center', color: colors.textFaint, fontSize: 13, cursor: 'pointer' }}>{t}</span>)}
                  </div>
                  <div style={{ minHeight: 140, padding: '10px 14px', fontSize: 13, color: colors.textMuted, lineHeight: 1.6 }}>Palm Residence is a premium waterfront development in Al Rawdhah, Jeddah, offering 96 thoughtfully designed apartments across 12 floors. Each unit features sea views, smart-home integration, and access to resort-grade amenities.</div>
                  <div style={{ borderTop: `1px solid ${colors.surfaceMuted}`, padding: '6px 10px', display: 'flex', justifyContent: 'flex-end' }}><span style={{ fontSize: 11, color: colors.textFaint }}>247 / 100 minimum</span></div>
                </div>
              </div>
              <div style={card}>
                <div style={cardLabel}>Amenities</div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 8 }}>
                  {amenityDefs.map(([icon, label], i) => {
                    const on = amenities[i]
                    return (
                      <div key={label} onClick={() => setAmenities(amenities.map((v, j) => (j === i ? !v : v)))} style={{ display: 'flex', gap: 8, alignItems: 'center', padding: '8px 10px', borderRadius: 8, cursor: 'pointer', border: `1px solid ${on ? colors.green : colors.border}`, background: on ? colors.greenTint : '#fff' }}>
                        <span style={{ width: 16, height: 16, minWidth: 16, borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', background: on ? colors.green : '#fff', border: `1.5px solid ${on ? colors.green : colors.borderStrong}` }}>
                          {on && <svg width={10} height={10} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3}><path d="M5 12l4 4L19 7" /></svg>}
                        </span>
                        <span style={{ fontSize: 14 }}>{icon}</span>
                        <span style={{ fontSize: 12, color: on ? colors.greenDarker : colors.textMuted }}>{label}</span>
                      </div>
                    )
                  })}
                </div>
              </div>
              <div style={{ ...card, marginBottom: 0 }}>
                <div style={cardLabel}>Nearby Landmarks</div>
                {landmarks.map((m, i) => (
                  <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'center' }}>
                    <select defaultValue={m.cat} style={{ ...selStyle, width: 130 }}><option>{m.cat}</option><option>School</option><option>Hospital</option><option>Mall</option><option>Mosque</option></select>
                    <input defaultValue={m.name} style={{ ...inputStyle, flex: 1 }} />
                    <input defaultValue={m.dist} style={{ ...inputStyle, width: 80 }} />
                    <span style={{ width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${colors.border}`, borderRadius: 6, color: colors.textFaint, cursor: 'pointer' }}>×</span>
                  </div>
                ))}
                <span style={{ fontSize: 13, color: colors.greenDark, cursor: 'pointer', display: 'inline-block', marginTop: 4 }}>+ Add landmark</span>
              </div>
            </div>
          )}

          {/* STEP 4 */}
          {step === 4 && (
            <div>
              <div style={card}>
                <div style={cardLabel}>Project Images (min 5)</div>
                <div style={{ border: `2px dashed ${colors.borderStrong}`, borderRadius: 12, padding: 28, textAlign: 'center', cursor: 'pointer', marginBottom: 14 }}>
                  <svg width={32} height={32} viewBox="0 0 24 24" fill="none" stroke={colors.borderStrong} strokeWidth={1.5} style={{ margin: '0 auto 10px' }}><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" /><circle cx="12" cy="13" r="4" /></svg>
                  <div style={{ fontSize: 14, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Drag &amp; drop photos here</div>
                  <div style={{ fontSize: 12, color: colors.textFaint }}>or</div>
                  <button style={{ height: 32, padding: '0 14px', marginTop: 6, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Choose Files</button>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 8 }}>JPG, PNG · max 10MB each</div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(80px, 1fr))', gap: 8 }}>
                  {[0, 1, 2, 3, 4].map((i) => (
                    <div key={i} style={{ position: 'relative', border: `1px solid ${colors.border}`, borderRadius: 8, overflow: 'hidden', aspectRatio: '5/4', background: colors.surfaceMuted, backgroundImage: hatch }}>
                      <span style={{ position: 'absolute', top: 4, right: 4, width: 18, height: 18, borderRadius: '50%', background: 'rgba(0,0,0,0.5)', color: '#fff', fontSize: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>×</span>
                    </div>
                  ))}
                </div>
                <div style={{ fontSize: 11, color: colors.green, marginTop: 8 }}>5 / 5 minimum ✓</div>
              </div>
              <div style={card}>
                <div style={cardLabel}>Master Plan</div>
                <div style={{ border: `1px solid ${colors.border}`, borderRadius: 8, overflow: 'hidden' }}>
                  <div style={{ height: 120, background: colors.surfaceMuted, backgroundImage: hatch }} />
                  <div style={{ padding: '8px 12px', fontSize: 12, color: colors.textMuted }}>master_plan.pdf</div>
                </div>
              </div>
              <div style={{ ...card, marginBottom: 0 }}>
                <div style={cardLabel}>Documents</div>
                {docsList.map((d) => (
                  <div key={d.name} style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 8 }}>
                    <div style={{ flex: 1, display: 'flex', gap: 8, alignItems: 'center', background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '10px 12px' }}>
                      <Icon name="fileText" size={16} color={colors.textFaint} strokeWidth={1.7} />
                      <div><div style={{ fontSize: 13, fontWeight: 500, color: colors.textMuted }}>{d.name}</div><div style={{ fontSize: 11, color: colors.textFaint }}>{d.meta}</div></div>
                    </div>
                    {d.done ? (
                      <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}><Icon name="check" size={16} color={colors.green} strokeWidth={2} /><span style={{ fontSize: 11, color: colors.textFaint }}>Replace</span></span>
                    ) : (
                      <button style={{ height: 30, padding: '0 10px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Upload ↑</button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 5 */}
          {step === 5 && (
            <div>
              {[
                { title: 'Basic Info', go: 1, body: (<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px 16px', fontSize: 12 }}><span style={{ color: colors.textFaint }}>Name</span><span style={{ color: colors.textMuted }}>Palm Residence</span><span style={{ color: colors.textFaint }}>Type</span><span style={{ color: colors.textMuted }}>Apartments</span><span style={{ color: colors.textFaint }}>Status</span><span style={{ color: colors.textMuted }}>Under Construction · Q4 2027</span><span style={{ color: colors.textFaint }}>Location</span><span style={{ color: colors.textMuted }}>Al Rawdhah, Jeddah · 12 floors, 96 units</span></div>) },
              ].map((s) => (
                <div key={s.title} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px', marginBottom: 10 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}><span style={{ fontSize: 13, fontWeight: 600 }}>{s.title}</span><span onClick={() => setStep(s.go)} style={{ fontSize: 12, color: colors.greenDark, cursor: 'pointer' }}>Edit ✏️</span></div>
                  {s.body}
                </div>
              ))}
              <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px', marginBottom: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}><span style={{ fontSize: 13, fontWeight: 600 }}>Unit Types</span><span onClick={() => setStep(2)} style={{ fontSize: 12, color: colors.greenDark, cursor: 'pointer' }}>Edit ✏️</span></div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr 1.3fr 0.7fr', gap: 6, fontSize: 12 }}>
                  {['Type', 'Size', 'Price', 'Comm.'].map((h) => <span key={h} style={{ color: colors.textFaint }}>{h}</span>)}
                  <span style={{ color: colors.textMuted }}>2BR</span><span style={{ color: colors.textMuted }}>110–130m²</span><span style={{ color: colors.textMuted }}>850k–1M</span><span style={{ color: colors.textMuted }}>3%</span>
                  <span style={{ color: colors.textMuted }}>1BR</span><span style={{ color: colors.textMuted }}>75–90m²</span><span style={{ color: colors.textMuted }}>600k–700k</span><span style={{ color: colors.textMuted }}>3%</span>
                </div>
              </div>
              <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px', marginBottom: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}><span style={{ fontSize: 13, fontWeight: 600 }}>Amenities</span><span onClick={() => setStep(3)} style={{ fontSize: 12, color: colors.greenDark, cursor: 'pointer' }}>Edit ✏️</span></div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {amenityDefs.filter((_, i) => amenities[i]).map(([, label]) => <span key={label} style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, color: colors.greenDark, borderRadius: 999, padding: '3px 10px', fontSize: 11 }}>{label}</span>)}
                </div>
              </div>
              <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px', marginBottom: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}><span style={{ fontSize: 13, fontWeight: 600 }}>Documents &amp; Images</span><span onClick={() => setStep(4)} style={{ fontSize: 12, color: colors.greenDark, cursor: 'pointer' }}>Edit ✏️</span></div>
                <div style={{ fontSize: 12, color: colors.textMuted, marginBottom: 10 }}>✓ Brochure · ✓ Payment Plan · ✓ NOC · ✓ Floor Plans</div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 6 }}>{[0, 1, 2, 3, 4].map((i) => <div key={i} style={{ aspectRatio: '5/4', borderRadius: 6, background: colors.surfaceMuted, backgroundImage: hatch }} />)}</div>
              </div>
              <div style={{ background: colors.bg, border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px', marginBottom: 16 }}>
                <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 10 }}>If sold at minimum price:</div>
                <div style={{ display: 'grid', gridTemplateColumns: '0.7fr 1fr 0.6fr 1fr', gap: 6, fontSize: 12 }}>
                  {['Type', 'Min Price', 'Comm%', 'Realtor earns'].map((h) => <span key={h} style={{ color: colors.textFaint }}>{h}</span>)}
                  <span style={{ color: colors.textMuted }}>2BR</span><span style={{ color: colors.textMuted }}>SAR 850k</span><span style={{ color: colors.textMuted }}>3%</span><span style={{ color: colors.greenDark, fontWeight: 600 }}>SAR 25,500</span>
                  <span style={{ color: colors.textMuted }}>1BR</span><span style={{ color: colors.textMuted }}>SAR 600k</span><span style={{ color: colors.textMuted }}>3%</span><span style={{ color: colors.greenDark, fontWeight: 600 }}>SAR 18,000</span>
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <button onClick={() => setSubmitted(true)} style={{ height: 38, background: colors.green, border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Submit for Review</button>
                <button style={{ height: 38, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 14, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Save as Draft</button>
              </div>
              <div style={{ fontSize: 12, color: colors.textFaint, textAlign: 'center', marginTop: 10 }}>Admin reviews within 24 hours. You'll be notified by email.</div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom nav */}
      <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, padding: '12px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        {step > 1 ? (
          <button onClick={() => setStep(step - 1)} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>← Previous</button>
        ) : <span />}
        <button onClick={() => navigate('/developer/projects')} style={{ height: 34, padding: '0 14px', background: 'transparent', border: 'none', fontSize: 12, color: colors.textSoft, fontFamily: 'inherit', cursor: 'pointer' }}>Save as Draft</button>
        <button onClick={next} style={{ height: 34, padding: '0 16px', background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>{step < 5 ? 'Next Step →' : 'Submit for Review'}</button>
      </div>
    </>
  )
}
