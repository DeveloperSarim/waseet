import React from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 9px)'

const up = 'M12 19V5M5 12l7-7 7 7'
const down = 'M12 5v14M19 12l-7 7-7-7'
const statCards = [
  { icon: 'M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z', label: 'Total Views', value: '1,248', change: '+187 vs prev 30 days', changeColor: '#16A34A', changeIcon: up },
  { icon: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3', label: 'Doc Downloads', value: '89', change: '+12 vs prev 30 days', changeColor: '#16A34A', changeIcon: up },
  { icon: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6', label: 'Leads Received', value: '48', change: '+8 vs prev 30 days', changeColor: '#16A34A', changeIcon: up },
  { icon: 'M8 11l3 3 5-6M20 6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2z', label: 'Deals Closed', value: '3', change: '-1 vs prev 30 days', changeColor: '#DC2626', changeIcon: down },
]

// line chart: 30 days, values 0..60
const viewsData = [12, 18, 15, 22, 20, 28, 25, 33, 30, 38, 35, 42, 40, 48, 55, 50, 46, 44, 40, 42, 38, 36, 34, 38, 33, 30, 34, 32, 36, 40]
const leadsData = [1, 0, 2, 1, 3, 2, 1, 2, 3, 2, 4, 3, 2, 5, 4, 3, 2, 3, 4, 2, 3, 1, 2, 3, 2, 1, 2, 3, 2, 3]
const W = 600, H = 200, maxV = 60
const toXY = (arr) => arr.map((v, i) => [(i / (arr.length - 1)) * W, H - (v / maxV) * H])
const pathOf = (pts) => pts.map((p, i) => (i === 0 ? 'M' : 'L') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ')
const viewsPath = pathOf(toXY(viewsData))
const leadsPath = pathOf(toXY(leadsData))
const viewsArea = viewsPath + ' L' + W + ' ' + H + ' L0 ' + H + ' Z'

const yLabels = ['60', '45', '30', '15', '0']
const xLabels = ['Jun 1', 'Jun 6', 'Jun 11', 'Jun 16', 'Jun 21', 'Jun 28']

const downloads = [
  { label: 'Project Brochure', count: '52', width: '100%' },
  { label: 'Payment Plan', count: '28', width: '54%' },
  { label: 'Floor Plans', count: '9', width: '17%' },
]

const funnel = [
  { name: 'Views', right: '1,248', bar: { width: '100%', background: '#F0FDF4', border: '1px solid #BBF7D0', color: '#15803D' }, barLabel: '1,248 views', hasArrow: true },
  { name: 'Leads', right: '48 (3.8%)', bar: { width: '48%', background: '#EEF3FF', border: '1px solid #BFDBFE', color: '#1B4FD8' }, barLabel: '48 leads', hasArrow: true },
  { name: 'Deals', right: '3 (6.25%)', bar: { width: '18%', background: '#FEF9EC', border: '1px solid #F3E2B8', color: '#92400E' }, barLabel: '3 deals', hasArrow: false },
]

const topRealtors = [
  { rank: '1', initials: 'AR', name: 'Ahmed Al-Rashid', role: '🥇 Gold', leads: '14', deals: '2', dealsColor: '#16A34A', conv: '14.3%', lastLead: '2 days ago' },
  { rank: '2', initials: 'FA', name: 'Fatima Hassan', role: '🥇 Gold', leads: '12', deals: '3', dealsColor: '#16A34A', conv: '25%', lastLead: 'Today' },
  { rank: '3', initials: 'BK', name: 'Bilal Khan', role: '🥈 Silver', leads: '8', deals: '1', dealsColor: '#16A34A', conv: '12.5%', lastLead: '5 days ago' },
  { rank: '4', initials: 'SO', name: 'Sara Al-Otaibi', role: '🥈 Silver', leads: '7', deals: '1', dealsColor: '#16A34A', conv: '14.3%', lastLead: '3 days ago' },
  { rank: '5', initials: 'OK', name: 'Omar Khalid', role: '🥉 Bronze', leads: '4', deals: '—', dealsColor: '#9CA3AF', conv: '0%', lastLead: '2 weeks ago' },
]

const unitPerf = [
  { type: '2BR', leads: '24', deals: '3', comm: '3%', width: '100%' },
  { type: '1BR', leads: '12', deals: '0', comm: '3%', width: '50%' },
  { type: 'Studio', leads: '8', deals: '0', comm: '3%', width: '33%' },
  { type: '3BR', leads: '4', deals: '0', comm: '2.5%', width: '17%' },
]

const chip = { height: 34, padding: '0 14px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff' }
const crumb = { fontSize: 13, color: colors.textFaint, cursor: 'pointer' }

export default function ProjectAnalytics() {
  const navigate = useNavigate()
  return (
    <>
      <style>{'@keyframes pa-pulse-dot { 0%,100% { opacity: 1; } 50% { opacity: 0.35; } }'}</style>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={crumb} onClick={() => navigate('/developer/projects')}>My Projects</span>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" strokeWidth={2}><path d="M9 6l6 6-6 6" /></svg>
            <span style={crumb} onClick={() => navigate('/developer/projects')}>Palm Residence</span>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" strokeWidth={2}><path d="M9 6l6 6-6 6" /></svg>
            <span style={{ fontSize: 13, color: colors.ink, fontWeight: 500 }}>Analytics</span>
          </div>
        }
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <span style={chip}><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth={1.8}><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></svg>Last 30 days <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={2}><path d="M6 9l6 6 6-6" /></svg></span>
            <span style={chip}><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth={1.8}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" /></svg>Export CSV</span>
          </div>
        }
      />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg }}>

        {/* PROJECT HEADER */}
        <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 18px', margin: '18px 22px 16px', display: 'flex', gap: 16, alignItems: 'center' }}>
          <div style={{ width: 72, height: 54, borderRadius: 8, background: colors.surfaceMuted, backgroundImage: hatch, flexShrink: 0 }} />
          <div>
            <div style={{ fontSize: 16, fontWeight: 600, letterSpacing: '-0.01em', marginBottom: 3 }}>Palm Residence</div>
            <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}><svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8}><path d="M12 22s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11z" /><circle cx="12" cy="11" r="2" /></svg><span style={{ fontSize: 12, color: colors.textFaint }}>Al Rawdhah, Jeddah</span></div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 4 }}><span style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 999, padding: '2px 8px', display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 5, height: 5, borderRadius: '50%', background: colors.green, animation: 'pa-pulse-dot 1.6s infinite' }} /><span style={{ fontSize: 11, fontWeight: 600, color: colors.greenDark }}>Live</span></span><span style={{ fontSize: 11, color: colors.textFaint }}>Added June 1, 2026</span></div>
          </div>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <span onClick={() => navigate('/project/palm-residence')} style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>View Project ↗</span>
            <span onClick={() => navigate('/developer/leads')} style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>All Leads →</span>
          </div>
        </div>

        <div style={{ padding: '0 22px 22px' }}>

          {/* STAT CARDS */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
            {statCards.map((c, i) => (
              <div key={i} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px' }}>
                <div style={{ width: 30, height: 30, borderRadius: 7, background: colors.greenTint, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}><svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth={1.8}><path d={c.icon} /></svg></div>
                <div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 4 }}>{c.label}</div>
                <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em' }}>{c.value}</div>
                <div style={{ display: 'flex', gap: 4, alignItems: 'center', marginTop: 4 }}><svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke={c.changeColor} strokeWidth={2}><path d={c.changeIcon} /></svg><span style={{ fontSize: 10, color: c.changeColor }}>{c.change}</span></div>
              </div>
            ))}
          </div>

          {/* VIEWS CHART */}
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '16px 18px', marginBottom: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
              <div><div style={{ fontSize: 14, fontWeight: 600 }}>Project Views</div><div style={{ fontSize: 12, color: colors.textFaint, marginTop: 2 }}>Daily views over last 30 days</div></div>
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}><span style={{ display: 'flex', gap: 5, alignItems: 'center' }}><span style={{ width: 6, height: 6, borderRadius: '50%', background: '#16A34A' }} /><span style={{ fontSize: 11, color: colors.textMuted }}>Views</span></span><span style={{ display: 'flex', gap: 5, alignItems: 'center' }}><span style={{ width: 6, height: 6, borderRadius: '50%', background: '#1B4FD8' }} /><span style={{ fontSize: 11, color: colors.textMuted }}>Leads</span></span></div>
            </div>
            <div style={{ display: 'flex' }}>
              <div style={{ width: 36, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', height: 200, paddingRight: 8 }}>
                {yLabels.map((y) => <span key={y} style={{ fontSize: 11, color: colors.textFaint, textAlign: 'right' }}>{y}</span>)}
              </div>
              <div style={{ flex: 1, position: 'relative', height: 200 }}>
                <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}><span style={{ borderTop: `1px solid ${colors.surfaceMuted}` }} /><span style={{ borderTop: `1px solid ${colors.surfaceMuted}` }} /><span style={{ borderTop: `1px solid ${colors.surfaceMuted}` }} /><span style={{ borderTop: `1px solid ${colors.surfaceMuted}` }} /><span style={{ borderTop: `1px solid ${colors.surfaceMuted}` }} /></div>
                <svg viewBox="0 0 600 200" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
                  <defs><linearGradient id="vfill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#16A34A" stopOpacity="0.12" /><stop offset="100%" stopColor="#16A34A" stopOpacity="0" /></linearGradient></defs>
                  <path d={viewsArea} fill="url(#vfill)" />
                  <path d={viewsPath} fill="none" stroke="#16A34A" strokeWidth={2} vectorEffect="non-scaling-stroke" />
                  <path d={leadsPath} fill="none" stroke="#1B4FD8" strokeWidth={1.5} strokeDasharray="4 3" vectorEffect="non-scaling-stroke" />
                </svg>
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, paddingLeft: 36 }}>
              {xLabels.map((x) => <span key={x} style={{ fontSize: 11, color: colors.textFaint }}>{x}</span>)}
            </div>
          </div>

          {/* TWO CHARTS */}
          <div style={{ display: 'flex', gap: 14, marginBottom: 14 }}>
            {/* DOWNLOADS */}
            <div style={{ flex: 1, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '16px 18px' }}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>Document Downloads</div>
              <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 16 }}>Last 30 days · 89 total</div>
              {downloads.map((d, i) => (
                <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 12 }}><span style={{ minWidth: 100, fontSize: 12, color: colors.textMuted }}>{d.label}</span><span style={{ flex: 1, height: 8, background: colors.surfaceMuted, borderRadius: 999, overflow: 'hidden' }}><span style={{ display: 'block', height: '100%', background: '#16A34A', borderRadius: 999, width: d.width }} /></span><span style={{ minWidth: 28, textAlign: 'right', fontSize: 12, fontWeight: 600 }}>{d.count}</span></div>
              ))}
            </div>
            {/* FUNNEL */}
            <div style={{ flex: 1, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '16px 18px' }}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>Lead Conversion Funnel</div>
              <div style={{ fontSize: 12, color: colors.textFaint, marginBottom: 16 }}>Last 30 days</div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'stretch' }}>
                {funnel.map((f, i) => (
                  <React.Fragment key={i}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}><span style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted }}>{f.name}</span><span style={{ fontSize: 12, fontWeight: 600 }}>{f.right}</span></div>
                    <div style={{ height: 32, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', width: f.bar.width, background: f.bar.background, border: f.bar.border, fontSize: 11, color: f.bar.color }}>{f.barLabel}</div>
                    {f.hasArrow && <div style={{ textAlign: 'center', margin: '2px 0' }}><svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" strokeWidth={2}><path d="M6 9l6 6 6-6" /></svg></div>}
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>

          {/* TOP REALTORS */}
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', marginBottom: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '14px 18px', borderBottom: `1px solid ${colors.border}` }}><span style={{ fontSize: 14, fontWeight: 600 }}>Top Realtors by Leads</span><span style={{ fontSize: 12, color: colors.textFaint }}>Last 30 days</span></div>
            <div style={{ background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '8px 16px', display: 'flex', alignItems: 'center' }}><span style={{ width: 30 }} /><span style={{ flex: 2, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Realtor</span><span style={{ flex: 0.8, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Leads</span><span style={{ flex: 0.6, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Deals</span><span style={{ flex: 0.8, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Conv.</span><span style={{ flex: 1, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }}>Last Lead</span></div>
            {topRealtors.map((r, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', padding: '10px 16px', borderBottom: `1px solid ${colors.surfaceMuted}`, minHeight: 52 }}>
                <span style={{ width: 20, height: 20, borderRadius: '50%', background: colors.surfaceMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: colors.textMuted, marginRight: 10, flexShrink: 0 }}>{r.rank}</span>
                <div style={{ flex: 2, display: 'flex', gap: 8, alignItems: 'center' }}><div style={{ width: 26, height: 26, borderRadius: '50%', background: colors.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 700, color: '#fff' }}>{r.initials}</div><div><div style={{ fontSize: 13, fontWeight: 500 }}>{r.name}</div><div style={{ fontSize: 10, color: colors.textFaint }}>{r.role}</div></div></div>
                <span style={{ flex: 0.8, fontSize: 13, fontWeight: 600 }}>{r.leads}</span>
                <span style={{ flex: 0.6, fontSize: 13, color: r.dealsColor }}>{r.deals}</span>
                <span style={{ flex: 0.8, fontSize: 12, color: colors.textMuted }}>{r.conv}</span>
                <span style={{ flex: 1, fontSize: 11, color: colors.textFaint }}>{r.lastLead}</span>
              </div>
            ))}
            <div onClick={() => navigate('/developer/network')} style={{ textAlign: 'center', padding: 12, fontSize: 12, color: colors.greenDark, cursor: 'pointer' }}>View All Realtors →</div>
          </div>

          {/* UNIT TYPE PERFORMANCE */}
          <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '16px 18px' }}>
            <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16 }}>Performance by Unit Type</div>
            {unitPerf.map((u, i) => (
              <div key={i} style={{ display: 'flex', gap: 14, alignItems: 'center', padding: '12px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                <span style={{ background: colors.surfaceMuted, borderRadius: 5, padding: '4px 10px', minWidth: 60, textAlign: 'center', fontSize: 12, fontWeight: 600, color: colors.textMuted }}>{u.type}</span>
                <div style={{ flex: 1 }}><div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}><span style={{ fontSize: 11, color: colors.textMuted }}>{u.leads} leads</span><span style={{ fontSize: 11, color: '#16A34A', fontWeight: 500 }}>{u.deals} deals</span></div><div style={{ height: 6, background: colors.surfaceMuted, borderRadius: 999, overflow: 'hidden' }}><div style={{ height: '100%', background: '#16A34A', borderRadius: 999, width: u.width }} /></div></div>
                <span style={{ textAlign: 'right', minWidth: 80 }}><span style={{ fontSize: 12, fontWeight: 700, color: colors.ink, background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 4, padding: '3px 8px' }}>{u.comm}</span></span>
              </div>
            ))}
          </div>

        </div>
      </div>
    </>
  )
}
