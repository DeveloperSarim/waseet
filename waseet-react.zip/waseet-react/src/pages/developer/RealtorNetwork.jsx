import React, { useState } from 'react'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const data = [
  { id: 1, initials: 'AR', name: 'Ahmed Al-Rashid', emoji: '💎', tier: 'Platinum', location: 'Jeddah, Saudi Arabia', agency: 'Al-Rashid Real Estate', leads: '8', deals: '2', conv: '25%', lastActive: '2 days ago', exp: '5–10 years exp.', platinum: true, perf: [{ project: 'Palm Residence', leads: '5', deals: '1' }, { project: 'Al Noor Tower', leads: '3', deals: '1' }] },
  { id: 2, initials: 'FA', name: 'Fatima Hassan', emoji: '🥇', tier: 'Gold', location: 'Riyadh, Saudi Arabia', agency: 'Independent', leads: '12', deals: '3', conv: '25%', lastActive: 'Today', exp: '3–5 years exp.', platinum: false, perf: [{ project: 'Palm Residence', leads: '7', deals: '2' }, { project: 'Al Noor Tower', leads: '5', deals: '1' }] },
  { id: 3, initials: 'BK', name: 'Bilal Khan', emoji: '🥇', tier: 'Gold', location: 'Karachi, Pakistan', agency: 'Khan Properties', leads: '6', deals: '1', conv: '16.7%', lastActive: '5 days ago', exp: '3–5 years exp.', platinum: false, perf: [{ project: 'Palm Residence', leads: '6', deals: '1' }] },
  { id: 4, initials: 'MH', name: 'Mohammed Hassan', emoji: '🥈', tier: 'Silver', location: 'Dubai, UAE', agency: 'Crown Realty', leads: '4', deals: '0', conv: '0%', lastActive: '1 week ago', exp: '1–3 years exp.', platinum: false, perf: [{ project: 'Palm Residence', leads: '4', deals: '0' }] },
  { id: 5, initials: 'SO', name: 'Sara Al-Otaibi', emoji: '🥈', tier: 'Silver', location: 'Jeddah, Saudi Arabia', agency: 'Independent', leads: '7', deals: '1', conv: '14.3%', lastActive: '3 days ago', exp: '1–3 years exp.', platinum: false, perf: [{ project: 'Palm Residence', leads: '4', deals: '1' }, { project: 'Al Noor Tower', leads: '3', deals: '0' }] },
  { id: 6, initials: 'OK', name: 'Omar Khalid', emoji: '🥉', tier: 'Bronze', location: 'Abu Dhabi, UAE', agency: 'Abu Dhabi Properties', leads: '2', deals: '0', conv: '0%', lastActive: '2 weeks ago', exp: '<1 year exp.', platinum: false, perf: [{ project: 'Palm Residence', leads: '2', deals: '0' }] },
]

const tabDefs = [['All', '24'], ['With Deals', '8'], ['Active', '12'], ['Inactive', '4']]

export default function RealtorNetwork() {
  const [tab, setTab] = useState('All')
  const [openId, setOpenId] = useState(null)
  const [hoverWa, setHoverWa] = useState(null)
  const stop = (e) => e.stopPropagation()

  const cur = data.find((d) => d.id === openId) || data[0]

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>Realtor Network</span>
            <span style={{ fontSize: 13, color: colors.textFaint }}>24 active realtors</span>
          </div>
        }
        actions={<span style={{ fontSize: 12, color: colors.textFaint, textAlign: 'right', maxWidth: 200, lineHeight: 1.4 }}>Realtors who submitted leads on your projects</span>}
      />

      {/* FILTER BAR */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '10px 22px', display: 'flex', gap: 8, alignItems: 'center' }}>
        <div style={{ flex: 1, maxWidth: 280, position: 'relative' }}>
          <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.3-4.3" /></svg>
          <input placeholder="Search by realtor name..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 12, fontFamily: 'inherit' }} />
        </div>
        <div style={{ display: 'flex', border: `1px solid ${colors.border}`, borderRadius: 7, overflow: 'hidden', marginLeft: 12 }}>
          {tabDefs.map(([id, count]) => {
            const on = tab === id
            return (
              <div key={id} onClick={() => setTab(id)} style={{ padding: '0 14px', height: 34, display: 'flex', alignItems: 'center', fontSize: 12, cursor: 'pointer', ...(on ? { background: colors.ink, color: '#fff' } : { background: '#fff', color: colors.textSoft }) }}>{id} ({count})</div>
            )
          })}
        </div>
        <span style={{ marginLeft: 'auto', height: 34, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff' }}>Most leads <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={2}><path d="M6 9l6 6 6-6" /></svg></span>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 14, alignItems: 'start' }}>
          {data.map((r) => (
            <div key={r.id} onClick={() => setOpenId(r.id)} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: 16, cursor: 'pointer' }}>
              <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', marginBottom: 14 }}>
                <div style={{ width: 52, height: 52, borderRadius: '50%', background: colors.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, fontWeight: 700, color: '#fff', flexShrink: 0 }}>{r.initials}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 4 }}>
                    <span style={{ fontSize: 14, fontWeight: 600, letterSpacing: '-0.01em' }}>{r.name}</span>
                    <svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth={2}><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></svg>
                  </div>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 6 }}>
                    <span style={{ fontSize: 14 }}>{r.emoji}</span>
                    <span style={{ fontSize: 12, fontWeight: 500, color: colors.greenDark }}>{r.tier} Realtor</span>
                  </div>
                  <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                    <span style={{ display: 'flex', gap: 4, alignItems: 'center' }}><svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8}><path d="M12 22s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11z" /><circle cx="12" cy="11" r="2" /></svg><span style={{ fontSize: 11, color: colors.textFaint }}>{r.location}</span></span>
                    <span style={{ display: 'flex', gap: 4, alignItems: 'center' }}><svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8}><rect x="2" y="7" width="20" height="14" rx="2" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg><span style={{ fontSize: 11, color: colors.textFaint }}>{r.agency}</span></span>
                  </div>
                </div>
              </div>
              <div style={{ borderTop: `1px solid ${colors.surfaceMuted}`, marginBottom: 12 }} />
              <div style={{ display: 'flex', border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, overflow: 'hidden' }}>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '10px 0', borderRight: `1px solid ${colors.surfaceMuted}` }}><span style={{ fontSize: 15, fontWeight: 700 }}>{r.leads}</span><span style={{ fontSize: 9, color: colors.textFaint, marginTop: 2 }}>Leads</span></div>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '10px 0', borderRight: `1px solid ${colors.surfaceMuted}` }}><span style={{ fontSize: 15, fontWeight: 700 }}>{r.deals}</span><span style={{ fontSize: 9, color: colors.textFaint, marginTop: 2 }}>Deals</span></div>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '10px 0' }}><span style={{ fontSize: 15, fontWeight: 700 }}>{r.conv}</span><span style={{ fontSize: 9, color: colors.textFaint, marginTop: 2 }}>Conv.</span></div>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}><span style={{ fontSize: 11, color: colors.textFaint }}>Last active:</span><span style={{ fontSize: 11, color: colors.textMuted }}>{r.lastActive}</span></div>
              <div style={{ display: 'flex', gap: 8, marginTop: 10, paddingTop: 10, borderTop: `1px solid ${colors.surfaceMuted}` }}>
                {r.platinum ? (
                  <button onClick={stop} style={{ flex: 1, height: 32, background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontFamily: 'inherit', cursor: 'pointer' }}><svg width={14} height={14} viewBox="0 0 24 24" fill="#16A34A"><path d="M12 2a10 10 0 0 0-8.5 15.3L2 22l4.8-1.5A10 10 0 1 0 12 2zm0 2a8 8 0 1 1-4.2 14.8l-.3-.2-2.8.9.9-2.7-.2-.3A8 8 0 0 1 12 4z" /></svg><span style={{ fontSize: 11, fontWeight: 500, color: colors.greenDark }}>WhatsApp</span></button>
                ) : (
                  <span onClick={stop} onMouseEnter={() => setHoverWa(r.id)} onMouseLeave={() => setHoverWa(null)} style={{ flex: 1, position: 'relative' }}>
                    <span style={{ display: 'flex', height: 32, background: colors.surfaceMuted, border: `1px solid ${colors.border}`, borderRadius: 7, alignItems: 'center', justifyContent: 'center', gap: 6, cursor: 'not-allowed' }}><svg width={14} height={14} viewBox="0 0 24 24" fill="#9CA3AF"><path d="M12 2a10 10 0 0 0-8.5 15.3L2 22l4.8-1.5A10 10 0 1 0 12 2z" /></svg><span style={{ fontSize: 11, fontWeight: 500, color: colors.textFaint }}>WhatsApp</span></span>
                    <span style={{ opacity: hoverWa === r.id ? 1 : 0, visibility: hoverWa === r.id ? 'visible' : 'hidden', transition: 'opacity 120ms', position: 'absolute', left: '50%', transform: 'translateX(-50%)', bottom: 38, zIndex: 30, background: colors.ink, color: '#fff', borderRadius: 7, padding: '7px 10px', fontSize: 11, lineHeight: 1.4, width: 190, textAlign: 'center' }}>Direct contact available for Platinum realtors only</span>
                  </span>
                )}
                <button onClick={(e) => { stop(e); setOpenId(r.id) }} style={{ flex: 1, height: 32, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontFamily: 'inherit', cursor: 'pointer' }}><span style={{ fontSize: 11, color: colors.textMuted }}>View Leads</span><svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={2}><path d="M5 12h14M13 6l6 6-6 6" /></svg></button>
              </div>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 16, paddingTop: 16, borderTop: `1px solid ${colors.border}` }}>
          <span style={{ fontSize: 12, color: colors.textSoft }}>Showing 1–12 of 24 realtors</span>
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <span style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textSoft, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>← Prev</span>
            <span style={{ height: 30, minWidth: 30, borderRadius: 6, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', background: colors.ink, color: '#fff' }}>1</span>
            <span style={{ height: 30, minWidth: 30, borderRadius: 6, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', border: `1px solid ${colors.border}`, color: colors.textMuted, background: '#fff' }}>2</span>
            <span style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer', background: '#fff' }}>Next →</span>
          </div>
        </div>
      </div>

      {/* DETAIL PANEL */}
      {openId !== null && (
        <>
          <div onClick={() => setOpenId(null)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.2)', zIndex: 40 }} />
          <div style={{ position: 'fixed', right: 0, top: 56, width: 380, maxWidth: '90vw', height: 'calc(100vh - 56px)', background: '#fff', borderLeft: `1px solid ${colors.border}`, boxShadow: '-4px 0 24px rgba(0,0,0,0.08)', overflowY: 'auto', zIndex: 41 }}>
            <div style={{ padding: '14px 18px', borderBottom: `1px solid ${colors.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><span style={{ fontSize: 14, fontWeight: 600 }}>Realtor details</span><span onClick={() => setOpenId(null)} style={{ fontSize: 20, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ padding: '16px 18px', borderBottom: `1px solid ${colors.border}`, textAlign: 'center' }}>
              <div style={{ width: 64, height: 64, borderRadius: '50%', background: colors.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, fontWeight: 700, color: '#fff', margin: '0 auto 10px' }}>{cur.initials}</div>
              <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 4 }}>{cur.name}</div>
              <div style={{ fontSize: 13, color: colors.greenDark, marginBottom: 8 }}>{cur.emoji} {cur.tier} Realtor</div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}><span style={{ fontSize: 11, color: colors.textFaint }}>{cur.location}</span><span style={{ fontSize: 11, color: colors.textFaint }}>· {cur.exp}</span></div>
            </div>
            <div style={{ padding: '14px 18px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', borderBottom: `1px solid ${colors.border}` }}>
              <div style={{ textAlign: 'center' }}><div style={{ fontSize: 16, fontWeight: 700 }}>{cur.leads}</div><div style={{ fontSize: 10, color: colors.textFaint, marginTop: 2 }}>Leads on your projects</div></div>
              <div style={{ textAlign: 'center' }}><div style={{ fontSize: 16, fontWeight: 700 }}>{cur.deals}</div><div style={{ fontSize: 10, color: colors.textFaint, marginTop: 2 }}>Deals closed</div></div>
              <div style={{ textAlign: 'center' }}><div style={{ fontSize: 16, fontWeight: 700 }}>{cur.conv}</div><div style={{ fontSize: 10, color: colors.textFaint, marginTop: 2 }}>Conversion</div></div>
            </div>
            <div style={{ padding: '14px 18px', borderBottom: `1px solid ${colors.border}` }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 10 }}>Performance on your projects</div>
              <div style={{ display: 'flex', paddingBottom: 6, borderBottom: `1px solid ${colors.surfaceMuted}` }}><span style={{ flex: 2, fontSize: 10, color: colors.textFaint, textTransform: 'uppercase' }}>Project</span><span style={{ flex: 1, textAlign: 'right', fontSize: 10, color: colors.textFaint, textTransform: 'uppercase' }}>Leads</span><span style={{ flex: 1, textAlign: 'right', fontSize: 10, color: colors.textFaint, textTransform: 'uppercase' }}>Deals</span></div>
              {cur.perf.map((p, i) => (
                <div key={i} style={{ display: 'flex', padding: '8px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}><span style={{ flex: 2, fontSize: 13, color: colors.textMuted }}>{p.project}</span><span style={{ flex: 1, textAlign: 'right', fontSize: 13, color: colors.textMuted }}>{p.leads}</span><span style={{ flex: 1, textAlign: 'right', fontSize: 13, color: colors.textMuted }}>{p.deals}</span></div>
              ))}
            </div>
            <div style={{ padding: '14px 18px' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 10 }}>Contact</div>
              {cur.platinum ? (
                <>
                  <button style={{ width: '100%', height: 36, background: '#25D366', border: 'none', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', marginBottom: 8 }}><svg width={16} height={16} viewBox="0 0 24 24" fill="#fff"><path d="M12 2a10 10 0 0 0-8.5 15.3L2 22l4.8-1.5A10 10 0 1 0 12 2z" /></svg>Open WhatsApp Chat</button>
                  <div style={{ fontSize: 12, color: colors.textFaint, textAlign: 'center' }}>+966 50 123 4567</div>
                </>
              ) : (
                <>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8}><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg><span style={{ fontSize: 12, color: colors.textFaint, textAlign: 'center' }}>Direct contact for Platinum realtors only</span></div>
                  <div style={{ width: '100%', height: 36, background: colors.surfaceMuted, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, color: colors.textFaint }}>WhatsApp</div>
                </>
              )}
              <button style={{ width: '100%', height: 36, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', marginTop: 8 }}>View All Their Leads →</button>
            </div>
          </div>
        </>
      )}
    </>
  )
}
