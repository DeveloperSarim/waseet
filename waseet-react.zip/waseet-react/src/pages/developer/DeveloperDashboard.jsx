import React from 'react'
import { useNavigate } from 'react-router-dom'
import { colors, radius } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { Topbar } from '../../components/layout/Topbar'
import { Avatar } from '../../components/ui'

const kpis = [
  { label: 'Live Projects', value: '3', sub: '1 under review', subColor: colors.amber, d: 'M3 21h18M6 21V7l6-4 6 4v14M9 9h2M13 9h2' },
  { label: 'New Leads', value: '12', sub: '+4 this week', subColor: colors.green, d: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M12 11v6M9 14h6' },
  { label: 'Deals Closed', value: '8', sub: 'all time', subColor: colors.textSoft, d: 'M11 17a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M13 7a5 5 0 0 0-7 0L3 10a5 5 0 0 0 7 7l1-1' },
  { label: 'Commission Paid', value: 'SAR 81k', sub: 'to Waseet total', subColor: colors.textSoft, d: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 7v10M9.5 9.5c0-1 1.1-1.5 2.5-1.5s2.5.5 2.5 1.5-1.1 1.5-2.5 1.5-2.5.5-2.5 1.5 1.1 1.5 2.5 1.5 2.5-.5 2.5-1.5' },
  { label: 'Active Realtors', value: '24', sub: 'submitted leads', subColor: colors.textSoft, d: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8' },
]

const leadTone = {
  New: { bg: '#EEF3FF', color: '#1B4FD8', bd: '#BFDBFE' },
  Contacted: { bg: '#F5F3FF', color: '#5B5BD6', bd: '#DDD6FE' },
  'Site Visit': { bg: '#EEF3FF', color: '#3730A3', bd: '#C7D2FE' },
}
const leads = [
  { project: 'Palm Residence · 2BR', client: 'Khalid M.', phone: '+966 ***** 4567', realtor: 'Ahmed 🥇', rInit: 'AR', time: '2 hrs ago', status: 'New' },
  { project: 'Palm Residence · 1BR', client: 'Sara A.', phone: '+966 ***** 8901', realtor: 'Fatima 🥈', rInit: 'FA', time: 'Yesterday', status: 'Contacted' },
  { project: 'Al Noor Tower · 3BR', client: 'Omar K.', phone: '+92 ***** 5678', realtor: 'Bilal 🥉', rInit: 'BK', time: 'Jun 25', status: 'Site Visit' },
]

export default function DeveloperDashboard() {
  const navigate = useNavigate()
  return (
    <>
      <Topbar title="Dashboard" notifications={1} avatar={<Avatar initials="AF" size={32} background={colors.surfaceMuted} color={colors.textMuted} style={{ border: `1px solid ${colors.border}` }} />} />
      <div style={{ flex: 1, overflowY: 'auto', padding: '18px 22px' }}>
        {/* Overdue alert */}
        <div style={{ background: '#fff', border: `1px solid ${colors.redTintBorder}`, borderLeft: `3px solid ${colors.red}`, borderRadius: 8, padding: '10px 14px', marginBottom: 10, display: 'flex', gap: 10, alignItems: 'center' }}>
          <Icon name="alertCircle" size={16} color={colors.red} strokeWidth={1.8} />
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#991B1B' }}>Commission overdue — SAR 27,000</div>
            <div style={{ fontSize: 12, color: colors.red, marginTop: 2 }}>Unpaid for 8 days · Palm Residence deal</div>
          </div>
          <span style={{ fontSize: 12, color: colors.red, fontWeight: 500, marginLeft: 'auto', border: `1px solid ${colors.redTintBorder}`, background: colors.redTint, borderRadius: 6, padding: '4px 10px', cursor: 'pointer', whiteSpace: 'nowrap' }}>Pay Now →</span>
        </div>

        {/* Review banner */}
        <div style={{ background: '#fff', border: `1px solid ${colors.amberTintBorder}`, borderLeft: `3px solid ${colors.amber}`, borderRadius: 8, padding: '10px 14px', marginBottom: 14, display: 'flex', gap: 10, alignItems: 'center' }}>
          <Icon name="clock" size={16} color={colors.amber} strokeWidth={1.8} />
          <span style={{ fontSize: 13, color: colors.textMuted }}>Palm Residence is under admin review</span>
          <span style={{ fontSize: 11, color: colors.textFaint, marginLeft: 'auto' }}>Expected within 24 hours</span>
        </div>

        {/* KPIs */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 10, marginBottom: 14 }}>
          {kpis.map((k) => (
            <div key={k.label} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '12px 14px' }}>
              <div style={{ width: 30, height: 30, background: colors.greenTint, borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}>
                <svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round"><path d={k.d} /></svg>
              </div>
              <div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 4 }}>{k.label}</div>
              <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em' }}>{k.value}</div>
              <div style={{ fontSize: 10, color: k.subColor, marginTop: 3 }}>{k.sub}</div>
            </div>
          ))}
        </div>

        {/* Recent leads table */}
        <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderBottom: `1px solid ${colors.border}` }}>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Recent leads</span>
            <span onClick={() => navigate('/developer/leads')} style={{ fontSize: 12, color: colors.greenDark, cursor: 'pointer' }}>View all →</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1.6fr 1.2fr 0.9fr 0.9fr', background: colors.bg, borderBottom: `1px solid ${colors.border}`, fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            <span style={{ padding: '8px 16px' }}>Project</span><span style={{ padding: '8px 8px' }}>Client</span><span style={{ padding: '8px 8px' }}>Realtor</span><span style={{ padding: '8px 8px' }}>Time</span><span style={{ padding: '8px 8px' }}>Status</span>
          </div>
          {leads.map((l, i) => {
            const t = leadTone[l.status]
            return (
              <div key={i} style={{ display: 'grid', gridTemplateColumns: '1.5fr 1.6fr 1.2fr 0.9fr 0.9fr', borderBottom: `1px solid ${colors.surfaceMuted}`, alignItems: 'center' }}>
                <span style={{ padding: '10px 16px', fontSize: 13, fontWeight: 500 }}>{l.project}</span>
                <span style={{ padding: '10px 8px', fontSize: 13, color: colors.textMuted }}>{l.client} <span style={{ fontSize: 11, color: colors.textFaint }}>{l.phone}</span></span>
                <span style={{ padding: '10px 8px', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ width: 22, height: 22, borderRadius: '50%', background: colors.surfaceMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 600, color: colors.textMuted }}>{l.rInit}</span>
                  <span style={{ fontSize: 12, color: colors.textMuted }}>{l.realtor}</span>
                </span>
                <span style={{ padding: '10px 8px', fontSize: 12, color: colors.textFaint }}>{l.time}</span>
                <span style={{ padding: '10px 8px' }}><span style={{ background: t.bg, color: t.color, border: `1px solid ${t.bd}`, borderRadius: 999, padding: '2px 8px', fontSize: 10, fontWeight: 600 }}>{l.status}</span></span>
              </div>
            )
          })}
        </div>

        {/* Quick actions */}
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <button onClick={() => navigate('/developer/projects/new')} style={{ height: 36, padding: '0 16px', background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icon name="plus" size={14} color="#fff" strokeWidth={2} />Add New Project
          </button>
          <button onClick={() => navigate('/developer/leads')} style={{ height: 36, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, fontWeight: 500, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>View All Leads</button>
          <button style={{ height: 36, padding: '0 14px', background: colors.redTint, border: `1px solid ${colors.redTintBorder}`, borderRadius: 8, fontSize: 13, fontWeight: 500, color: colors.red, fontFamily: 'inherit', cursor: 'pointer' }}>Pending Payments</button>
        </div>
      </div>
    </>
  )
}
