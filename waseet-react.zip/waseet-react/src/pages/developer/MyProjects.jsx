import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { Topbar } from '../../components/layout/Topbar'
import { Avatar } from '../../components/ui'

const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 11px)'
const tabDefs = [['All', 4], ['Live', 2], ['Under Review', 1], ['Draft', 1], ['Paused', 0]]

const liveUnits = [
  { type: 'Studio', comm: '3%' }, { type: '1BR', comm: '3%' }, { type: '2BR', comm: '3%' }, { type: '3BR', comm: '2.5%' },
]
const liveStats = [['124', 'Views'], ['48', 'Leads'], ['3', 'Deals'], ['SAR 81k', 'Commission']]

function TabBar({ active, onChange }) {
  return (
    <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '0 22px', display: 'flex' }}>
      {tabDefs.map(([label, count]) => {
        const on = active === label
        return (
          <div key={label} onClick={() => onChange(label)} style={{ padding: '11px 16px', fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', borderBottom: `2px solid ${on ? colors.ink : 'transparent'}`, color: on ? colors.ink : colors.textSoft, fontWeight: on ? 600 : 400, whiteSpace: 'nowrap' }}>
            {label}
            <span style={{ borderRadius: 999, padding: '1px 6px', fontSize: 10, fontWeight: 600, marginLeft: 5, background: on ? colors.ink : colors.surfaceMuted, color: on ? '#fff' : colors.textSoft }}>{count}</span>
          </div>
        )
      })}
    </div>
  )
}

export default function MyProjects() {
  const navigate = useNavigate()
  const [tab, setTab] = useState('All')

  const showLive = tab === 'All' || tab === 'Live'
  const showReview = tab === 'All' || tab === 'Under Review'
  const showDraft = tab === 'All' || tab === 'Draft'

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>My Projects</span>
            <span style={{ fontSize: 13, color: colors.textFaint }}>4 total</span>
          </div>
        }
        actions={
          <button onClick={() => navigate('/developer/projects/new')} style={{ height: 36, padding: '0 16px', background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icon name="plus" size={14} color="#fff" strokeWidth={2} />Add New Project
          </button>
        }
      />
      <TabBar active={tab} onChange={setTab} />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 14, alignItems: 'start' }}>
          {/* LIVE */}
          {showLive && (
            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden' }}>
              <div style={{ height: 160, background: colors.surfaceMuted, backgroundImage: hatch, position: 'relative' }}>
                <div style={{ position: 'absolute', top: 12, left: 12, background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 999, padding: '3px 10px', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ width: 6, height: 6, borderRadius: '50%', background: colors.green, animation: 'ps-pulse 1.6s infinite' }} />
                  <span style={{ fontSize: 11, fontWeight: 600, color: colors.greenDark }}>Live</span>
                </div>
                <div style={{ position: 'absolute', top: 12, right: 12, display: 'flex', gap: 8 }}>
                  {[['eye', '124 views'], ['fileText', '48 leads']].map(([ic, t]) => (
                    <span key={t} style={{ background: 'rgba(0,0,0,0.5)', borderRadius: 999, padding: '3px 8px', display: 'flex', gap: 4, alignItems: 'center' }}>
                      <Icon name={ic} size={12} color="#fff" strokeWidth={1.8} /><span style={{ fontSize: 10, color: '#fff' }}>{t}</span>
                    </span>
                  ))}
                </div>
              </div>
              <div style={{ padding: '14px 16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 3 }}>Palm Residence</div>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <Icon name="mapPin" size={12} color={colors.textFaint} strokeWidth={1.8} />
                      <span style={{ fontSize: 12, color: colors.textFaint }}>Al Rawdhah, Jeddah</span>
                    </div>
                  </div>
                  <span style={{ fontSize: 11, color: colors.textFaint }}>Added June 1, 2026</span>
                </div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
                  {liveUnits.map((u) => (
                    <span key={u.type} style={{ background: colors.surfaceMuted, borderRadius: 5, padding: '3px 8px', display: 'flex', gap: 5, alignItems: 'center' }}>
                      <span style={{ fontSize: 11, fontWeight: 500, color: colors.textMuted }}>{u.type}</span>
                      <span style={{ background: colors.greenTint, borderRadius: 3, padding: '1px 5px', fontSize: 10, fontWeight: 600, color: colors.greenDark }}>{u.comm}</span>
                    </span>
                  ))}
                </div>
                <div style={{ display: 'flex', border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, overflow: 'hidden' }}>
                  {liveStats.map(([v, l], i) => (
                    <div key={l} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '10px 0', borderRight: i < 3 ? `1px solid ${colors.surfaceMuted}` : 'none' }}>
                      <div style={{ fontSize: 16, fontWeight: 700 }}>{v}</div>
                      <div style={{ fontSize: 10, color: colors.textFaint, marginTop: 2 }}>{l}</div>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 12, paddingTop: 12, borderTop: `1px solid ${colors.surfaceMuted}` }}>
                  <button onClick={() => navigate('/developer/leads')} style={{ height: 32, padding: '0 12px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 11, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>View Leads →</button>
                  <button onClick={() => navigate('/developer/analytics')} style={{ height: 32, padding: '0 12px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Analytics</button>
                  <button onClick={() => navigate('/developer/projects/palm-residence/edit')} style={{ height: 32, padding: '0 12px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Edit</button>
                </div>
              </div>
            </div>
          )}

          {/* UNDER REVIEW */}
          {showReview && (
            <div style={{ background: '#fff', border: `1px solid ${colors.amberTintBorder}`, borderLeft: `3px solid ${colors.amber}`, borderRadius: 12, overflow: 'hidden' }}>
              <div style={{ height: 160, background: colors.surfaceMuted, backgroundImage: hatch, position: 'relative' }}>
                <div style={{ position: 'absolute', top: 12, left: 12, background: colors.amberTint, border: `1px solid ${colors.amberTintBorder}`, borderRadius: 999, padding: '3px 10px', display: 'flex', alignItems: 'center', gap: 5 }}>
                  <Icon name="clock" size={11} color={colors.amber} strokeWidth={2} />
                  <span style={{ fontSize: 11, fontWeight: 600, color: colors.amberText }}>Under Review</span>
                </div>
              </div>
              <div style={{ padding: '14px 16px' }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>Al Noor Tower</div>
                <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 2 }}>Al Hamra, Riyadh</div>
                <div style={{ background: colors.amberTint, border: `1px solid ${colors.amberTintBorder}`, borderRadius: 8, padding: '10px 12px', margin: '10px 0' }}>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 4 }}>
                    <Icon name="clock" size={14} color={colors.amber} strokeWidth={1.8} />
                    <span style={{ fontSize: 12, color: colors.amberText }}>Submitted for review · June 27, 2026</span>
                  </div>
                  <div style={{ fontSize: 11, color: colors.amberText, marginBottom: 10 }}>Our admin team reviews within 24 hours.</div>
                  <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                    {[['Submitted', colors.green], ['Review', colors.amber], ['Live', colors.borderStrong]].map(([label, dot], i) => (
                      <div key={label} style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, width: 64 }}>
                          <span style={{ width: 8, height: 8, borderRadius: '50%', background: dot }} />
                          <span style={{ fontSize: 10, color: colors.textFaint, whiteSpace: 'nowrap' }}>{label}</span>
                        </div>
                        {i < 2 && <span style={{ width: 22, height: 2, background: colors.border, marginBottom: 12 }} />}
                      </div>
                    ))}
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button style={{ height: 32, padding: '0 12px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Edit Draft</button>
                  <button style={{ height: 32, padding: '0 12px', background: 'transparent', border: 'none', fontSize: 11, color: colors.textFaint, fontFamily: 'inherit', cursor: 'pointer' }}>Cancel Submission</button>
                </div>
              </div>
            </div>
          )}

          {/* DRAFT */}
          {showDraft && (
            <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden' }}>
              <div style={{ height: 160, background: colors.surfaceMuted, backgroundImage: hatch, position: 'relative' }}>
                <div style={{ position: 'absolute', top: 12, left: 12, background: colors.surfaceMuted, border: `1px solid ${colors.border}`, borderRadius: 999, padding: '3px 10px' }}>
                  <span style={{ fontSize: 11, fontWeight: 500, color: colors.textSoft }}>Draft</span>
                </div>
              </div>
              <div style={{ padding: '14px 16px' }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>Marina Heights</div>
                <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 2 }}>Dubai Marina, UAE</div>
                <div style={{ margin: '10px 0' }}>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 6 }}>Completion:</div>
                  <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                    {[['Basics', colors.green], ['Units', colors.green], ['Media', colors.amber], ['Docs', colors.borderStrong], ['Publish', colors.borderStrong]].map(([label, dot], i) => (
                      <div key={label} style={{ display: 'flex', alignItems: 'center' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, width: 56 }}>
                          <span style={{ width: 8, height: 8, borderRadius: '50%', background: dot }} />
                          <span style={{ fontSize: 9, color: colors.textFaint }}>{label}</span>
                        </div>
                        {i < 4 && <span style={{ width: 16, height: 2, background: colors.border, marginBottom: 12 }} />}
                      </div>
                    ))}
                  </div>
                  <div style={{ fontSize: 11, color: colors.amber, marginTop: 8 }}>Step 3 of 5 — Continue adding content</div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => navigate('/developer/projects/new')} style={{ height: 32, padding: '0 12px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 11, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Continue Editing →</button>
                  <button style={{ height: 32, padding: '0 12px', background: 'transparent', border: 'none', fontSize: 11, color: colors.red, fontFamily: 'inherit', cursor: 'pointer', borderRadius: 7 }}>Delete Draft</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  )
}
