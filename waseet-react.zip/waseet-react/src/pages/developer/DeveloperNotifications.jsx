import React, { useState } from 'react'
import { colors } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { Topbar } from '../../components/layout/Topbar'
import { PortalMain } from '../../components/layout/PortalLayout'
import { Avatar } from '../../components/ui'

const groups = [
  {
    label: 'Today',
    items: [
      { icon: 'user', tone: 'blue', title: 'New lead on Palm Residence', sub: 'Ahmed Al-Rashid submitted a 2BR lead for Khalid M.', time: '2h', unread: true },
      { icon: 'dollar', tone: 'red', title: 'Commission payment due', sub: 'SAR 27,000 owed to Ahmed Al-Rashid — overdue 8 days.', time: '5h', unread: true },
    ],
  },
  {
    label: 'Earlier this week',
    items: [
      { icon: 'checkCircle', tone: 'green', title: 'Palm Residence approved', sub: 'Your project is now live on the marketplace.', time: 'Jun 27', unread: false },
      { icon: 'clock', tone: 'amber', title: 'Al Noor Tower under review', sub: 'Admin team is reviewing your submission.', time: 'Jun 27', unread: false },
      { icon: 'users', tone: 'green', title: 'New realtor in your network', sub: 'Noura Al-Mutairi 💎 submitted her first lead.', time: 'Jun 24', unread: false },
    ],
  },
]

const toneMap = {
  green: { bg: colors.greenTint, color: colors.green },
  blue: { bg: colors.blueTint, color: colors.blue },
  amber: { bg: colors.amberTint, color: colors.amber },
  red: { bg: colors.redTint, color: colors.red },
}

export default function DeveloperNotifications() {
  const [readAll, setReadAll] = useState(false)
  return (
    <>
      <Topbar
        title="Notifications"
        notifications={1}
        avatar={<Avatar initials="AF" size={30} background={colors.surfaceMuted} color={colors.textMuted} style={{ border: `1px solid ${colors.border}` }} />}
        actions={<button onClick={() => setReadAll(true)} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, fontWeight: 500, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Mark all read</button>}
      />
      <PortalMain maxWidth={720} padding="20px 22px">
        {groups.map((g) => (
          <div key={g.label} style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>{g.label}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {g.items.map((n, i) => {
                const t = toneMap[n.tone]
                const unread = n.unread && !readAll
                return (
                  <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '13px 15px' }}>
                    <span style={{ width: 34, height: 34, minWidth: 34, borderRadius: 9, background: t.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Icon name={n.icon} size={17} color={t.color} strokeWidth={1.8} />
                    </span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{n.title}</div>
                      <div style={{ fontSize: 12, color: colors.textSoft, marginTop: 2 }}>{n.sub}</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
                      <span style={{ fontSize: 11, color: colors.textFaint }}>{n.time}</span>
                      {unread && <span style={{ width: 8, height: 8, borderRadius: '50%', background: colors.green }} />}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        ))}
      </PortalMain>
    </>
  )
}
