import React, { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Topbar } from '../../components/layout/Topbar'

const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 8px)'

const summaryCards = [
  { icon: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 7v10', label: 'Total Paid', value: 'SAR 81,450', sub: 'all time to Waseet' },
  { icon: 'M8 11l3 3 5-6M20 6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2z', label: 'Deals Closed', value: '8', sub: 'generating commissions' },
  { icon: 'M3 3v18h18M7 16l4-6 4 3 5-7', label: 'Avg. Commission', value: 'SAR 10,181', sub: 'per deal' },
  { icon: 'M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z', label: 'Last Payment', value: 'June 27', sub: 'SAR 27,000 — Palm Residence' },
]

const rows = [
  { deal: '#WS-2026-042', dealDate: 'Jun 27', project: 'Palm Residence', unit: 'Unit 4B · 2BR', realtorInit: 'AR', realtor: 'Ahmed 🥇', agency: 'Al-Rashid Real Estate', salePrice: 'SAR 900,000', commission: 'SAR 27,000', commPct: '(3%)', fee: 'SAR 4,050', paid: 'Jun 27', ref: 'REF-29112' },
  { deal: '#WS-2026-041', dealDate: 'Jun 10', project: 'Al Noor Tower', unit: 'Unit 2A · 1BR', realtorInit: 'FA', realtor: 'Fatima 🥈', agency: 'Independent', salePrice: 'SAR 650,000', commission: 'SAR 19,500', commPct: '(3%)', fee: 'SAR 2,925', paid: 'Jun 10', ref: 'REF-29089' },
  { deal: '#WS-2026-040', dealDate: 'Jun 2', project: 'Marina Heights', unit: 'Office Unit 8', realtorInit: 'BK', realtor: 'Bilal 🥉', agency: 'Khan Properties', salePrice: 'AED 980,000', commission: 'AED 24,500', commPct: '(2.5%)', fee: 'AED 3,675', paid: 'Jun 2', ref: 'REF-29056' },
  { deal: '#WS-2026-039', dealDate: 'May 28', project: 'Palm Residence', unit: 'Unit 2B · Studio', realtorInit: 'SO', realtor: 'Sara 🥈', agency: 'Independent', salePrice: 'SAR 460,000', commission: 'SAR 13,800', commPct: '(3%)', fee: 'SAR 2,070', paid: 'May 28', ref: 'REF-28934' },
  { deal: '#WS-2026-038', dealDate: 'May 15', project: 'Green Valley', unit: 'Villa Unit 3', realtorInit: 'OK', realtor: 'Omar 🥉', agency: 'ADP', salePrice: 'PKR 65M', commission: 'PKR 2.275M', commPct: '(3.5%)', fee: 'PKR 341k', paid: 'May 15', ref: 'REF-28891' },
  { deal: '#WS-2026-037', dealDate: 'May 3', project: 'Palm Residence', unit: 'Unit 1A · 1BR', realtorInit: 'MH', realtor: 'Mohammed 🥉', agency: 'Crown Realty', salePrice: 'SAR 680,000', commission: 'SAR 20,400', commPct: '(3%)', fee: 'SAR 3,060', paid: 'May 3', ref: 'REF-28845' },
  { deal: '#WS-2026-036', dealDate: 'Apr 22', project: 'Al Noor Tower', unit: 'Unit 5C · 2BR', realtorInit: 'AR', realtor: 'Ahmed 🥇', agency: 'Al-Rashid Real Estate', salePrice: 'SAR 920,000', commission: 'SAR 27,600', commPct: '(3%)', fee: 'SAR 4,140', paid: 'Apr 22', ref: 'REF-28790' },
  { deal: '#WS-2026-035', dealDate: 'Apr 8', project: 'Palm Residence', unit: 'Unit 3D · Studio', realtorInit: 'FA', realtor: 'Fatima 🥈', agency: 'Independent', salePrice: 'SAR 445,000', commission: 'SAR 13,350', commPct: '(3%)', fee: 'SAR 2,003', paid: 'Apr 8', ref: 'REF-28712' },
]

const chip = { height: 34, padding: '0 12px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff' }
const th = { fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase' }

export default function CommissionHistory() {
  const navigate = useNavigate()
  const [exportState, setExportState] = useState('idle')
  const [toast, setToast] = useState(false)
  const [proofOpen, setProofOpen] = useState(false)
  const timers = useRef([])
  const stop = (e) => e.stopPropagation()

  const doExport = () => {
    if (exportState !== 'idle') return
    setExportState('loading')
    timers.current.push(setTimeout(() => { setExportState('done'); setToast(true) }, 1000))
    timers.current.push(setTimeout(() => { setExportState('idle'); setToast(false) }, 4500))
  }

  const es = exportState
  const exportLabel = es === 'loading' ? 'Preparing…' : es === 'done' ? 'Downloaded ✓' : 'Export CSV'
  const exportColor = es === 'done' ? colors.greenDark : colors.textMuted
  const exportBg = es === 'done' ? colors.greenTint : '#fff'
  const exportBorder = es === 'done' ? colors.greenTintBorder : colors.border

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 13, color: colors.textFaint, cursor: 'pointer' }} onClick={() => navigate('/developer/commissions')}>Commissions</span>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" strokeWidth={2}><path d="M9 6l6 6-6 6" /></svg>
            <span style={{ fontSize: 13, color: colors.ink, fontWeight: 500 }}>History</span>
          </div>
        }
        actions={
          <button onClick={doExport} style={{ height: 34, padding: '0 14px', background: exportBg, border: `1px solid ${exportBorder}`, borderRadius: 7, fontSize: 12, color: exportColor, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={exportColor} strokeWidth={1.8}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" /></svg>{exportLabel}</button>
        }
      />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg }}>
        {/* SUMMARY CARDS */}
        <div style={{ padding: '18px 22px 0', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          {summaryCards.map((c, i) => (
            <div key={i} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px' }}>
              <div style={{ width: 30, height: 30, borderRadius: 7, background: colors.greenTint, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}><svg width={15} height={15} viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth={1.8}><path d={c.icon} /></svg></div>
              <div style={{ fontSize: 10, color: colors.textFaint, marginBottom: 4 }}>{c.label}</div>
              <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em' }}>{c.value}</div>
              <div style={{ fontSize: 10, color: colors.textSoft, marginTop: 3 }}>{c.sub}</div>
            </div>
          ))}
        </div>

        {/* FILTER BAR */}
        <div style={{ background: '#fff', borderTop: `1px solid ${colors.border}`, borderBottom: `1px solid ${colors.border}`, padding: '10px 22px', display: 'flex', gap: 8, alignItems: 'center', marginTop: 16 }}>
          <span style={chip}>All projects <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={2}><path d="M6 9l6 6 6-6" /></svg></span>
          <span style={chip}>All realtors <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={2}><path d="M6 9l6 6 6-6" /></svg></span>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8}><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></svg><input placeholder="From" style={{ height: 34, width: 110, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 12, fontFamily: 'inherit' }} /><span style={{ fontSize: 12, color: colors.textFaint }}>to</span><input placeholder="To" style={{ height: 34, width: 110, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 12, fontFamily: 'inherit' }} /></div>
          <div style={{ flex: 1, maxWidth: 220, marginLeft: 'auto', position: 'relative' }}><svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.3-4.3" /></svg><input placeholder="Search by deal ID..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 12, fontFamily: 'inherit' }} /></div>
        </div>

        {/* TABLE */}
        <div style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, overflow: 'hidden', margin: '16px 22px' }}>
          <div style={{ background: colors.bg, borderBottom: `1px solid ${colors.border}`, padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ flex: 0.8, ...th }}>Deal</span>
            <span style={{ flex: 1.8, ...th }}>Project · Unit</span>
            <span style={{ flex: 1.2, ...th }}>Realtor</span>
            <span style={{ flex: 1, textAlign: 'right', ...th }}>Sale Price</span>
            <span style={{ flex: 1, textAlign: 'right', ...th }}>Commission</span>
            <span style={{ flex: 1, textAlign: 'right', ...th }}>Platform Fee</span>
            <span style={{ flex: 0.8, ...th }}>Paid</span>
            <span style={{ flex: 1, ...th }}>Reference</span>
            <span style={{ flex: 0.6, textAlign: 'center', ...th }}>Proof</span>
          </div>
          {rows.map((r, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, borderBottom: `1px solid ${colors.surfaceMuted}`, padding: '12px 16px', minHeight: 56 }}>
              <div style={{ flex: 0.8 }}><div style={{ fontSize: 11, fontWeight: 600, fontFamily: 'monospace' }}>{r.deal}</div><div style={{ fontSize: 10, color: colors.textFaint, marginTop: 2 }}>{r.dealDate}</div></div>
              <div style={{ flex: 1.8, display: 'flex', gap: 8, alignItems: 'center' }}><div style={{ width: 36, height: 26, borderRadius: 5, background: colors.surfaceMuted, backgroundImage: hatch, flexShrink: 0 }} /><div><div style={{ fontSize: 13, fontWeight: 500 }}>{r.project}</div><div style={{ fontSize: 10, color: colors.textFaint }}>{r.unit}</div></div></div>
              <div style={{ flex: 1.2, display: 'flex', gap: 6, alignItems: 'center' }}><span style={{ width: 24, height: 24, borderRadius: '50%', background: colors.surfaceMuted, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 600, color: colors.textMuted, flexShrink: 0 }}>{r.realtorInit}</span><div><div style={{ fontSize: 12, color: colors.textMuted }}>{r.realtor}</div><div style={{ fontSize: 10, color: colors.textFaint }}>{r.agency}</div></div></div>
              <div style={{ flex: 1, textAlign: 'right', fontSize: 13, color: colors.textMuted }}>{r.salePrice}</div>
              <div style={{ flex: 1, textAlign: 'right' }}><div style={{ fontSize: 13, fontWeight: 600 }}>{r.commission}</div><div style={{ fontSize: 10, color: colors.textFaint, marginTop: 1 }}>{r.commPct}</div></div>
              <div style={{ flex: 1, textAlign: 'right' }}><div style={{ fontSize: 12, color: colors.textFaint }}>{r.fee}</div><div style={{ fontSize: 10, color: colors.textFaint, marginTop: 1 }}>(15%)</div></div>
              <div style={{ flex: 0.8 }}><div style={{ fontSize: 12, color: colors.textMuted }}>{r.paid}</div><div style={{ fontSize: 10, color: colors.green }}>Verified</div></div>
              <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 4 }}><span style={{ fontSize: 11, color: colors.textMuted, fontFamily: 'monospace' }}>{r.ref}</span><svg width={13} height={13} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.8} style={{ cursor: 'pointer' }}><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg></div>
              <div style={{ flex: 0.6, textAlign: 'center' }}><span onClick={() => setProofOpen(true)} style={{ cursor: 'pointer', display: 'inline-flex', flexDirection: 'column', alignItems: 'center' }}><svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={1.7}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6" /></svg><span style={{ fontSize: 10, color: colors.greenDark, marginTop: 1 }}>View</span></span></div>
            </div>
          ))}
          {/* TOTALS */}
          <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ flex: 0.8, fontSize: 12, color: colors.textFaint }}>8 deals total</span>
            <span style={{ flex: 1.8 }} />
            <span style={{ flex: 1.2 }} />
            <div style={{ flex: 1, textAlign: 'right' }}><div style={{ fontSize: 13, fontWeight: 600 }}>SAR 6.1M+</div><div style={{ fontSize: 10, color: colors.textFaint }}>Total sales</div></div>
            <div style={{ flex: 1, textAlign: 'right' }}><div style={{ fontSize: 13, fontWeight: 700 }}>SAR 173,150</div><div style={{ fontSize: 10, color: colors.textFaint }}>Total commission</div></div>
            <div style={{ flex: 1, textAlign: 'right' }}><div style={{ fontSize: 12, color: colors.textFaint }}>SAR 25,973</div><div style={{ fontSize: 10, color: colors.textFaint }}>Platform total</div></div>
            <span style={{ flex: 0.8 }} />
            <span style={{ flex: 1 }} />
            <span style={{ flex: 0.6 }} />
          </div>
        </div>

        {/* PAGINATION */}
        <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '14px 22px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: colors.textSoft }}>Showing 1–8 of 8 deals</span>
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <span style={{ height: 30, minWidth: 30, borderRadius: 6, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', background: colors.ink, color: '#fff' }}>1</span>
          </div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}><span style={{ fontSize: 12, color: colors.textSoft }}>Per page:</span><span style={{ height: 34, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', background: '#fff' }}>10 <svg width={12} height={12} viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth={2}><path d="M6 9l6 6 6-6" /></svg></span></div>
        </div>
      </div>

      {/* PROOF MODAL */}
      {proofOpen && (
        <div onClick={() => setProofOpen(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div onClick={stop} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, maxWidth: 560, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)', overflow: 'hidden' }}>
            <div style={{ padding: '14px 18px', borderBottom: `1px solid ${colors.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><div><div style={{ fontSize: 14, fontWeight: 600 }}>Payment proof — WS-2026-042</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>Uploaded June 27 · 2.1MB</div></div><div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><span style={{ height: 30, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 11, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer' }}>Download ↓</span><span onClick={() => setProofOpen(false)} style={{ fontSize: 20, color: colors.textFaint, cursor: 'pointer' }}>×</span></div></div>
            <div style={{ height: 360, background: colors.surfaceMuted, backgroundImage: 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 9px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><span style={{ fontSize: 13, color: colors.textFaint }}>Bank transfer receipt</span></div>
            <div style={{ padding: '10px 16px', borderTop: `1px solid ${colors.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><div style={{ display: 'flex', gap: 6 }}><span style={{ height: 28, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 5, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer' }}>← Prev</span><span style={{ height: 28, padding: '0 10px', border: `1px solid ${colors.border}`, borderRadius: 5, fontSize: 12, color: colors.textMuted, display: 'flex', alignItems: 'center', cursor: 'pointer' }}>Next →</span></div><span style={{ fontSize: 12, color: colors.textFaint }}>Page 1 of 1</span><div style={{ display: 'flex', gap: 6 }}><span style={{ width: 28, height: 28, border: `1px solid ${colors.border}`, borderRadius: 5, fontSize: 14, color: colors.textMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>−</span><span style={{ width: 28, height: 28, border: `1px solid ${colors.border}`, borderRadius: 5, fontSize: 14, color: colors.textMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>+</span></div></div>
          </div>
        </div>
      )}

      {/* EXPORT TOAST */}
      {toast && (
        <div style={{ position: 'fixed', right: 22, bottom: 22, zIndex: 60, background: '#fff', border: `1px solid ${colors.greenTintBorder}`, borderRadius: 10, padding: '12px 14px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', display: 'flex', gap: 10, alignItems: 'center' }}>
          <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth={2}><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></svg>
          <span style={{ fontSize: 13, fontWeight: 500 }}>waseet_commission_history.csv downloaded · 8 deals</span>
        </div>
      )}
    </>
  )
}
