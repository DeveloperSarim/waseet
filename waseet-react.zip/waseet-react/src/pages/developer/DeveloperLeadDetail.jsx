import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { Topbar } from '../../components/layout/Topbar'
import { Avatar } from '../../components/ui'

const hatch = 'repeating-linear-gradient(45deg, #E9EBEE 0, #E9EBEE 1px, transparent 1px, transparent 8px)'
const card = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 18px', marginBottom: 12 }
const sectionLabel = { fontSize: 9, fontWeight: 700, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 14 }
const rLabel = { fontSize: 10, fontWeight: 600, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }

const clientFields = [
  ['Email', 'k.ansari@gmail.com'],
  ['Budget', 'SAR 850,000 – 950,000'],
  ['Unit Interest', '2BR'],
  ['Lead ID', '#WS-2026-042'],
  ['Submitted', 'June 24, 2026 · 10:32 AM'],
  ['Last Updated', 'June 27, 2026 · 3:15 PM'],
]
const devNotes = [
  { time: 'Jun 26 · 11:32 AM', text: 'Client visited site, very interested in 2BR. Wants to check with family.' },
  { time: 'Jun 27 · 9:15 AM', text: 'Client confirmed budget SAR 900k. Ready to proceed.' },
]
const stepDefs = [
  { label: 'New', date: 'Jun 24 · 10:32 AM', sub: 'Lead submitted by Ahmed Al-Rashid' },
  { label: 'Contacted', date: 'Jun 25 · 2:15 PM', sub: 'Status updated by you' },
  { label: 'Site Visit', date: 'Jun 26 · 11:00 AM', sub: 'Client visited Palm Residence' },
  { label: 'Negotiation', date: 'Jun 27 · 9:15 AM', sub: 'Currently in progress' },
  { label: 'Closed', date: '—', sub: '' },
  { label: 'Lost', date: '—', sub: '' },
]

const modalShell = { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }
const modalCard = { background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '18px 20px', maxWidth: 440, width: '100%', boxShadow: '0 10px 30px rgba(0,0,0,0.12)' }
const btnGhost = { height: 34, padding: '0 16px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }
const inputStyle = { width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 13, fontFamily: 'inherit' }
const modalFieldLabel = { fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }

const fmt = (raw) => {
  const d = String(raw).replace(/[^\d]/g, '')
  return d ? Number(d).toLocaleString('en-US') : ''
}
const sar = (n) => 'SAR ' + n.toLocaleString('en-US')

export default function DeveloperLeadDetail() {
  const navigate = useNavigate()
  const [view, setView] = useState('neg') // neg | closed | lost
  const [paid, setPaid] = useState(false)
  const [closeOpen, setCloseOpen] = useState(false)
  const [disputeOpen, setDisputeOpen] = useState(false)
  const [price, setPrice] = useState('900,000')

  const currentIdx = view === 'neg' ? 3 : view === 'closed' ? 4 : 5
  const dates = { 4: view === 'closed' ? 'Jun 28 · 4:00 PM' : '—', 5: view === 'lost' ? 'Jun 27 · 5:00 PM' : '—' }

  const timeline = stepDefs.map((st, i) => {
    const isDone = i < currentIdx
    const isCurrent = i === currentIdx
    return {
      label: st.label, date: dates[i] || st.date, sub: isDone || isCurrent ? st.sub : '',
      showCheck: isDone || (isCurrent && view === 'closed'),
      showDot: isCurrent && view !== 'closed',
      circleBg: isDone ? colors.green : isCurrent ? (view === 'lost' ? colors.red : view === 'closed' ? colors.green : colors.ink) : '#fff',
      circleBorder: isDone || isCurrent ? 'none' : `1.5px solid ${colors.border}`,
      hasLine: i < stepDefs.length - 1,
      lineColor: i < currentIdx ? colors.green : colors.border,
      weight: isCurrent ? 600 : 500,
      color: isDone || isCurrent ? colors.ink : colors.textFaint,
    }
  })

  const priceNum = Number(String(price).replace(/[^\d]/g, '')) || 0
  const comm = Math.round(priceNum * 0.03)
  const fee = Math.round(comm * 0.15)
  const net = comm - fee

  const tabStyle = (on) => ({ padding: '5px 11px', fontSize: 12, borderRadius: 6, cursor: 'pointer', ...(on ? { background: '#fff', color: colors.ink, fontWeight: 600, boxShadow: '0 1px 2px rgba(0,0,0,0.06)' } : { color: colors.textSoft }) })
  const setV = (v) => { setView(v); setPaid(false) }

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span onClick={() => navigate('/developer/leads')} style={{ fontSize: 13, color: colors.textFaint, cursor: 'pointer' }}>All Leads</span>
            <Icon name="chevronRight" size={14} color={colors.borderStrong} strokeWidth={2} />
            <span style={{ fontSize: 13, fontWeight: 500 }}>Khalid M. · Palm Residence</span>
          </div>
        }
        actions={
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: 4, background: colors.surfaceMuted, borderRadius: 8, padding: 3 }}>
              <span onClick={() => setV('neg')} style={tabStyle(view === 'neg')}>Negotiation</span>
              <span onClick={() => setV('closed')} style={tabStyle(view === 'closed')}>Closed</span>
              <span onClick={() => setV('lost')} style={tabStyle(view === 'lost')}>Lost</span>
            </div>
            <button onClick={() => navigate('/developer/leads')} style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 12, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>← Back to leads</button>
          </div>
        }
      />

      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg, padding: '18px 22px' }}>
        <div className="rp-cols" style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
          {/* LEFT */}
          <div style={{ flex: 2, minWidth: 0 }}>
            {/* Client info */}
            <div style={card}>
              <div style={sectionLabel}>Client Information</div>
              <div style={{ display: 'flex', gap: 14, alignItems: 'center', marginBottom: 14 }}>
                <Avatar initials="KA" size={52} fontSize={16} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 18, fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 6 }}>Khalid Al-Ansari</div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                    <Icon name="phone" size={15} color={colors.green} strokeWidth={1.8} />
                    <span style={{ fontSize: 14, fontWeight: 600 }}>+966 50 123 4567</span>
                    <span style={{ width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${colors.border}`, borderRadius: 6, cursor: 'pointer' }}>
                      <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.7}><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15V5a2 2 0 0 1 2-2h10" /></svg>
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 5, background: '#25D366', borderRadius: 999, padding: '5px 12px', cursor: 'pointer' }}>
                      <svg width={14} height={14} viewBox="0 0 24 24" fill="#fff"><path d="M12 2a10 10 0 0 0-8.6 15l-1.4 5 5.1-1.3A10 10 0 1 0 12 2z" /></svg>
                      <span style={{ fontSize: 12, fontWeight: 500, color: '#fff' }}>WhatsApp</span>
                    </span>
                  </div>
                  <div style={{ fontSize: 10, color: colors.textFaint, fontStyle: 'italic', marginTop: 4 }}>Viewed by you · June 27 10:32 AM</div>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 16px' }}>
                {clientFields.map(([label, value]) => (
                  <div key={label}>
                    <div style={{ fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 2 }}>{label}</div>
                    <div style={{ fontSize: 13, color: colors.textMuted }}>{value}</div>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${colors.surfaceMuted}`, display: 'flex', gap: 12, alignItems: 'center' }}>
                <div style={{ width: 36, height: 36, borderRadius: '50%', background: colors.surfaceMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600, color: colors.textMuted }}>AR</div>
                <div><div style={{ fontSize: 13, fontWeight: 600 }}>Ahmed Al-Rashid 🥇</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>Gold Realtor · Jeddah</div></div>
                <span onClick={() => navigate('/developer/network')} style={{ fontSize: 12, color: colors.greenDark, cursor: 'pointer', marginLeft: 'auto' }}>View Realtor</span>
              </div>
              <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${colors.surfaceMuted}` }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: colors.textMuted, marginBottom: 6 }}>Realtor notes</div>
                <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '10px 12px', fontSize: 13, color: colors.textMuted, lineHeight: 1.6, fontStyle: 'italic' }}>
                  Client visited a similar project in Al Hamra last month. Serious buyer, budget confirmed SAR 900k.
                </div>
              </div>
            </div>

            {/* Project */}
            <div style={card}>
              <div style={{ ...sectionLabel, marginBottom: 12 }}>Project</div>
              <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
                <div style={{ width: 64, height: 48, minWidth: 64, borderRadius: 8, background: colors.surfaceMuted, backgroundImage: hatch }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 3 }}>Palm Residence</div>
                  <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                    <Icon name="mapPin" size={12} color={colors.textFaint} strokeWidth={1.8} />
                    <span style={{ fontSize: 12, color: colors.textFaint }}>Al Rawdhah, Jeddah</span>
                  </div>
                  <div style={{ fontSize: 12, color: colors.textMuted, marginTop: 4 }}>Unit: 2BR · SAR 850k–1M · <span style={{ color: colors.greenDark, fontWeight: 600 }}>3% Commission</span></div>
                </div>
              </div>
            </div>

            {/* Internal notes */}
            <div style={card} className="wa-form">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                <span style={{ fontSize: 14, fontWeight: 600 }}>Internal notes</span>
                <svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.8}><circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" /></svg>
              </div>
              {devNotes.map((n, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, padding: '12px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}>
                  <div style={{ width: 28, height: 28, minWidth: 28, borderRadius: '50%', background: colors.surfaceMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 600, color: colors.textMuted, marginTop: 2 }}>AF</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                      <span style={{ fontSize: 12, fontWeight: 500 }}>Mohammed Al-Faisal</span>
                      <span style={{ fontSize: 11, color: colors.textFaint }}>{n.time}</span>
                    </div>
                    <div style={{ fontSize: 13, color: colors.textMuted, lineHeight: 1.6 }}>{n.text}</div>
                  </div>
                </div>
              ))}
              <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${colors.surfaceMuted}` }}>
                <textarea placeholder="Add an internal note..." style={{ width: '100%', height: 70, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, fontFamily: 'inherit', resize: 'none' }} />
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                  <button style={{ height: 30, padding: '0 12px', background: colors.green, border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 500, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Save Note</button>
                </div>
              </div>
            </div>

            {/* Dispute */}
            <div style={{ ...card, marginBottom: 0 }}>
              <div style={rLabel}>Dispute</div>
              <div style={{ fontSize: 13, color: colors.textSoft, lineHeight: 1.6, marginBottom: 12 }}>If there's an issue with this lead or commission, raise a dispute.</div>
              <button onClick={() => setDisputeOpen(true)} style={{ width: '100%', height: 34, background: '#fff', border: `1px solid ${colors.redTintBorder}`, borderRadius: 8, fontSize: 13, color: colors.red, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.red} strokeWidth={1.8}><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7" /></svg>Raise Dispute
              </button>
            </div>
          </div>

          {/* RIGHT */}
          <div style={{ flex: 1, minWidth: 250, position: 'sticky', top: 0 }}>
            {/* Lead status */}
            <div style={card}>
              <div style={rLabel}>Lead Status</div>

              {view === 'closed' ? (
                paid ? (
                  <div style={{ background: colors.amberTint, border: `1px solid ${colors.amberTintBorder}`, borderRadius: 10, padding: '14px 16px', textAlign: 'center' }}>
                    <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke={colors.amber} strokeWidth={1.8} style={{ marginBottom: 8 }}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>
                    <div style={{ fontSize: 14, fontWeight: 600, color: colors.amberText }}>Payment proof uploaded</div>
                    <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 4 }}>Awaiting Waseet verification</div>
                  </div>
                ) : (
                  <div style={{ background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 10, padding: '14px 16px', textAlign: 'center' }}>
                    <svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2} style={{ marginBottom: 8 }}><circle cx="12" cy="12" r="10" /><path d="M8 12l2.5 2.5L16 9" /></svg>
                    <div style={{ fontSize: 16, fontWeight: 700 }}>Deal Closed! 🎉</div>
                    <div style={{ fontSize: 13, color: colors.textSoft, marginTop: 2 }}>SAR 27,000 commission due</div>
                    <div style={{ fontSize: 12, color: colors.amber, marginTop: 4 }}>Payment due: July 1, 2026</div>
                    <button onClick={() => setPaid(true)} style={{ width: '100%', height: 36, marginTop: 10, background: colors.green, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Upload Payment Proof</button>
                  </div>
                )
              ) : (
                <div className="wa-form">
                  <div style={{ textAlign: 'center', marginBottom: 14 }}>
                    <div style={{ width: '100%', boxSizing: 'border-box', borderRadius: 8, padding: '8px 14px', fontSize: 14, fontWeight: 700, ...(view === 'lost' ? { background: colors.redTint, border: `1px solid ${colors.redTintBorder}`, color: '#991B1B' } : { background: colors.amberTint, border: `1px solid ${colors.amberTintBorder}`, color: colors.amberText }) }}>{view === 'lost' ? 'Lost' : 'Negotiation'}</div>
                    <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 6 }}>Since June 27, 2026</div>
                  </div>
                  <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 6 }}>Update status:</div>
                  <select defaultValue="Negotiation" style={{ width: '100%', height: 36, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 13, fontFamily: 'inherit', color: colors.textMuted, background: '#fff' }}>
                    <option>New</option><option>Contacted</option><option>Site Visit</option><option>Negotiation</option><option>Lost</option>
                  </select>
                  <button style={{ width: '100%', height: 34, marginTop: 8, background: colors.green, border: 'none', borderRadius: 7, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Update Status</button>
                  <button onClick={() => setCloseOpen(true)} style={{ width: '100%', height: 36, marginTop: 10, background: colors.ink, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                    <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={1.8}><path d="M11 17a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M13 7a5 5 0 0 0-7 0L3 10a5 5 0 0 0 7 7l1-1" /></svg>Mark as Closed Deal
                  </button>
                </div>
              )}
            </div>

            {/* Status history */}
            <div style={card}>
              <div style={{ ...rLabel, marginBottom: 14 }}>Status History</div>
              {timeline.map((t, i) => (
                <div key={i} style={{ display: 'flex', gap: 12 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <div style={{ width: 20, height: 20, minWidth: 20, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: t.circleBg, border: t.circleBorder }}>
                      {t.showCheck && <svg width={11} height={11} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3}><path d="M5 12l4 4L19 7" /></svg>}
                      {t.showDot && <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#fff' }} />}
                    </div>
                    {t.hasLine && <div style={{ width: 1.5, height: 32, background: t.lineColor, margin: '2px 0' }} />}
                  </div>
                  <div style={{ paddingBottom: 14 }}>
                    <div style={{ fontSize: 13, fontWeight: t.weight, color: t.color }}>{t.label}</div>
                    <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 2 }}>{t.date}</div>
                    {t.sub && <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 1 }}>{t.sub}</div>}
                  </div>
                </div>
              ))}
            </div>

            {/* Commission preview */}
            {view !== 'lost' && (
              <div style={{ ...card, marginBottom: 0 }}>
                <div style={rLabel}>Commission Preview</div>
                <div style={{ fontSize: 11, color: colors.textFaint, marginBottom: 10 }}>If closed at SAR 900,000 (2BR):</div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: colors.textMuted, padding: '6px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}><span>Sale Price</span><span>SAR 900,000</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: colors.textMuted, padding: '6px 0', borderBottom: `1px solid ${colors.surfaceMuted}` }}><span>Commission (3%)</span><span>SAR 27,000</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: colors.textFaint, padding: '6px 0' }}><span>Platform fee (15%)</span><span>SAR 4,050</span></div>
                <div style={{ height: 1, background: colors.surfaceMuted, margin: '4px 0' }} />
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, fontWeight: 700, paddingTop: 6 }}><span>You owe Waseet</span><span>SAR 27,000</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: colors.textSoft, marginTop: 4 }}><span>Realtor receives</span><span>SAR 22,950</span></div>
                <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 10, lineHeight: 1.5 }}>Payment due within 7 days of marking deal as closed.</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Close deal modal */}
      {closeOpen && (
        <div onClick={() => setCloseOpen(false)} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={modalCard} className="wa-form">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}><span style={{ fontSize: 14, fontWeight: 600 }}>Mark deal as closed</span><span onClick={() => setCloseOpen(false)} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '10px 12px', marginBottom: 16 }}><div style={{ fontSize: 13, color: colors.textMuted }}>Khalid Al-Ansari · Palm Residence 2BR</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 3 }}>#WS-2026-042 · Ahmed Al-Rashid 🥇</div></div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div><div style={modalFieldLabel}>Unit Number *</div><input placeholder="e.g. 401" style={inputStyle} /></div>
              <div><div style={modalFieldLabel}>Final Sale Price *</div>
                <div style={{ display: 'flex', border: `1px solid ${colors.border}`, borderRadius: 7, overflow: 'hidden', height: 34 }}>
                  <span style={{ background: colors.bg, borderRight: `1px solid ${colors.border}`, display: 'flex', alignItems: 'center', padding: '0 10px', fontSize: 12, color: colors.textSoft }}>SAR</span>
                  <input value={price} onChange={(e) => setPrice(fmt(e.target.value))} placeholder="900,000" style={{ flex: 1, border: 'none', padding: '0 10px', fontSize: 13, fontFamily: 'inherit', minWidth: 0 }} />
                </div>
              </div>
              <div><div style={modalFieldLabel}>Closing Date *</div><input placeholder="DD / MM / YYYY" style={inputStyle} /></div>
            </div>
            <div style={{ background: colors.bg, border: `1px solid ${colors.border}`, borderRadius: 8, padding: '10px 12px', marginTop: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: colors.textMuted }}><span>Commission (3%)</span><span>{sar(comm)}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: colors.textFaint, marginTop: 4 }}><span>Platform (15%)</span><span>{sar(fee)}</span></div>
              <div style={{ height: 1, background: colors.border, margin: '8px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, fontWeight: 700 }}><span>Realtor receives</span><span>{sar(net)}</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: colors.textFaint, marginTop: 6 }}><span>Payment due</span><span>July 1, 2026</span></div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 16 }}>
              <button onClick={() => setCloseOpen(false)} style={btnGhost}>Cancel</button>
              <button onClick={() => { setCloseOpen(false); setView('closed'); setPaid(false) }} style={{ height: 34, padding: '0 16px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Confirm &amp; Close ✓</button>
            </div>
          </div>
        </div>
      )}

      {/* Dispute modal */}
      {disputeOpen && (
        <div onClick={() => setDisputeOpen(false)} style={modalShell}>
          <div onClick={(e) => e.stopPropagation()} style={modalCard} className="wa-form">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}><span style={{ fontSize: 14, fontWeight: 600 }}>Raise a dispute</span><span onClick={() => setDisputeOpen(false)} style={{ fontSize: 18, color: colors.textFaint, cursor: 'pointer' }}>×</span></div>
            <div style={{ background: colors.bg, border: `1px solid ${colors.surfaceMuted}`, borderRadius: 8, padding: '10px 12px', marginBottom: 14 }}><div style={{ fontSize: 13, color: colors.textMuted }}>Khalid M. · Palm Residence 2BR</div><div style={{ fontSize: 11, color: colors.textFaint, marginTop: 3 }}>Lead #WS-2026-042</div></div>
            <div style={{ fontSize: 12, fontWeight: 500, color: colors.textMuted, marginBottom: 4 }}>Reason for dispute *</div>
            <textarea placeholder="Describe the issue clearly..." style={{ width: '100%', height: 100, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, fontFamily: 'inherit', resize: 'none' }} />
            <div style={{ fontSize: 11, color: colors.textFaint, marginTop: 10 }}>Our team reviews disputes within 48 hours and notifies both parties.</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 14 }}>
              <button onClick={() => setDisputeOpen(false)} style={btnGhost}>Cancel</button>
              <button onClick={() => setDisputeOpen(false)} style={{ height: 34, padding: '0 14px', background: colors.green, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>Submit Dispute</button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
