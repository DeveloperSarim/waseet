import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { Topbar } from '../../components/layout/Topbar'

const statusTone = {
  New: { bg: '#EEF3FF', color: '#1B4FD8', bd: '#BFDBFE', dot: '#1B4FD8' },
  Contacted: { bg: '#F5F3FF', color: '#5B5BD6', bd: '#DDD6FE', dot: '#5B5BD6' },
  'Site Visit': { bg: '#EEF3FF', color: '#3730A3', bd: '#C7D2FE', dot: '#3730A3' },
  Negotiation: { bg: '#FFFBEB', color: '#92400E', bd: '#FDE68A', dot: '#D97706' },
  Closed: { bg: colors.greenTint, color: colors.greenDark, bd: colors.greenTintBorder, dot: colors.green },
}
const statusOptions = ['New', 'Contacted', 'Site Visit', 'Negotiation']

const leadsData = [
  { init: 'AR', realtor: 'Ahmed Al-Rashid', tier: '🥇', project: 'Palm Residence · 2BR', client: 'Khalid M.', phone: '+966 ***** 4567', fullPhone: '+966 50 123 4567', time: '2 hrs ago', status: 'New' },
  { init: 'FA', realtor: 'Fatima Hassan', tier: '🥈', project: 'Palm Residence · 1BR', client: 'Sara A.', phone: '+966 ***** 8901', fullPhone: '+966 55 890 1234', time: 'Yesterday', status: 'Contacted' },
  { init: 'BK', realtor: 'Bilal Khan', tier: '🥉', project: 'Al Noor Tower · 3BR', client: 'Omar K.', phone: '+92 ***** 5678', fullPhone: '+92 300 555 5678', time: 'Jun 25', status: 'Site Visit' },
  { init: 'MH', realtor: 'Mohammed Hasan', tier: '🥉', project: 'Palm Residence · Studio', client: 'Hassan M.', phone: '+966 ***** 2345', fullPhone: '+966 56 234 5678', time: 'Jun 23', status: 'Negotiation' },
]

const selStyle = { height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 12, fontFamily: 'inherit', color: colors.textMuted, background: '#fff' }
const dateStyle = { height: 34, width: 110, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px', fontSize: 12, fontFamily: 'inherit', color: colors.textMuted }

export default function DeveloperLeads() {
  const navigate = useNavigate()
  const [revealed, setRevealed] = useState({})
  const [statusOpen, setStatusOpen] = useState(null)

  return (
    <>
      <Topbar
        left={
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em' }}>All Leads</span>
            <span style={{ fontSize: 13, color: colors.textFaint }}>248 total</span>
          </div>
        }
        actions={
          <button style={{ height: 34, padding: '0 14px', background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, fontWeight: 500, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icon name="download" size={14} color={colors.textMuted} strokeWidth={1.7} />Export CSV
          </button>
        }
      />

      {/* Filter bar */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${colors.border}`, padding: '10px 22px', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <select style={selStyle}><option>All Projects</option></select>
        <select style={selStyle}><option>All Status</option></select>
        <input placeholder="Date from" style={dateStyle} />
        <input placeholder="Date to" style={dateStyle} />
        <div style={{ position: 'relative', flex: 1, maxWidth: 260, minWidth: 160 }}>
          <Icon name="search" size={14} color={colors.textFaint} strokeWidth={1.8} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }} />
          <input placeholder="Search client or realtor..." style={{ width: '100%', height: 34, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 10px 0 32px', fontSize: 12, fontFamily: 'inherit' }} />
        </div>
      </div>

      {/* List */}
      <div style={{ flex: 1, overflowY: 'auto', background: colors.bg }}>
        <div style={{ padding: '16px 22px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {leadsData.map((l, i) => {
            const t = statusTone[l.status]
            const isRevealed = revealed[i]
            return (
              <div key={i} style={{ background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 12, padding: '14px 16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <div>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={{ width: 28, height: 28, borderRadius: '50%', background: colors.surfaceMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 600, color: colors.textMuted }}>{l.init}</span>
                      <span style={{ fontSize: 13, fontWeight: 500 }}>{l.realtor}</span>
                      <span style={{ fontSize: 12 }}>{l.tier}</span>
                    </div>
                    <div style={{ fontSize: 12, color: colors.textSoft, marginTop: 3 }}>{l.project}</div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span style={{ borderRadius: 999, padding: '3px 10px', fontSize: 11, fontWeight: 600, border: `1px solid ${t.bd}`, background: t.bg, color: t.color }}>{l.status}</span>
                    <span style={{ fontSize: 11, color: colors.textFaint }}>{l.time}</span>
                  </div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 12, borderTop: `1px solid ${colors.surfaceMuted}`, gap: 10, flexWrap: 'wrap' }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span style={{ fontSize: 12, color: colors.textFaint }}>Client:</span>
                    <span style={{ fontSize: 13, fontWeight: 500, color: colors.textMuted }}>{l.client}</span>
                    {isRevealed ? (
                      <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ fontSize: 13, fontWeight: 600 }}>{l.fullPhone}</span>
                        <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke={colors.textFaint} strokeWidth={1.7} style={{ cursor: 'pointer' }}><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15V5a2 2 0 0 1 2-2h10" /></svg>
                      </span>
                    ) : (
                      <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 12, color: colors.textFaint }}>{l.phone}</span>
                        <span onClick={() => setRevealed({ ...revealed, [i]: true })} style={{ fontSize: 11, fontWeight: 500, color: colors.greenDark, background: colors.greenTint, border: `1px solid ${colors.greenTintBorder}`, borderRadius: 5, padding: '2px 7px', cursor: 'pointer' }}>Reveal</span>
                      </span>
                    )}
                  </div>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <div style={{ position: 'relative' }}>
                      <div onClick={() => setStatusOpen(statusOpen === i ? null : i)} style={{ height: 32, padding: '0 10px', display: 'flex', alignItems: 'center', gap: 5, border: `1px solid ${colors.border}`, borderRadius: 6, fontSize: 12, color: colors.textMuted, cursor: 'pointer', background: '#fff' }}>
                        {l.status}<Icon name="chevronDown" size={12} color={colors.textFaint} strokeWidth={2} />
                      </div>
                      {statusOpen === i && (
                        <div style={{ position: 'absolute', right: 0, top: 36, zIndex: 20, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, boxShadow: '0 8px 24px rgba(0,0,0,0.1)', minWidth: 180, overflow: 'hidden' }}>
                          {statusOptions.map((o) => (
                            <div key={o} onClick={() => setStatusOpen(null)} style={{ padding: '9px 14px', fontSize: 13, color: colors.textMuted, cursor: 'pointer', display: 'flex', gap: 8, alignItems: 'center' }}>
                              <span style={{ width: 6, height: 6, borderRadius: '50%', background: statusTone[o].dot }} />{o}
                            </div>
                          ))}
                          <div style={{ height: 1, background: colors.surfaceMuted }} />
                          <div style={{ padding: '10px 14px', fontSize: 13, fontWeight: 500, color: colors.greenDark, cursor: 'pointer' }}>Mark as Closed Deal →</div>
                        </div>
                      )}
                    </div>
                    <div onClick={() => navigate('/developer/leads/' + i)} title="Edit lead" style={{ width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${colors.border}`, borderRadius: 6, cursor: 'pointer' }}>
                      <Icon name="edit" size={13} color={colors.textFaint} strokeWidth={1.8} />
                    </div>
                    <div style={{ width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${colors.border}`, borderRadius: 6, cursor: 'pointer', color: colors.textFaint, fontSize: 14 }}>⋯</div>
                  </div>
                </div>
                {isRevealed && <div style={{ fontSize: 10, color: colors.textFaint, fontStyle: 'italic', marginTop: 6 }}>Logged: you viewed this · 10:32 AM</div>}
              </div>
            )
          })}
        </div>
      </div>

      {/* Pagination */}
      <div style={{ background: colors.bg, borderTop: `1px solid ${colors.border}`, padding: '12px 22px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
        <span style={{ fontSize: 12, color: colors.textSoft }}>Showing 1–10 of 248 leads</span>
        <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
          <span style={{ height: 30, padding: '0 10px', display: 'flex', alignItems: 'center', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textFaint, background: '#fff' }}>← Prev</span>
          {['1', '2', '3'].map((n, i) => (
            <span key={n} style={{ width: 30, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 7, fontSize: 12, fontWeight: i === 0 ? 600 : 400, border: i === 0 ? 'none' : `1px solid ${colors.border}`, background: i === 0 ? colors.ink : '#fff', color: i === 0 ? '#fff' : colors.textMuted, cursor: 'pointer' }}>{n}</span>
          ))}
          <span style={{ height: 30, padding: '0 10px', display: 'flex', alignItems: 'center', border: `1px solid ${colors.border}`, borderRadius: 7, fontSize: 12, color: colors.textMuted, background: '#fff', cursor: 'pointer' }}>Next →</span>
        </div>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: colors.textSoft }}>Per page</span>
          <select style={{ height: 32, border: `1px solid ${colors.border}`, borderRadius: 7, padding: '0 8px', fontSize: 12, fontFamily: 'inherit', background: '#fff' }}><option>10</option><option>25</option></select>
        </div>
      </div>
    </>
  )
}
