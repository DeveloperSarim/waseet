import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { colors } from '../../theme/tokens'
import { Icon } from '../../components/icons/Icon'
import { Label, Hint, TextInput, SelectInput, Section, CheckBox, StepIndicator, Dropzone, FileChip, PhoneField, inputStyle } from './RegistrationKit'

const checkLabels = [
  "I agree to Waseet's Terms & Conditions",
  'All information provided is accurate',
  'I understand Waseet charges a platform commission on all closed deals',
  'I agree to provide valid NOC documents for all listed projects',
]
const timeline = [
  { title: 'Application received', sub: 'Just now', done: true },
  { title: 'Admin review', sub: 'Within 24 hours', done: false },
  { title: 'Account approved', sub: "We'll email you", done: false },
  { title: 'Add your first project', sub: 'After approval', done: false },
]

export default function DeveloperRegistration() {
  const navigate = useNavigate()
  const [checks, setChecks] = useState([false, false, false, false])
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const toggle = (i) => setChecks(checks.map((v, j) => (j === i ? !v : v)))
  const allChecked = checks.every(Boolean)

  const onSubmit = () => {
    if (!allChecked || loading) return
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      setSubmitted(true)
      window.scrollTo(0, 0)
    }, 1400)
  }

  if (submitted) {
    return (
      <div style={{ fontFamily: 'Inter, sans-serif', color: colors.ink, background: colors.bg, minHeight: '100vh' }}>
        <div style={{ maxWidth: 480, margin: '0 auto', padding: '48px 24px', textAlign: 'center' }}>
          <svg width={52} height={52} viewBox="0 0 24 24" fill="none" stroke={colors.green} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ margin: '0 auto 20px', animation: 'pd-pop .3s ease-out' }}>
            <circle cx="12" cy="12" r="10" />
            <path d="M8 12l2.5 2.5L16 9" />
          </svg>
          <div style={{ fontSize: 22, fontWeight: 700, marginBottom: 8 }}>Application submitted! 🎉</div>
          <div style={{ fontSize: 13, color: colors.textSoft, lineHeight: 1.7, marginBottom: 28 }}>
            We received your developer application. Our team reviews within 24 hours. Check your email for updates.
          </div>
          <div style={{ textAlign: 'left', maxWidth: 320, margin: '0 auto' }}>
            {timeline.map((t, i) => (
              <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', paddingBottom: 16, position: 'relative' }}>
                {i !== timeline.length - 1 && <div style={{ position: 'absolute', left: 9, top: 20, width: 1, height: '100%', background: colors.border }} />}
                <div style={{ width: 20, height: 20, minWidth: 20, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', zIndex: 1, background: t.done ? colors.green : '#fff', border: t.done ? 'none' : `1px solid ${colors.border}` }}>
                  {t.done && <svg width={11} height={11} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3}><path d="M5 12l4 4L19 7" /></svg>}
                </div>
                <div style={{ position: 'relative', zIndex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{t.title}</div>
                  <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 2 }}>{t.sub}</div>
                </div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}>
            <button onClick={() => navigate('/')} style={{ height: 36, background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 13, fontWeight: 500, color: colors.textMuted, fontFamily: 'inherit', cursor: 'pointer' }}>Back to Home</button>
            <button style={{ height: 36, background: 'transparent', border: 'none', fontSize: 12, color: colors.textSoft, fontFamily: 'inherit', cursor: 'pointer' }}>Check Application Status</button>
          </div>
          <div style={{ fontSize: 12, color: colors.textFaint, marginTop: 16 }}>Questions? support@waseet.io</div>
        </div>
      </div>
    )
  }

  return (
    <div className="wa-form" style={{ fontFamily: 'Inter, sans-serif', color: colors.ink, background: colors.bg, minHeight: '100vh' }}>
      <div style={{ maxWidth: 600, margin: '0 auto', padding: '32px 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 }}>
          <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke={colors.ink} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11z" /><circle cx="12" cy="11" r="2.4" /></svg>
            <span style={{ fontSize: 15, fontWeight: 700 }}>waseet</span>
          </Link>
          <div style={{ fontSize: 12, color: colors.textSoft }}>
            Already have an account? <Link to="/login" style={{ color: colors.greenDark, cursor: 'pointer' }}>Sign in</Link>
          </div>
        </div>

        <h1 style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', margin: '0 0 4px' }}>Create developer account</h1>
        <p style={{ fontSize: 13, color: colors.textSoft, margin: '0 0 28px' }}>Join 50+ verified developers on Waseet</p>

        <StepIndicator labels={['Company', 'Contact', 'Documents', 'Agreement']} activeIndex={0} />

        {/* 01 Company */}
        <Section num="01" title="Company information">
          <div style={{ marginBottom: 12 }}>
            <Label>Company Name *</Label>
            <TextInput placeholder="Al Faisal Real Estate Development" />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
            <div>
              <Label>Country *</Label>
              <SelectInput defaultValue="Saudi Arabia"><option>Saudi Arabia</option><option>UAE</option><option>Pakistan</option></SelectInput>
            </div>
            <div>
              <Label>City *</Label>
              <TextInput placeholder="Jeddah" />
            </div>
          </div>
          <div style={{ marginBottom: 12 }}>
            <Label icon="info">REGA License Number *</Label>
            <TextInput placeholder="REGA-2024-12345" />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
            <div>
              <Label>CR / Trade License *</Label>
              <TextInput placeholder="1234567890" />
            </div>
            <div>
              <Label>Website (optional)</Label>
              <TextInput placeholder="https://company.com" />
            </div>
          </div>
          <div>
            <Label>Years in Business</Label>
            <SelectInput defaultValue="Select"><option>Select</option><option>Less than 1 year</option><option>1–3 years</option><option>3–5 years</option><option>5–10 years</option><option>10+ years</option></SelectInput>
          </div>
        </Section>

        {/* 02 Contact person */}
        <Section num="02" title="Contact person">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
            <div>
              <Label>Full Name *</Label>
              <TextInput placeholder="Mohammed Al-Faisal" />
            </div>
            <div>
              <Label>Designation *</Label>
              <TextInput placeholder="Sales Director" />
            </div>
          </div>
          <div style={{ marginBottom: 12 }}>
            <Label>Phone Number *</Label>
            <PhoneField />
          </div>
          <div style={{ marginBottom: 12 }}>
            <Label>Email Address *</Label>
            <div style={{ position: 'relative' }}>
              <Icon name="mail" size={14} color={colors.textFaint} strokeWidth={1.7} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }} />
              <TextInput placeholder="m.faisal@company.com" style={{ padding: '0 10px 0 34px' }} />
            </div>
          </div>
          <label style={{ display: 'flex', gap: 8, alignItems: 'center', cursor: 'pointer' }}>
            <CheckBox on />
            <span style={{ fontSize: 12, color: colors.textMuted }}>WhatsApp same as phone number</span>
          </label>
        </Section>

        {/* 03 Documents */}
        <Section num="03" title="Required documents">
          <Dropzone icon="upload" title="Trade License / CR Certificate *" sub="Drag & drop or click to browse" note="PDF, JPG, PNG · max 50MB" />
          <FileChip name="rega_license.pdf" meta="2.4 MB · PDF" />
          <div style={{ border: `1px dashed ${colors.greenTintBorder}`, borderRadius: 8, padding: 9, textAlign: 'center', fontSize: 12, color: colors.green, cursor: 'pointer' }}>+ Add company profile (optional)</div>
        </Section>

        {/* 04 Agreement */}
        <Section num="04" title="Terms & agreement" style={{ marginBottom: 20 }}>
          {checkLabels.map((label, i) => (
            <div key={i} onClick={() => toggle(i)} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: 12, cursor: 'pointer' }}>
              <CheckBox on={checks[i]} marginTop={1} />
              <span style={{ fontSize: 13, color: colors.textMuted, lineHeight: 1.5 }}>{label}</span>
            </div>
          ))}
          <button
            onClick={onSubmit}
            disabled={!allChecked || loading}
            style={{ width: '100%', height: 36, border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 600, color: '#fff', fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, background: !allChecked || loading ? colors.textFaint : colors.green, cursor: !allChecked || loading ? 'not-allowed' : 'pointer' }}
          >
            {loading && <span style={{ width: 14, height: 14, border: '2px solid rgba(255,255,255,0.4)', borderTopColor: '#fff', borderRadius: '50%', display: 'inline-block', animation: 'pd-spin .7s linear infinite' }} />}
            {loading ? 'Submitting…' : 'Submit Application'}
          </button>
          <div style={{ fontSize: 12, color: colors.textFaint, textAlign: 'center', marginTop: 12 }}>Your data is stored securely per our Privacy Policy</div>
        </Section>
      </div>
    </div>
  )
}
